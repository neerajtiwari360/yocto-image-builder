#include "preview_render.h"
#include <math.h>
#include <string.h>
static void point(uint8_t *p,int w,int h,size_t pitch,int x,int y,int mark) {
    if(x<0||y<0||x>=w||y>=h)return;
    p[(size_t)y*pitch+(size_t)x]=(uint8_t)(mark==2?235:(mark?210:145));
    size_t uv=(size_t)h*pitch+(size_t)(y/2)*pitch+(size_t)(x&~1);
    p[uv]=(uint8_t)(mark==2?128:(mark?16:54));p[uv+1]=(uint8_t)(mark==2?128:(mark?146:34));
}
static void face_point(uint8_t *dst,int w,int h,size_t pitch,int x,int y,int mark,int ox,int oy,int dw,int dh) {
    if(x<ox||x>=ox+dw||y<oy||y>=oy+dh)return;
    point(dst,w,h,pitch,x,y,mark);
}
static void draw_faces(const preview_slot *s,uint8_t *dst,int w,int h,size_t pitch,int ox,int oy,int dw,int dh) {
    int sw=(int)s->width,sh=(int)s->height;
    for(uint32_t i=0;i<s->count;i++){
        const yunet_face *f=&s->faces[i];
        if(!isfinite(f->x)||!isfinite(f->y)||!isfinite(f->w)||!isfinite(f->h)||f->w<=0||f->h<=0)continue;
        float left=fmaxf(0,fminf((float)sw,f->x)),top=fmaxf(0,fminf((float)sh,f->y));
        float right=fmaxf(left,fminf((float)sw,f->x+f->w)),bottom=fmaxf(top,fminf((float)sh,f->y+f->h));
        int x0=ox+(int)(left*dw/sw),y0=oy+(int)(top*dh/sh);
        int x1=ox+(int)(right*dw/sw)-1,y1=oy+(int)(bottom*dh/sh)-1;
        if(x1<x0||y1<y0)continue;
        for(int t=0;t<2&&x0+t<=x1&&y0+t<=y1;t++){
            for(int x=x0;x<=x1;x++){face_point(dst,w,h,pitch,x,y0+t,0,ox,oy,dw,dh);face_point(dst,w,h,pitch,x,y1-t,0,ox,oy,dw,dh);}
            for(int y=y0;y<=y1;y++){face_point(dst,w,h,pitch,x0+t,y,0,ox,oy,dw,dh);face_point(dst,w,h,pitch,x1-t,y,0,ox,oy,dw,dh);}
        }
        for(int j=0;j<5;j++){
            float x=f->landmarks[j*2],y=f->landmarks[j*2+1];
            if(!isfinite(x)||!isfinite(y)||x<0||y<0||x>=sw||y>=sh)continue;
            int px=ox+(int)(x*dw/sw),py=oy+(int)(y*dh/sh);
            for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)face_point(dst,w,h,pitch,px+dx,py+dy,1,ox,oy,dw,dh);
        }
    }
}
static int render_base(const preview_slot *s,uint8_t *dst,size_t len,int w,int h,size_t pitch,int panel_width,int annotate) {
    if(!s||!dst||w<2||h<2||(w&1)||(h&1)||pitch<(size_t)w||pitch>len/(size_t)h||len<(size_t)h*pitch*3/2||
       s->width<2||s->height<2||s->width>PREVIEW_WIDTH||s->height>PREVIEW_HEIGHT||(s->width&1)||(s->height&1)||s->count>PREVIEW_FACES)return -1;
    int sw=(int)s->width,sh=(int)s->height;
    int dw=panel_width,dh=(int)((int64_t)sh*panel_width/sw)&~1;
    if(dh>h){dh=h;dw=(int)((int64_t)sw*h/sh)&~1;}
    if(dw<2||dh<2)return -1;
    int ox=((panel_width-dw)/2)&~1,oy=((h-dh)/2)&~1;
    /* Padding is cleared too: a stale box cannot survive in a reused buffer. */
    memset(dst,16,pitch*(size_t)h);memset(dst+pitch*(size_t)h,128,pitch*(size_t)h/2);
    for(int y=0;y<dh;y++){
        const uint8_t *src=s->pixels+(size_t)(y*sh/dh)*sw;
        uint8_t *out=dst+(size_t)(oy+y)*pitch+(size_t)ox;
        for(int x=0;x<dw;x++){
            int v=src[x*sw/dw];
            out[x]=(uint8_t)(s->full_range?16+(v*219+127)/255:v);
        }
    }
    const uint8_t *uv=s->pixels+(size_t)sw*sh;
    for(int y=0;y<dh/2;y++){
        const uint8_t *src=uv+(size_t)(y*sh/dh)*sw;
        uint8_t *out=dst+pitch*(size_t)h+(size_t)(oy/2+y)*pitch+(size_t)ox;
        for(int x=0;x<dw;x+=2){
            int sx=(x*sw/dw)&~1;
            for(int c=0;c<2;c++){int v=src[sx+c];out[x+c]=(uint8_t)(s->full_range?128+((v-128)*224)/255:v);}
        }
    }
    if(annotate)draw_faces(s,dst,w,h,pitch,ox,oy,dw,dh);
    return 0;
}

static void label(uint8_t *dst,int w,int h,size_t pitch,int x,int y,const char *text) {
    static const char letters[]="ACEFLMNORTUY";
    static const uint8_t glyphs[][5]={
        {0x7e,0x11,0x11,0x11,0x7e},{0x3e,0x41,0x41,0x41,0x22},
        {0x7f,0x49,0x49,0x49,0x41},{0x7f,0x09,0x09,0x09,0x01},
        {0x7f,0x40,0x40,0x40,0x40},{0x7f,0x02,0x04,0x02,0x7f},
        {0x7f,0x04,0x08,0x10,0x7f},{0x3e,0x41,0x41,0x41,0x3e},
        {0x7f,0x09,0x19,0x29,0x46},{0x01,0x01,0x7f,0x01,0x01},
        {0x3f,0x40,0x40,0x40,0x3f},{0x03,0x04,0x78,0x04,0x03}
    };
    for(;*text;text++,x+=12){
        const char *g=strchr(letters,*text);if(!g)continue;
        for(int col=0;col<5;col++)for(int row=0;row<7;row++)if(glyphs[g-letters][col]&(1u<<row))
            for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)point(dst,w,h,pitch,x+col*2+dx,y+row*2+dy,2);
    }
}
int preview_render_nv12(const preview_slot *s,uint8_t *dst,size_t len,int w,int h,size_t pitch) {
    return render_base(s,dst,len,w,h,pitch,w,1);
}
int preview_render_split_nv12(const preview_slot *s,uint8_t *dst,size_t len,int w,int h,size_t pitch,int ml_active) {
    if(w<8||(w%4))return -1; /* each NV12 column must have an even width */
    int half=w/2;
    if(render_base(s,dst,len,w,h,pitch,half,0))return -1;
    /* Resize once. A small sequential copy duplicates the clean panel before
     * any overlays are drawn; no second source read, resize or ML execution. */
    for(int y=0;y<h*3/2;y++)memcpy(dst+(size_t)y*pitch+half,dst+(size_t)y*pitch,(size_t)half);
    int sw=(int)s->width,sh=(int)s->height;
    int dw=half,dh=(int)((int64_t)sh*half/sw)&~1;
    if(dh>h){dh=h;dw=(int)((int64_t)sw*h/sh)&~1;}
    int ox=((half-dw)/2)&~1,oy=((h-dh)/2)&~1;
    if(ml_active)draw_faces(s,dst,w,h,pitch,half+ox,oy,dw,dh);
    for(int y=0;y<h;y++){point(dst,w,h,pitch,half-1,y,2);point(dst,w,h,pitch,half,y,2);}
    int title_y=oy>=20?oy-20:2;
    label(dst,w,h,pitch,8,title_y,"CAMERA");
    label(dst,w,h,pitch,half+8,title_y,ml_active?"YUNET":"ML OFF");
    return 0;
}
