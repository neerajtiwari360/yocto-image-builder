#define _POSIX_C_SOURCE 200809L
#include "preview.h"
#include <fcntl.h>
#include <string.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
_Static_assert(ATOMIC_INT_LOCK_FREE==2 && ATOMIC_LLONG_LOCK_FREE==2,
               "Preview requires process-shared lock-free 32/64-bit atomics");
uint64_t preview_now_ns(void) {
    struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);
    return (uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;
}
void preview_writer_close(preview_writer *p) {
    if(p->map){
        if(p->slot>=0)atomic_store_explicit(&p->map->slots[p->slot].state,PREVIEW_FREE,memory_order_release);
        munmap(p->map,sizeof(*p->map));p->map=NULL;
    }
    if(p->fd>=0)close(p->fd);
    p->fd=-1;p->slot=-1;
}
uint8_t *preview_begin(preview_writer *p,int w,int h,uint64_t ns) {
    if(w<2||h<2||w>PREVIEW_WIDTH||h>PREVIEW_HEIGHT||(w&1)||(h&1))return NULL;
    if(!p->map){
        if(ns<p->next_probe_ns)return NULL;
        p->next_probe_ns=ns+1000000000u;
        int fd=open(PREVIEW_PATH,O_RDWR|O_CLOEXEC|O_NOFOLLOW);
        if(fd<0)return NULL;
        struct stat st;
        if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_size!=(off_t)sizeof(preview_mailbox)||flock(fd,LOCK_EX|LOCK_NB)){close(fd);return NULL;}
        preview_mailbox *m=mmap(NULL,sizeof(*m),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
        if(m==MAP_FAILED){close(fd);return NULL;}
        if(atomic_load_explicit(&m->magic,memory_order_acquire)!=PREVIEW_MAGIC||m->version!=PREVIEW_VERSION||m->bytes!=sizeof(*m)||!m->fps||m->fps>30){munmap(m,sizeof(*m));close(fd);return NULL;}
        p->map=m;p->fd=fd;
        /* A former writer can die before publishing. flock proves it is gone.
         * Never reset READING or READY: the viewer may still own those slots. */
        for(int i=0;i<PREVIEW_SLOTS;i++){
            uint32_t expected=PREVIEW_WRITING;
            atomic_compare_exchange_strong(&m->slots[i].state,&expected,PREVIEW_FREE);
        }
    }
    uint64_t beat=atomic_load_explicit(&p->map->heartbeat_ns,memory_order_acquire);
    if(ns<beat||ns-beat>1000000000u){preview_writer_close(p);return NULL;}
    if(ns<p->next_frame_ns)return NULL;
    uint64_t period=1000000000u/p->map->fps;
    p->next_frame_ns+=period;
    if(p->next_frame_ns<=ns)p->next_frame_ns=ns+period;
    for(int pass=0;pass<2;pass++)for(int i=0;i<PREVIEW_SLOTS;i++){
        uint32_t expected=pass?PREVIEW_READY:PREVIEW_FREE;
        if(atomic_compare_exchange_strong_explicit(&p->map->slots[i].state,&expected,PREVIEW_WRITING,memory_order_acq_rel,memory_order_relaxed)){
            preview_slot *s=&p->map->slots[i];s->width=(uint32_t)w;s->height=(uint32_t)h;p->slot=i;
            return s->pixels;
        }
    }
    p->dropped++;return NULL;
}
void preview_publish(preview_writer *p,int matrix,int range,const yunet_face *faces,size_t n,uint64_t seq,uint64_t ns) {
    if(p->slot<0)return;
    preview_slot *s=&p->map->slots[p->slot];
    if(n>PREVIEW_FACES)n=PREVIEW_FACES;
    s->matrix=(uint32_t)matrix;s->full_range=(uint32_t)range;s->count=(uint32_t)n;
    s->sequence=seq;s->capture_ns=ns;memcpy(s->faces,faces,n*sizeof(*faces));
    atomic_store_explicit(&s->state,PREVIEW_READY,memory_order_release);
    p->slot=-1;p->published++;
}
int preview_take_latest(preview_mailbox *m) {
    int best=-1;
    /* Claim BEFORE reading sequence/metadata; scanning READY metadata without
     * ownership races a producer reclaiming the same slot. */
    for(int i=0;i<PREVIEW_SLOTS;i++){
        uint32_t expected=PREVIEW_READY;
        if(!atomic_compare_exchange_strong_explicit(&m->slots[i].state,&expected,PREVIEW_READING,memory_order_acq_rel,memory_order_relaxed))continue;
        /* Frame counters restart with an inference process; CLOCK_MONOTONIC
         * acquisition time still orders the newest frame across restarts. */
        if(best<0||m->slots[i].capture_ns>m->slots[best].capture_ns){
            if(best>=0)preview_release(m,best);
            best=i;
        }else preview_release(m,i);
    }
    return best;
}
void preview_release(preview_mailbox *m,int i) {
    atomic_store_explicit(&m->slots[i].state,PREVIEW_FREE,memory_order_release);
}
