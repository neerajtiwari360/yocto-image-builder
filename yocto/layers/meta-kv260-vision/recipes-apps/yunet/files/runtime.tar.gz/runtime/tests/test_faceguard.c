#include "faceguard.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint8_t image[160*160*3];
static int8_t aligned[FG_WIDTH*FG_HEIGHT*3];
static yunet_face face(void){
    yunet_face f={10,10,130,140,{58.2946f,71.6963f,93.5318f,71.5014f,76.0252f,91.7366f,61.5493f,112.3655f,90.7299f,112.2041f},.99f};return f;
}
int main(void){
    yunet_face f=face();fg_quality_config c=fg_quality_defaults();fg_quality_result r;
    for(int y=0;y<160;y++)for(int x=0;x<160;x++)for(int ch=0;ch<3;ch++)image[(y*160+x)*3+ch]=(uint8_t)(80+((x+y)%2)*90);
    assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(!r.rejected);
    assert(r.landmark_error<.0001f);
    assert(!fg_align(image,160,160,480,&f,5,aligned));
    /* Translation by 20 pixels gives exact sampling of the checkerboard. */
    assert(aligned[0]==-12&&aligned[3]==11);
    memset(image,128,sizeof(image));
    assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected&FG_BLUR);assert(r.rejected&FG_OCCLUSION_PROXY);
    memset(image,0,sizeof(image));
    assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected&FG_LIGHT);
    f.x=-1;assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected&FG_POSITION);
    f=face();f.w=70;assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected&FG_SIZE);
    f=face();f.landmarks[4]+=30;assert(!fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected&FG_LANDMARKS);
    f=face();f.landmarks[0]=NAN;assert(fg_quality(image,160,160,480,&f,&c,&r));assert(r.rejected==FG_INVALID);
    f=face();assert(fg_align(image,160,160,480,&f,17,aligned));
    assert(fg_align(image,160,160,20,&f,7,aligned));
    for(int i=0;i<5;i++){f.landmarks[2*i]-=40;f.landmarks[2*i+1]-=40;}
    memset(aligned,17,sizeof(aligned));assert(fg_align(image,160,160,480,&f,7,aligned));assert(aligned[0]==17);
    /* BGR channel preservation, fixed-point normalization and saturation. */
    f=face();for(int i=0;i<160*160;i++){image[3*i]=0;image[3*i+1]=128;image[3*i+2]=255;}
    assert(!fg_align(image,160,160,480,&f,5,aligned));assert(aligned[0]==-32&&aligned[1]==0&&aligned[2]==32);
    assert(!fg_align(image,160,160,480,&f,6,aligned));assert(aligned[0]==-64&&aligned[1]==0&&aligned[2]==64);
    assert(!fg_align(image,160,160,480,&f,7,aligned));assert(aligned[0]==-128&&aligned[1]==1&&aligned[2]==127);
    /* Compare a fitted scale/rotation with an independent float sampler. */
    double aa=.75*cos(.12),bb=.75*sin(.12);
    for(int i=0;i<5;i++){
        double x=f.landmarks[2*i]-20,y=f.landmarks[2*i+1]-20;
        f.landmarks[2*i]=(float)(aa*x-bb*y+30);f.landmarks[2*i+1]=(float)(bb*x+aa*y+15);
    }
    for(int y=0;y<160;y++)for(int x=0;x<160;x++)for(int ch=0;ch<3;ch++)image[(y*160+x)*3+ch]=(uint8_t)((x+y+ch*15)%256);
    assert(!fg_align(image,160,160,480,&f,5,aligned));
    for(int y=0;y<FG_HEIGHT;y++)for(int x=0;x<FG_WIDTH;x++){
        double sx=aa*(x+8)-bb*y+30,sy=bb*(x+8)+aa*y+15;
        int ix=(int)sx,iy=(int)sy;double fx=sx-ix,fy=sy-iy;
        for(int ch=0;ch<3;ch++){
            const uint8_t *p=image+(iy*160+ix)*3+ch;
            double v=p[0]*(1-fx)*(1-fy)+p[3]*fx*(1-fy)+p[480]*(1-fx)*fy+p[483]*fx*fy;
            int q=(int)lround((2*lround(v)-255)/255.*32);
            if(q< -128)q=-128;
            if(q>127)q=127;
            assert(abs(aligned[(y*FG_WIDTH+x)*3+ch]-q)<=1);
        }
    }
    puts("FaceGuard quality/alignment checks passed");return 0;
}
