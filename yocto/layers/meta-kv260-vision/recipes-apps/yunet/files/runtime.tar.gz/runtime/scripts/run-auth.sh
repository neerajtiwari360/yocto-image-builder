#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -d lib ]; then
    export LD_LIBRARY_PATH="$PWD/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi
exec ./bin/yunet-kv260 --config config/yunet.conf \
    --auth-database "${FACEGUARD_DATABASE:-/var/lib/faceguard/users.db}" \
    --auth-key "${FACEGUARD_KEY:-/etc/faceguard/faceguard.key}" \
    --auth-policy "${FACEGUARD_POLICY:-/etc/faceguard/policy.json}" \
    --auth-permission "${FACEGUARD_PERMISSION:-front-door}" "$@"
