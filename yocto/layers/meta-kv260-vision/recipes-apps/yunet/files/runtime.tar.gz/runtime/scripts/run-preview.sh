#!/bin/sh
# Quality feedback always works; matching starts only with provisioned files.
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ "${FACEGUARD_TEST_MODE:-0}" = 1 ]; then
    set -- "$@" --preview-test-mode
fi
if [ -n "${FACEGUARD_QUALITY_CONFIG:-}" ]; then
    set -- "$@" --quality-config "$FACEGUARD_QUALITY_CONFIG"
fi
if [ -f "${FACEGUARD_DATABASE:-/var/lib/faceguard/users.db}" ] &&
   [ -f "${FACEGUARD_KEY:-/etc/faceguard/faceguard.key}" ] &&
   [ -f "${FACEGUARD_POLICY:-/etc/faceguard/policy.json}" ]; then
    exec ./run-auth.sh "$@"
fi
exec ./run.sh "$@"
