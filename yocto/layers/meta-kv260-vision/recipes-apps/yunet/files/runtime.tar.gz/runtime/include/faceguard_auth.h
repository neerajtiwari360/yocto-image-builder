#ifndef FACEGUARD_AUTH_H
#define FACEGUARD_AUTH_H
#include <stdint.h>
typedef struct fg_auth_context fg_auth_context;
/* Native reader for the AES-GCM/SQLite format created by authentication/. */
int fg_auth_open(const char *database,const char *key,const char *policy,const char *model,
                 const char *permission,const char *claim,fg_auth_context **out);
/* Returns an allocated JSON decision; caller frees it. Errors fail closed. */
int fg_auth_match(fg_auth_context *ctx,const int8_t *embedding,char **decision);
void fg_auth_close(fg_auth_context *ctx);
#endif
