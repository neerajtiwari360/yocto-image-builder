#include "yunet.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static int clamp(int x,int lo,int hi) { return x<lo?lo:(x>hi?hi:x); }
static float dequant(const yunet_head *h,size_t offset) {
    return ldexpf((float)h->data[offset],-h->fix_point);
}
static float sigmoid(float x) {
    if(x>=0) return 1.0f/(1.0f+expf(-x));
    float e=expf(x); return e/(1.0f+e);
}

int yunet_preprocess(const uint8_t *src,int w,int h,size_t stride,int fix,
                     int8_t *dst,yunet_transform *tr) {
    if(!src||!dst||!tr||w<=0||h<=0||w>16384||h>16384||
       stride<(size_t)w*3||fix < -16||fix>16) return -1;
    double scale=320.0/(w>h?w:h);
    /* nearbyint uses nearest/even, matching Python round used by the reference. */
    int rw=(int)nearbyint(w*scale), rh=(int)nearbyint(h*scale);
    if(rw<1)rw=1;
    if(rh<1)rh=1;
    memset(dst,0,320*320*3);
    for(int y=0;y<rh;y++) {
        double sy=((y+.5)*h/rh)-.5;
        int y0=(int)floor(sy), y1=y0+1;
        double fy=sy-y0;
        y0=clamp(y0,0,h-1); y1=clamp(y1,0,h-1);
        for(int x=0;x<rw;x++) {
            double sx=((x+.5)*w/rw)-.5;
            int x0=(int)floor(sx),x1=x0+1;
            double fx=sx-x0;
            x0=clamp(x0,0,w-1); x1=clamp(x1,0,w-1);
            for(int c=0;c<3;c++) {
                double top=src[(size_t)y0*stride+x0*3+c]*(1-fx)+src[(size_t)y0*stride+x1*3+c]*fx;
                double bottom=src[(size_t)y1*stride+x0*3+c]*(1-fx)+src[(size_t)y1*stride+x1*3+c]*fx;
                int pixel=clamp((int)floor(top*(1-fy)+bottom*fy+.5),0,255);
                int q=(int)floor(ldexp((double)pixel,fix)+.5);
                dst[((size_t)y*320+x)*3+c]=(int8_t)clamp(q,-128,127);
            }
        }
    }
    *tr=(yunet_transform){w,h,rw,rh}; return 0;
}

static int compare_faces(const void *va,const void *vb) {
    const yunet_face *a=va,*b=vb;
    if(a->score>b->score)return -1;
    if(a->score<b->score)return 1;
    /* Deterministic tie order independent of libc qsort implementation. */
    if(a->y<b->y)return -1;
    if(a->y>b->y)return 1;
    if(a->x<b->x)return -1;
    if(a->x>b->x)return 1;
    return 0;
}
static float iou(const yunet_face *a,const yunet_face *b) {
    float w=fmaxf(0,fminf(a->x+a->w,b->x+b->w)-fmaxf(a->x,b->x));
    float h=fmaxf(0,fminf(a->y+a->h,b->y+b->h)-fmaxf(a->y,b->y));
    float intersection=w*h,area=a->w*a->h+b->w*b->h-intersection;
    return area>0?intersection/area:0;
}
int yunet_decode(const yunet_head hs[12],float threshold,float nms,
                 const yunet_transform *tr,yunet_face *out,size_t cap,size_t *count) {
    if(count)*count=0;
    if(!hs||!tr||!out||!count||!cap||!isfinite(threshold)||threshold<=0||threshold>1||
       !isfinite(nms)||nms<0||nms>1||tr->resized_width<1||tr->resized_height<1||
       tr->width<1||tr->height<1) return -1;
    const int channels[4]={1,1,4,10};
    for(int j=0;j<12;j++) {
        int side=40>>(j%3);
        if(!hs[j].data||hs[j].height!=side||hs[j].width!=side||
           hs[j].channels!=channels[j/3]||hs[j].fix_point < -16||hs[j].fix_point>16) return -1;
    }
    yunet_face *candidates=malloc(sizeof(*candidates)*YUNET_MAX_CANDIDATES);
    if(!candidates)return -1;
    size_t n=0;
    for(int level=0;level<3;level++) {
        int side=40>>level,stride=8<<level;
        for(int y=0;y<side;y++)for(int x=0;x<side;x++) {
            size_t p=(size_t)y*side+x;
            float score=sqrtf(sigmoid(dequant(&hs[level],p))*sigmoid(dequant(&hs[level+3],p)));
            if(score<threshold)continue;
            float cx=(dequant(&hs[level+6],p*4)+x)*stride;
            float cy=(dequant(&hs[level+6],p*4+1)+y)*stride;
            float bw=expf(dequant(&hs[level+6],p*4+2))*stride;
            float bh=expf(dequant(&hs[level+6],p*4+3))*stride;
            if(!isfinite(bw)||!isfinite(bh)||!isfinite(cx)||!isfinite(cy))continue;
            yunet_face *f=&candidates[n++];
            *f=(yunet_face){.x=cx-bw/2,.y=cy-bh/2,.w=bw,.h=bh,.score=score};
            for(int k=0;k<5;k++) {
                f->landmarks[k*2]=(dequant(&hs[level+9],p*10+k*2)+x)*stride;
                f->landmarks[k*2+1]=(dequant(&hs[level+9],p*10+k*2+1)+y)*stride;
            }
        }
    }
    qsort(candidates,n,sizeof(*candidates),compare_faces);
    size_t used=0;
    for(size_t i=0;i<n&&used<cap;i++) {
        int suppress=0;
        for(size_t j=0;j<used;j++)if(iou(&candidates[i],&out[j])>nms){suppress=1;break;}
        if(!suppress)out[used++]=candidates[i];
    }
    free(candidates);
    float sx=(float)tr->width/tr->resized_width,sy=(float)tr->height/tr->resized_height;
    for(size_t i=0;i<used;i++) {
        out[i].x*=sx;out[i].w*=sx;out[i].y*=sy;out[i].h*=sy;
        for(int k=0;k<5;k++){out[i].landmarks[k*2]*=sx;out[i].landmarks[k*2+1]*=sy;}
    }
    *count=used;return 0;
}

int yunet_nv12_to_bgr(const uint8_t *y,size_t yl,size_t ys,const uint8_t *uv,
                      size_t uvl,size_t uvs,int w,int h,int matrix,int full,uint8_t *bgr) {
    if(!y||!uv||!bgr||w<=0||h<=0||w>16384||h>16384||(w&1)||(h&1)||
       ys>SIZE_MAX/(size_t)h||uvs>SIZE_MAX/(size_t)h||ys<(size_t)w||uvs<(size_t)w||
       yl<ys*(size_t)(h-1)+(size_t)w||uvl<uvs*(size_t)(h/2-1)+(size_t)w||
       (matrix!=601&&matrix!=709)||(full!=0&&full!=1)) return -1;
    int cy=full?256:298;
    int cb=matrix==601?(full?454:516):(full?475:541);
    int cgu=matrix==601?(full?88:100):(full?48:55);
    int cgv=matrix==601?(full?183:208):(full?120:136);
    int cr=matrix==601?(full?359:409):(full?403:459);
    for(int row=0;row<h;row++)for(int x=0;x<w;x++) {
        int yy=(int)y[(size_t)row*ys+x]-(full?0:16);
        int u=(int)uv[(size_t)(row/2)*uvs+(x&~1)]-128;
        int v=(int)uv[(size_t)(row/2)*uvs+(x&~1)+1]-128;
        if(yy<0)yy=0;
        size_t p=((size_t)row*w+x)*3;
        bgr[p]=(uint8_t)clamp((cy*yy+cb*u+128)>>8,0,255);
        bgr[p+1]=(uint8_t)clamp((cy*yy-cgu*u-cgv*v+128)>>8,0,255);
        bgr[p+2]=(uint8_t)clamp((cy*yy+cr*v+128)>>8,0,255);
    }
    return 0;
}

/* Convert only the four source pixels used by a model-input sample. Saturating
 * each source pixel before interpolation preserves the reference RGB semantics. */
static void nv12_pixel(const uint8_t *y,const uint8_t *uv,size_t ys,size_t uvs,
                       int x,int row,int cy,int cb,int cgu,int cgv,int cr,int offset,
                       uint8_t bgr[3]) {
    int yy=(int)y[(size_t)row*ys+x]-offset;
    int u=(int)uv[(size_t)(row/2)*uvs+(x&~1)]-128;
    int v=(int)uv[(size_t)(row/2)*uvs+(x&~1)+1]-128;
    if(yy<0)yy=0;
    bgr[0]=(uint8_t)clamp((cy*yy+cb*u+128)>>8,0,255);
    bgr[1]=(uint8_t)clamp((cy*yy-cgu*u-cgv*v+128)>>8,0,255);
    bgr[2]=(uint8_t)clamp((cy*yy+cr*v+128)>>8,0,255);
}
int yunet_preprocess_nv12(const uint8_t *y,size_t yl,size_t ys,const uint8_t *uv,
                         size_t uvl,size_t uvs,int w,int h,int matrix,int full,
                         int fix,int8_t *dst,yunet_transform *tr) {
    if(!y||!uv||!dst||!tr||w<2||h<2||w>16384||h>16384||(w&1)||(h&1)||
       ys>SIZE_MAX/(size_t)h||uvs>SIZE_MAX/(size_t)h||ys<(size_t)w||uvs<(size_t)w||
       yl<ys*(size_t)(h-1)+(size_t)w||uvl<uvs*(size_t)(h/2-1)+(size_t)w||
       (matrix!=601&&matrix!=709)||(full!=0&&full!=1)||fix < -16||fix>16)return -1;
    double scale=320.0/(w>h?w:h);
    int rw=(int)nearbyint(w*scale),rh=(int)nearbyint(h*scale);
    if(rw<1)rw=1;
    if(rh<1)rh=1;
    int cy=full?256:298,cb=matrix==601?(full?454:516):(full?475:541);
    int cgu=matrix==601?(full?88:100):(full?48:55);
    int cgv=matrix==601?(full?183:208):(full?120:136);
    int cr=matrix==601?(full?359:409):(full?403:459);
    int8_t quant[256];
    for(int i=0;i<256;i++)quant[i]=(int8_t)clamp((int)floor(ldexp((double)i,fix)+.5),-128,127);
    memset(dst,0,320*320*3);
    /* At 1280x720 -> 320x180, all four bilinear weights are exactly 1/4.
     * This integer path is also valid for any equal, even integer downscale. */
    int factor=w/rw;
    if(factor>=2 && !(factor&1) && w==rw*factor && h==rh*factor) {
        for(int row=0;row<rh;row++)for(int x=0;x<rw;x++) {
            int sx=x*factor+factor/2-1,sy=row*factor+factor/2-1;
            uint8_t a[3],b[3],c[3],d[3];
            nv12_pixel(y,uv,ys,uvs,sx,sy,cy,cb,cgu,cgv,cr,full?0:16,a);
            nv12_pixel(y,uv,ys,uvs,sx+1,sy,cy,cb,cgu,cgv,cr,full?0:16,b);
            nv12_pixel(y,uv,ys,uvs,sx,sy+1,cy,cb,cgu,cgv,cr,full?0:16,c);
            nv12_pixel(y,uv,ys,uvs,sx+1,sy+1,cy,cb,cgu,cgv,cr,full?0:16,d);
            for(int k=0;k<3;k++)dst[((size_t)row*320+x)*3+k]=quant[(a[k]+b[k]+c[k]+d[k]+2)>>2];
        }
    }else{
        for(int row=0;row<rh;row++) {
            double sy=((row+.5)*h/rh)-.5;
            int y0=(int)floor(sy),y1=y0+1;double fy=sy-y0;
            y0=clamp(y0,0,h-1);y1=clamp(y1,0,h-1);
            for(int x=0;x<rw;x++) {
                double sx=((x+.5)*w/rw)-.5;
                int x0=(int)floor(sx),x1=x0+1;double fx=sx-x0;
                x0=clamp(x0,0,w-1);x1=clamp(x1,0,w-1);
                uint8_t a[3],b[3],c[3],d[3];
                nv12_pixel(y,uv,ys,uvs,x0,y0,cy,cb,cgu,cgv,cr,full?0:16,a);
                nv12_pixel(y,uv,ys,uvs,x1,y0,cy,cb,cgu,cgv,cr,full?0:16,b);
                nv12_pixel(y,uv,ys,uvs,x0,y1,cy,cb,cgu,cgv,cr,full?0:16,c);
                nv12_pixel(y,uv,ys,uvs,x1,y1,cy,cb,cgu,cgv,cr,full?0:16,d);
                for(int k=0;k<3;k++){
                    double top=a[k]*(1-fx)+b[k]*fx,bottom=c[k]*(1-fx)+d[k]*fx;
                    int pixel=clamp((int)floor(top*(1-fy)+bottom*fy+.5),0,255);
                    dst[((size_t)row*320+x)*3+k]=quant[pixel];
                }
            }
        }
    }
    *tr=(yunet_transform){w,h,rw,rh};return 0;
}
