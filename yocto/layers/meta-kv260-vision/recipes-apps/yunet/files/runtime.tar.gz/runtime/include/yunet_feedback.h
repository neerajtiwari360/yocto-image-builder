#ifndef YUNET_FEEDBACK_H
#define YUNET_FEEDBACK_H
#include <stdint.h>
/* Frame-local display information only. No embeddings, identities or decisions
 * from older frames may be reused for authentication. */
enum {
    YUNET_FEEDBACK_OFF, YUNET_FEEDBACK_NO_FACE, YUNET_FEEDBACK_MULTIPLE,
    YUNET_FEEDBACK_ADJUST, YUNET_FEEDBACK_READY,
    YUNET_FEEDBACK_MATCH, YUNET_FEEDBACK_NO_MATCH
};
typedef struct {
    uint32_t state,quality_flags;
    float mean,sharpness,roll,yaw,pitch,landmark_error,match_score;
    uint32_t test_mode;
} yunet_feedback;
_Static_assert(sizeof(yunet_feedback)==40,"Feedback ABI changed");
#endif
