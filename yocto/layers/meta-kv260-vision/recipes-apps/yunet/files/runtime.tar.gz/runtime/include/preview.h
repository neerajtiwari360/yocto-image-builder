#ifndef YUNET_PREVIEW_H
#define YUNET_PREVIEW_H
#include "yunet.h"
#include <stdatomic.h>
#include <stdint.h>
#define PREVIEW_PATH "/run/yunet-preview.shm"
#define PREVIEW_MAGIC 0x59565032u
#define PREVIEW_VERSION 1u
#define PREVIEW_SLOTS 3
#define PREVIEW_WIDTH 1280
#define PREVIEW_HEIGHT 720
#define PREVIEW_BYTES (PREVIEW_WIDTH * PREVIEW_HEIGHT * 3 / 2)
#define PREVIEW_FACES 100
enum { PREVIEW_FREE, PREVIEW_WRITING, PREVIEW_READY, PREVIEW_READING };
typedef struct {
    _Alignas(64) _Atomic uint32_t state;
    uint32_t width,height,matrix,full_range,count;
    uint64_t sequence,capture_ns;
    yunet_face faces[PREVIEW_FACES];
    _Alignas(64) uint8_t pixels[PREVIEW_BYTES];
} preview_slot;
typedef struct {
    _Alignas(64) _Atomic uint32_t magic;
    uint32_t version,bytes,fps;
    _Atomic uint64_t heartbeat_ns;
    preview_slot slots[PREVIEW_SLOTS];
} preview_mailbox;
typedef struct {
    preview_mailbox *map;
    int fd,slot;
    uint64_t next_probe_ns,next_frame_ns,published,dropped;
} preview_writer;
#define PREVIEW_WRITER_INIT { .fd=-1, .slot=-1 }
uint64_t preview_now_ns(void);
/* All operations are bounded. No waits, reader locks, camera ownership or DRM. */
uint8_t *preview_begin(preview_writer *p,int width,int height,uint64_t now_ns);
void preview_publish(preview_writer *p,int matrix,int full_range,
                     const yunet_face *faces,size_t count,uint64_t sequence,uint64_t capture_ns);
void preview_writer_close(preview_writer *p);
/* Viewer claims one complete frame+metadata pair; producer cannot touch READING. */
int preview_take_latest(preview_mailbox *map);
void preview_release(preview_mailbox *map,int slot);
#endif
