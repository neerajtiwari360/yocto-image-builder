#include "config.h"
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char *trim(char *s) {
    while(isspace((unsigned char)*s))s++;
    char *e=s+strlen(s);while(e>s&&isspace((unsigned char)e[-1]))*--e=0;return s;
}
static int text(char *dst,size_t n,const char *src) {
    size_t len=strlen(src);if(!len||len>=n)return -1;memcpy(dst,src,len+1);return 0;
}
static int integer(const char *v,int *out) {
    char *e;errno=0;long x=strtol(v,&e,10);
    if(errno||*e||x<2||x>16384||(x&1))return -1;
    *out=(int)x;return 0;
}
static int fraction(const char *v,float *out) {
    char *e;errno=0;float f=strtof(v,&e);
    if(errno||*e||!isfinite(f)||f<=0||f>1)return -1;
    *out=f;return 0;
}
int config_load(const char *path,app_config *c) {
    if(!path||!c)return -1;
    memset(c,0,sizeof(*c));c->width=1280;c->height=720;c->score=.9f;c->nms=.3f;
    strcpy(c->device,"auto");
    strcpy(c->firmware,"/lib/firmware/xilinx/kv260-smartcam/kv260-smartcam.xclbin");
    FILE *f=fopen(path,"r");if(!f){perror(path);return -1;}
    const char *heads[12]={"cls_8","cls_16","cls_32","obj_8","obj_16","obj_32","bbox_8","bbox_16","bbox_32","kps_8","kps_16","kps_32"};
    char line[1024];unsigned number=0;int result=-1;
    while(fgets(line,sizeof(line),f)) {
        number++;
        if(!strchr(line,'\n')&&!feof(f))goto invalid;
        char *key=trim(line);if(!*key||*key=='#')continue;
        char *eq=strchr(key,'=');if(!eq)goto invalid;*eq=0;key=trim(key);char *value=trim(eq+1);
        if(!strcmp(key,"model")){if(text(c->model,sizeof(c->model),value))goto invalid;}
        else if(!strcmp(key,"firmware")){if(text(c->firmware,sizeof(c->firmware),value))goto invalid;}
        else if(!strcmp(key,"device")){if(text(c->device,sizeof(c->device),value))goto invalid;}
        else if(!strcmp(key,"width")){if(integer(value,&c->width))goto invalid;}
        else if(!strcmp(key,"height")){if(integer(value,&c->height))goto invalid;}
        else if(!strcmp(key,"score")){if(fraction(value,&c->score))goto invalid;}
        else if(!strcmp(key,"nms")){if(fraction(value,&c->nms))goto invalid;}
        else if(!strcmp(key,"fingerprint")) {
            char *e;errno=0;c->fingerprint=strtoull(value,&e,0);
            if(errno||*e||!c->fingerprint)goto invalid;
        }else {
            int found=0;
            for(int i=0;i<12;i++)if(!strcmp(key,heads[i])) {
                if(text(c->head[i],sizeof(c->head[i]),value))goto invalid;
                if(strncmp(value,"op",2)||!isdigit((unsigned char)value[2]))goto invalid;
                for(size_t j=2;value[j];j++)if(!isdigit((unsigned char)value[j]))goto invalid;
                found=1;break;
            }
            if(!found)goto invalid;
        }
    }
    if(ferror(f)||!c->model[0]||!c->fingerprint)goto invalid;
    for(int i=0;i<12;i++) {
        if(!c->head[i][0])goto invalid;
        for(int j=0;j<i;j++)if(!strcmp(c->head[i],c->head[j]))goto invalid;
    }
    result=0;goto done;
invalid:
    fprintf(stderr,"Invalid/incomplete config %s near line %u\n",path,number);
done:
    fclose(f);return result;
}
