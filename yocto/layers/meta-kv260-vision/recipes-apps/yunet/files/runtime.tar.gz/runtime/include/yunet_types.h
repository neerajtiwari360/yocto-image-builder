#ifndef YUNET_TYPES_H
#define YUNET_TYPES_H
#include <stddef.h>
#include <stdint.h>
#include "yunet_version.h"
#define YUNET_SIDE 320
#define YUNET_HEADS 12
#define YUNET_MAX_CANDIDATES 2100
typedef struct { float x,y,w,h,landmarks[10],score; } yunet_face;
typedef struct { int width,height,resized_width,resized_height; } yunet_transform;
typedef struct {
    const int8_t *data; /* NHWC contiguous, one batch */
    int height,width,channels,fix_point;
} yunet_head;
#endif
