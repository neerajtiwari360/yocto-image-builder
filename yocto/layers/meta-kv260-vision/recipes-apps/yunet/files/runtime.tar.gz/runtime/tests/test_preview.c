#define _POSIX_C_SOURCE 200809L
#include "preview_render.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
/* A process-shared producer/consumer stress test: frame, metadata and every
 * pixel must remain one pair even while READY slots are aggressively replaced. */
static void stress(preview_mailbox *m) {
    pid_t pid=fork();assert(pid>=0);
    if(!pid){
        for(uint64_t n=1;n<=30000;n++){
            for(int i=0;i<PREVIEW_SLOTS;i++){
                uint32_t expected=PREVIEW_FREE;
                if(!atomic_compare_exchange_strong(&m->slots[i].state,&expected,PREVIEW_WRITING)){
                    expected=PREVIEW_READY;
                    if(!atomic_compare_exchange_strong(&m->slots[i].state,&expected,PREVIEW_WRITING))continue;
                }
                preview_slot *s=&m->slots[i];s->sequence=n;s->capture_ns=n;s->count=(uint32_t)(n%100);
                s->feedback.quality_flags=(uint32_t)n;
                memset(s->pixels,(unsigned char)n,4096);
                atomic_store_explicit(&s->state,PREVIEW_READY,memory_order_release);break;
            }
        }
        atomic_store_explicit(&m->heartbeat_ns,1,memory_order_release);_exit(0);
    }
    unsigned reads=0;int finished;
    do {
        finished=atomic_load_explicit(&m->heartbeat_ns,memory_order_acquire)!=0;
        int slot=preview_take_latest(m);
        if(slot>=0){
            preview_slot *s=&m->slots[slot];assert(s->count==s->sequence%100);
            assert(s->feedback.quality_flags==s->sequence);
            for(int j=0;j<4096;j++)assert(s->pixels[j]==(uint8_t)s->sequence);
            reads++;preview_release(m,slot);
        }
    }while(!finished);
    int status;assert(waitpid(pid,&status,0)==pid&&WIFEXITED(status)&&!WEXITSTATUS(status));assert(reads>0);
    printf("Preview ownership stress: %u paired frames read\n",reads);
}
int main(void) {
    char name[]="/tmp/yunet-preview-test-XXXXXX";int fd=mkstemp(name);assert(fd>=0);unlink(name);
    assert(!ftruncate(fd,sizeof(preview_mailbox)));
    preview_mailbox *m=mmap(NULL,sizeof(*m),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);assert(m!=MAP_FAILED);memset(m,0,sizeof(*m));
    for(int i=0;i<PREVIEW_SLOTS;i++)atomic_init(&m->slots[i].state,PREVIEW_FREE);
    atomic_init(&m->heartbeat_ns,0);atomic_init(&m->magic,PREVIEW_MAGIC);
    stress(m);
    /* All slots held by a reader must make publication return immediately. */
    preview_writer writer=PREVIEW_WRITER_INIT;
    writer.map=m;writer.next_frame_ns=0;m->fps=30;
    uint64_t ns=preview_now_ns();atomic_store(&m->heartbeat_ns,ns);
    for(int i=0;i<PREVIEW_SLOTS;i++)atomic_store(&m->slots[i].state,PREVIEW_READING);
    assert(!preview_begin(&writer,1280,720,ns));assert(writer.dropped==1);
    /* One released slot can be claimed, paired, then read without a copy. */
    preview_release(m,1);ns+=40000000;atomic_store(&m->heartbeat_ns,ns);
    uint8_t *pixels=preview_begin(&writer,1280,720,ns);assert(pixels==m->slots[1].pixels);
    assert(atomic_load(&m->slots[1].state)==PREVIEW_WRITING);
    pixels[0]=77;yunet_face face={.x=42};
    yunet_feedback feedback={.state=YUNET_FEEDBACK_ADJUST,.quality_flags=4};
    preview_publish_feedback(&writer,709,0,&face,1,123,ns,&feedback);
    assert(atomic_load(&m->slots[1].state)==PREVIEW_READY);
    int claimed=preview_take_latest(m);assert(claimed==1);
    assert(m->slots[claimed].pixels[0]==77&&m->slots[claimed].faces[0].x==42&&m->slots[claimed].sequence==123);
    assert(m->slots[claimed].feedback.state==YUNET_FEEDBACK_ADJUST&&m->slots[claimed].feedback.quality_flags==4);
    preview_release(m,claimed);writer.map=NULL;
    /* A restarted ML process has a lower counter but a newer acquisition time. */
    m->slots[0].sequence=900;m->slots[0].capture_ns=100;
    m->slots[1].sequence=1;m->slots[1].capture_ns=200;
    atomic_store(&m->slots[0].state,PREVIEW_READY);atomic_store(&m->slots[1].state,PREVIEW_READY);
    claimed=preview_take_latest(m);assert(claimed==1);preview_release(m,claimed);

    for(int i=0;i<PREVIEW_SLOTS;i++)atomic_store(&m->slots[i].state,PREVIEW_READING);
    assert(preview_take_latest(m)==-1); /* never claim an owned reader buffer */
    preview_slot *s=&m->slots[0];s->width=1280;s->height=720;s->count=1;
    memset(s->pixels,90,1280*720);memset(s->pixels+1280*720,128,1280*720/2);
    s->faces[0]=(yunet_face){.x=100,.y=100,.w=200,.h=200,.landmarks={200,200,220,200,210,220,200,240,220,240}};
    size_t bytes=640*480*3/2;uint8_t *out=malloc(bytes+32);assert(out);memset(out,0xa5,bytes+32);
    assert(!preview_render_nv12(s,out,bytes,640,480,640));
    assert(out[0]==16&&out[60*640]==90); /* letterbox */
    assert(out[110*640+50]==145); /* transformed top-left box corner */
    assert(out[160*640+100]==210); /* transformed first landmark */
    for(int i=0;i<32;i++)assert(out[bytes+i]==0xa5);
    assert(!preview_render_split_nv12(s,out,bytes,640,480,640,1));
    assert(out[175*640+25]==90);       /* left remains clean */
    assert(out[175*640+345]==145);     /* box transformed into right panel */
    assert(out[200*640+370]==210);     /* right first landmark */
    assert(out[200*640+50]==90);       /* corresponding left pixel unmarked */
    for(int y=150;y<330;y++)for(int x=0;x<318;x++)assert(out[y*640+x]==90);
    assert(!preview_render_split_nv12(s,out,bytes,640,480,640,0));
    assert(out[175*640+345]==90);      /* no fabricated overlay when ML is off */
    for(int i=0;i<32;i++)assert(out[bytes+i]==0xa5);
    assert(preview_render_split_nv12(s,out,bytes,638,480,640,1)==-1);
    /* Clipped boxes/landmarks at the split boundary cannot mark the raw panel. */
    s->faces[0]=(yunet_face){.x=0,.y=0,.w=1,.h=1,.landmarks={0,0,0,0,0,0,0,0,0,0}};
    assert(!preview_render_split_nv12(s,out,bytes,640,480,640,1));
    for(int y=150;y<330;y++)for(int x=0;x<318;x++)assert(out[y*640+x]==90);
    s->faces[0].x=NAN;s->faces[0].landmarks[0]=INFINITY;
    assert(!preview_render_nv12(s,out,bytes,640,480,640));
    assert(preview_render_nv12(s,out,bytes-1,640,480,640)==-1);
    s->width=PREVIEW_WIDTH+2;assert(preview_render_nv12(s,out,bytes,640,480,640)==-1);
    free(out);munmap(m,sizeof(*m));close(fd);puts("Preview renderer and ownership tests passed");return 0;
}
