#ifndef YUNET_VERSION_H
#define YUNET_VERSION_H
#include <stdint.h>
/* Major: incompatible API/semantics; minor: additive; patch: compatible fix.
 * Preprocess/postprocess legacy C APIs are frozen as version 1. */
#define YUNET_API_VERSION_MAJOR 1
#define YUNET_API_VERSION_MINOR 0
#define YUNET_API_VERSION_PATCH 0
#define YUNET_PREPROCESS_API_VERSION 1
#define YUNET_POSTPROCESS_API_VERSION 1
#define YUNET_OVERLAY_API_VERSION 1
#define YUNET_CAMERA_API_VERSION 1
#define YUNET_DPU_API_VERSION 1
#define YUNET_IPC_API_VERSION 1
#define YUNET_PREVIEW_SCHEMA_VERSION 1u
#define YUNET_PLATFORM_ID "kv260-smartcam-b3136-v1"
#define YUNET_DPU_FINGERPRINT UINT64_C(0x101000016010406)
#endif
