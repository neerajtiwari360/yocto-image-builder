#ifndef YUNET_OVERLAY_H
#define YUNET_OVERLAY_H
#include "yunet_types.h"
#define YUNET_OVERLAY_MAX_WIDTH 1280
#define YUNET_OVERLAY_MAX_HEIGHT 720
#define YUNET_OVERLAY_MAX_FACES 100
#ifdef __cplusplus
extern "C" {
#endif
/* Borrowed tightly packed NV12, Y followed by interleaved UV. No ownership,
 * mailbox, device or lifetime management. Faces use original-image pixels.
 * Input and output buffers must not overlap. Source stays immutable. */
typedef struct {
    uint32_t width,height,matrix,full_range,count;
    const yunet_face *faces;
    const uint8_t *pixels;
    size_t length;
} yunet_overlay_frame;
/* Caller owns destination, pitch >= width; needs pitch*height*3/2 bytes.
 * Returns zero on success, -1 on invalid dimensions/length/count. */
int yunet_overlay_nv12(const yunet_overlay_frame *,uint8_t *,size_t,int,int,size_t);
int yunet_overlay_split_nv12(const yunet_overlay_frame *,uint8_t *,size_t,int,int,size_t,int);
#ifdef __cplusplus
}
#endif
#endif
