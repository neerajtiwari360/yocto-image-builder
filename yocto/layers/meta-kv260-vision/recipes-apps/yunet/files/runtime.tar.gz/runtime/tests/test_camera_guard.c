#define _POSIX_C_SOURCE 200809L
#include "camera_guard.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
int main(void) {
    char path[]="/tmp/yunet-camera-guard-XXXXXX";
    int fd=mkstemp(path);assert(fd>=0);assert(!camera_guard_claim(fd,0));
    pid_t child=fork();assert(child>=0);
    if(!child){
        close(fd);int other=camera_guard_open(path);assert(other>=0);
        assert(camera_guard_claim(other,0)==-1);close(other);_exit(0);
    }
    int status;assert(waitpid(child,&status,0)==child&&WIFEXITED(status)&&!WEXITSTATUS(status));close(fd);
    child=fork();assert(child>=0);
    if(!child){int other=camera_guard_open(path);assert(other>=0);assert(!camera_guard_claim(other,0));_exit(0);}
    assert(waitpid(child,&status,0)==child&&WIFEXITED(status)&&!WEXITSTATUS(status));
    fd=camera_guard_open(path);assert(fd>=0);assert(!camera_guard_claim(fd,0));close(fd);unlink(path);
    puts("Camera ownership: competing process excluded; dead owner releases lock");return 0;
}
