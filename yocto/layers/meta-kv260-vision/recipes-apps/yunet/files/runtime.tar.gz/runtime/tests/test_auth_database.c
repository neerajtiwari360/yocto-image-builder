#include "faceguard_auth.h"
#include "faceguard.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
/* Args: database key policy model. Fixtures are produced by the Python writer. */
int main(int argc,char **argv){
    assert(argc==5);
    const char *permissions[]={"door","lab","door"};
    const char *claims[]={NULL,NULL,"Bob"};
    for(int test=0;test<3;test++){
        fg_auth_context *ctx=NULL;char *decision=NULL;int8_t query[FG_DIM]={0};query[0]=100;
        assert(!fg_auth_open(argv[1],argv[2],argv[3],argv[4],permissions[test],claims[test],&ctx));
        assert(!fg_auth_match(ctx,query,&decision));
        assert(strstr(decision,test?"\"accepted\":false":"\"accepted\":true"));
        free(decision);fg_auth_close(ctx);
    }
    fg_auth_context *ctx=NULL;char *decision=NULL;int8_t zero[FG_DIM]={0};
    assert(fg_auth_open(argv[1],argv[2],argv[3],argv[2],"door",NULL,&ctx));
    assert(!fg_auth_open(argv[1],argv[2],argv[3],argv[4],"door",NULL,&ctx));
    assert(fg_auth_match(ctx,zero,&decision));fg_auth_close(ctx);
    sqlite3 *writer=NULL;
    assert(sqlite3_open(argv[1],&writer)==SQLITE_OK);
    assert(sqlite3_exec(writer,"UPDATE templates SET payload=zeroblob(length(payload)) WHERE id!='contract'",NULL,NULL,NULL)==SQLITE_OK);
    sqlite3_close(writer);
    assert(!fg_auth_open(argv[1],argv[2],argv[3],argv[4],"door",NULL,&ctx));
    zero[0]=100;assert(fg_auth_match(ctx,zero,&decision));fg_auth_close(ctx);
    puts("Native AES-GCM/SQLite cross-language decisions passed");return 0;
}
