#include "capture.h"
#include "camera_guard.h"
#include <unistd.h>
#include "config.h"
#include "dpu_bridge.h"
#include "yunet.h"
#include "preview.h"
#include "faceguard.h"
#ifdef FACEGUARD_DATABASE
#include "faceguard_auth.h"
#include <json-c/json.h>
#endif
#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

static volatile sig_atomic_t stop;
static int quality_config_load(const char *path,fg_quality_config *config){
    FILE *stream=fopen(path,"r");if(!stream){perror(path);return -1;}
    char line[256],key[64],tail;float value;int result=0;
    const char *names[]={"min_size","min_mean","max_mean","min_laplacian_variance","max_roll","max_yaw_proxy","max_landmark_error","min_region_variance","min_pitch_proxy","max_pitch_proxy","min_score","max_size_fraction"};
    float *fields[]={&config->min_size,&config->min_mean,&config->max_mean,&config->min_laplacian_variance,&config->max_roll,&config->max_yaw_proxy,&config->max_landmark_error,&config->min_region_variance,&config->min_pitch_proxy,&config->max_pitch_proxy,&config->min_score,&config->max_size_fraction};
    while(fgets(line,sizeof(line),stream)){
        char *start=line;while(isspace((unsigned char)*start))start++;
        if(!*start||*start=='#')continue;
        if(sscanf(start,"%63[^=]=%f %c",key,&value,&tail)!=2||!isfinite(value)||value<0){result=-1;break;}
        size_t i;for(i=0;i<sizeof(fields)/sizeof(fields[0]);i++)if(!strcmp(key,names[i])){*fields[i]=value;break;}
        if(i==sizeof(fields)/sizeof(fields[0])){result=-1;break;}
    }
    if(ferror(stream))result=-1;
    fclose(stream);return result;
}
static void stopped(int value){(void)value;stop=1;}
static double now(void) {
    struct timespec ts;if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
    return ts.tv_sec+ts.tv_nsec/1e9;
}
static int token(FILE *f,char *out,size_t n) {
    int ch;do {
        ch=fgetc(f);
        if(ch=='#')while(ch!='\n'&&ch!=EOF)ch=fgetc(f);
    }while(ch!=EOF&&isspace((unsigned char)ch));
    size_t i=0;
    while(ch!=EOF&&!isspace((unsigned char)ch)) {
        if(i+1>=n)return -1;
        out[i++]=(char)ch;ch=fgetc(f);
    }
    if(ch=='\r'){int next=fgetc(f);if(next!='\n'&&next!=EOF)ungetc(next,f);}
    out[i]=0;return i?0:-1;
}
static int read_ppm(const char *path,uint8_t **data,int *width,int *height) {
    FILE *f=fopen(path,"rb");if(!f){perror(path);return -1;}
    char s[64],*end;long w=0,h=0,max=0;int rc=-1;
    if(token(f,s,sizeof(s))||strcmp(s,"P6"))goto done;
    if(token(f,s,sizeof(s)))goto done;
    w=strtol(s,&end,10);if(*end||w<1||w>16384)goto done;
    if(token(f,s,sizeof(s)))goto done;
    h=strtol(s,&end,10);if(*end||h<1||h>16384)goto done;
    if(token(f,s,sizeof(s)))goto done;
    max=strtol(s,&end,10);if(*end||max!=255)goto done;
    size_t bytes=(size_t)w*(size_t)h*3;
    uint8_t *p=malloc(bytes);if(!p)goto done;
    if(fread(p,1,bytes,f)!=bytes){free(p);goto done;}
    for(size_t i=0;i<bytes;i+=3){uint8_t t=p[i];p[i]=p[i+2];p[i+2]=t;}
    *data=p;*width=(int)w;*height=(int)h;rc=0;
done:
    fclose(f);return rc;
}
static void print_faces(unsigned long frame,const yunet_face *faces,size_t n,double dpu,double total,double wait,double copy,double prep,double post,int profile) {
    printf("{\"frame\":%lu,\"count\":%zu,\"dpu_call_ms\":%.3f,\"capture_inference_postprocess_ms\":%.3f",frame,n,dpu,total);
    if(profile)printf(",\"capture_wait_ms\":%.3f,\"frame_copy_ms\":%.3f,\"preprocess_ms\":%.3f,\"postprocess_ms\":%.3f",wait,copy,prep,post);
    printf(",\"faces_original_pixels\":[");
    for(size_t i=0;i<n;i++) {
        if(i)putchar(',');
        printf("[%.5f,%.5f,%.5f,%.5f",faces[i].x,faces[i].y,faces[i].w,faces[i].h);
        for(int j=0;j<10;j++)printf(",%.5f",faces[i].landmarks[j]);
        printf(",%.7f]",faces[i].score);
    }
    puts("]}");fflush(stdout);
}
int main(int argc,char **argv) {
    const char *config="config/yunet.conf",*image=NULL,*dump=NULL;
    const char *recognition_model=NULL;
    const char *auth_database=NULL,*auth_key=NULL,*auth_policy=NULL,*auth_permission=NULL,*auth_claim=NULL;
#ifdef FACEGUARD_DATABASE
    fg_auth_context *auth=NULL;
#endif
    const char *quality_path=NULL;fg_quality_config quality_config=fg_quality_defaults();
    const char *preprocess="fused";int check=0,profile=0,preview_test_mode=0;
    unsigned long limit=0;
    for(int i=1;i<argc;i++) {
        if(!strcmp(argv[i],"--help")) {
            puts("yunet-kv260 [--config FILE] [--image P6.ppm] [--frames N] [--dump-input FILE] [--preprocess fused|reference|cached-reference] [--check-preprocess] [--profile] [--recognition-model MODEL.xmodel] [--quality-config FILE] [--preview-test-mode]");return 0;
        }
        if(!strcmp(argv[i],"--check-preprocess")){check=1;continue;}
        if(!strcmp(argv[i],"--profile")){profile=1;continue;}
        if(!strcmp(argv[i],"--preview-test-mode")){preview_test_mode=1;continue;}
        if(i+1>=argc){fprintf(stderr,"Missing option value\n");return 2;}
        if(!strcmp(argv[i],"--config"))config=argv[++i];
        else if(!strcmp(argv[i],"--recognition-model"))recognition_model=argv[++i];
        else if(!strcmp(argv[i],"--quality-config"))quality_path=argv[++i];
        else if(!strcmp(argv[i],"--auth-database"))auth_database=argv[++i];
        else if(!strcmp(argv[i],"--auth-key"))auth_key=argv[++i];
        else if(!strcmp(argv[i],"--auth-policy"))auth_policy=argv[++i];
        else if(!strcmp(argv[i],"--auth-permission"))auth_permission=argv[++i];
        else if(!strcmp(argv[i],"--auth-claim"))auth_claim=argv[++i];
        else if(!strcmp(argv[i],"--image"))image=argv[++i];
        else if(!strcmp(argv[i],"--dump-input"))dump=argv[++i];
        else if(!strcmp(argv[i],"--preprocess"))preprocess=argv[++i];
        else if(!strcmp(argv[i],"--frames")) {
            char *end;errno=0;const char *v=argv[++i];limit=strtoul(v,&end,10);
            if(errno||*end||*v=='-'){fprintf(stderr,"Invalid frame count\n");return 2;}
        }else{fprintf(stderr,"Unknown option: %s\n",argv[i]);return 2;}
    }
    if(strcmp(preprocess,"fused")&&strcmp(preprocess,"reference")&&strcmp(preprocess,"cached-reference")){fprintf(stderr,"Invalid preprocessing mode\n");return 2;}
    app_config cfg;if(config_load(config,&cfg))return 2;
    if(!recognition_model&&cfg.recognition_model[0])recognition_model=cfg.recognition_model;
    int auth_requested=auth_database||auth_key||auth_policy||auth_permission||auth_claim;
    if(auth_requested&&(!recognition_model||!auth_database||!auth_key||!auth_policy||!auth_permission)){fprintf(stderr,"Authentication requires recognition model, database, key, policy and permission\n");return 2;}
#ifndef FACEGUARD_DATABASE
    if(auth_requested){fprintf(stderr,"Native identity database support is disabled in this build\n");return 2;}
#endif
    if(quality_path&&(!recognition_model||quality_config_load(quality_path,&quality_config))){fprintf(stderr,"Invalid recognition quality config\n");return 2;}
    if(setenv("XLNX_VART_FIRMWARE",cfg.firmware,1)){perror("setenv");return 1;}
    signal(SIGINT,stopped);signal(SIGTERM,stopped);
    dpu_context *dpu=NULL,*recognizer=NULL;camera *cam=NULL;uint8_t *bgr=NULL;int w=0,h=0;
    uint8_t *auth_bgr=NULL;size_t auth_capacity=0;int8_t *auth_input=NULL;
    dpu_tensor_info auth_tensor={0};
    uint8_t *cached=NULL;size_t cached_size=0;
    int rc=1;char error[1024]={0};
    preview_writer preview=PREVIEW_WRITER_INIT;
    int intent_fd=-1,camera_fd=-1;
#ifdef FACEGUARD_DATABASE
    if(auth_requested&&fg_auth_open(auth_database,auth_key,auth_policy,recognition_model,auth_permission,auth_claim,&auth)){
        fprintf(stderr,"Native authentication initialization failed; access denied\n");goto done;
    }
#endif
    if(!image){
        intent_fd=camera_guard_intent();
        if(intent_fd<0){fprintf(stderr,"Another live inference owns camera intent\n");goto done;}
    }
    if(dpu_open(cfg.model,cfg.fingerprint,&dpu,error,sizeof(error))) {
        fprintf(stderr,"DPU open: %s\n",error);goto done;
    }
    if(recognition_model){
        if(dpu_open_embedding(recognition_model,cfg.fingerprint,&recognizer,error,sizeof(error))||dpu_input(recognizer,&auth_tensor,&auth_input)){
            fprintf(stderr,"Recognition open: %s\n",error);goto done;
        }
    }
    dpu_tensor_info input;int8_t *input_data;
    if(dpu_input(dpu,&input,&input_data))goto done;
    fprintf(stderr,"Input: %s [%d,%d,%d,%d], fix_point=%d, BGR/no normalization\n",input.name,input.dims[0],input.dims[1],input.dims[2],input.dims[3],input.fix_point);
    yunet_head heads[12]={0};
    for(int j=0;j<12;j++) {
        char pattern[64];snprintf(pattern,sizeof(pattern),"_%s__",cfg.head[j]);
        int matches=0;
        for(size_t i=0;i<dpu_output_count(dpu);i++) {
            dpu_tensor_info info;const int8_t *data;
            if(dpu_output(dpu,i,&info,&data))goto done;
            if(strstr(info.name,pattern)) {
                int channels=j/3==2?4:(j/3==3?10:1),side=40>>(j%3);
                if(info.dims[1]!=side||info.dims[2]!=side||info.dims[3]!=channels||
                   info.bytes!=(size_t)side*side*channels){fprintf(stderr,"Unexpected head shape: %s\n",info.name);goto done;}
                heads[j]=(yunet_head){data,side,side,channels,info.fix_point};matches++;
                fprintf(stderr,"Head %d: %s [%d,%d,%d,%d], fix_point=%d\n",j,info.name,info.dims[0],info.dims[1],info.dims[2],info.dims[3],info.fix_point);
            }
        }
        if(matches!=1){fprintf(stderr,"Head %s matched %d tensors\n",cfg.head[j],matches);goto done;}
    }
    if(image) {
        if(read_ppm(image,&bgr,&w,&h)){fprintf(stderr,"Read a binary P6 PPM image, maxval 255\n");goto done;}
    }else {
        char device[128];
        if(!strcmp(cfg.device,"auto")) {
            if(capture_find_ias(device,sizeof(device))){fprintf(stderr,"Cannot find unique IAS capture node; configure/load SmartCam first\n");goto done;}
        }else snprintf(device,sizeof(device),"%s",cfg.device);
        camera_fd=camera_guard_open("/run/yunet-camera.lock");
        if(camera_fd<0||camera_guard_claim(camera_fd,2000)){
            fprintf(stderr,"Camera ownership handoff failed at startup\n");goto done;
        }
        if(capture_open(device,cfg.width,cfg.height,&cam))goto done;
    }
    for(unsigned long frame=1;!stop&&(!limit||frame<=limit);frame++) {
        double begin=now();
        double wait_ms=0,copy_ms=0,prep_ms=0;
        int preview_matrix=601,preview_range=0;uint64_t capture_ns=0;
        yunet_transform tr;
        if(cam) {
            nv12_frame nv;
            if(capture_acquire(cam,&nv)){if(stop){rc=0;goto done;}fprintf(stderr,"Camera capture timeout/error\n");goto done;}
            wait_ms=(now()-begin)*1000;w=nv.width;h=nv.height;
            capture_ns=preview_now_ns();preview_matrix=nv.matrix;preview_range=nv.full_range;
            double copy_begin=now();
            int direct=!strcmp(preprocess,"reference");
            if(!direct){
                size_t size=(size_t)w*h*3/2;
                uint8_t *pixels=preview_begin(&preview,w,h,capture_ns);
                if(!pixels){
                    if(cached_size!=size){free(cached);cached=malloc(size);cached_size=size;}
                    if(!cached){capture_release(cam);goto done;}
                    pixels=cached;
                }
                /* DMA mappings can be uncached. One sequential bulk copy avoids
                 * millions of repeated uncached byte loads during conversion. */
                for(int row=0;row<h;row++)memcpy(pixels+(size_t)row*w,nv.y+(size_t)row*nv.y_stride,(size_t)w);
                uint8_t *uv=pixels+(size_t)w*h;
                for(int row=0;row<h/2;row++)memcpy(uv+(size_t)row*w,nv.uv+(size_t)row*nv.uv_stride,(size_t)w);
                if(capture_release(cam))goto done;
                nv.y=pixels;nv.uv=uv;nv.y_stride=nv.uv_stride=(size_t)w;
                nv.y_length=(size_t)w*h;nv.uv_length=(size_t)w*h/2;
            }
            copy_ms=(now()-copy_begin)*1000;
            double prep_begin=now();
            if(recognizer){
                size_t needed=(size_t)w*h*3;
                if(auth_capacity!=needed){free(auth_bgr);auth_bgr=malloc(needed);auth_capacity=needed;}
                if(!auth_bgr||yunet_nv12_to_bgr(nv.y,nv.y_length,nv.y_stride,nv.uv,nv.uv_length,nv.uv_stride,w,h,nv.matrix,nv.full_range,auth_bgr))goto done;
            }
            if(!strcmp(preprocess,"fused")){
                if(yunet_preprocess_nv12(nv.y,nv.y_length,nv.y_stride,nv.uv,nv.uv_length,nv.uv_stride,w,h,nv.matrix,nv.full_range,input.fix_point,input_data,&tr))goto done;
                if(check){
                    uint8_t *reference_bgr=malloc((size_t)w*h*3);int8_t *reference=malloc(input.bytes);yunet_transform rt;
                    if(!reference_bgr||!reference){free(reference_bgr);free(reference);goto done;}
                    int failed=yunet_nv12_to_bgr(nv.y,nv.y_length,nv.y_stride,nv.uv,nv.uv_length,nv.uv_stride,w,h,nv.matrix,nv.full_range,reference_bgr)||yunet_preprocess(reference_bgr,w,h,(size_t)w*3,input.fix_point,reference,&rt);
                    if(!failed)failed=memcmp(reference,input_data,input.bytes)||memcmp(&rt,&tr,sizeof(tr));
                    free(reference_bgr);free(reference);
                    if(failed){fprintf(stderr,"Fused preprocessing parity failed\n");goto done;}
                    fprintf(stderr,"Fused preprocessing byte-identical to reference on captured frame\n");check=0;
                }
            }else{
                if(!bgr)bgr=malloc((size_t)cfg.width*cfg.height*3);
                if(!bgr||w!=cfg.width||h!=cfg.height)goto done;
                int converted=yunet_nv12_to_bgr(nv.y,nv.y_length,nv.y_stride,nv.uv,nv.uv_length,nv.uv_stride,w,h,nv.matrix,nv.full_range,bgr);
                if(direct&&capture_release(cam))goto done;
                if(converted||yunet_preprocess(bgr,w,h,(size_t)w*3,input.fix_point,input_data,&tr))goto done;
            }
            prep_ms=(now()-prep_begin)*1000;
        }else{
            double prep_begin=now();
            if(yunet_preprocess(bgr,w,h,(size_t)w*3,input.fix_point,input_data,&tr))goto done;
            prep_ms=(now()-prep_begin)*1000;
        }
        if(dump) {
            FILE *f=fopen(dump,"wb");if(!f){perror(dump);goto done;}
            size_t written=fwrite(input_data,1,input.bytes,f);int closed=fclose(f);
            if(written!=input.bytes||closed)goto done;
            dump=NULL;
        }
        double start=now();
        if(dpu_run(dpu,error,sizeof(error))){fprintf(stderr,"DPU run: %s\n",error);goto done;}
        double dpu_ms=(now()-start)*1000;
        double post_begin=now();
        yunet_face faces[100];size_t count;
        if(yunet_decode(heads,cfg.score,cfg.nms,&tr,faces,100,&count))goto done;
        double post_ms=(now()-post_begin)*1000;
        yunet_feedback feedback={.state=YUNET_FEEDBACK_OFF,.test_mode=(uint32_t)preview_test_mode};
        if(recognizer){
            double recognition_begin=now();
            fg_quality_result quality={0};
            const uint8_t *pixels=cam?auth_bgr:bgr;
            int ready=count==1&&fg_quality(pixels,w,h,(size_t)w*3,faces,&quality_config,&quality)==0&&!quality.rejected;
            feedback.state=count==0?YUNET_FEEDBACK_NO_FACE:count>1?YUNET_FEEDBACK_MULTIPLE:YUNET_FEEDBACK_ADJUST;
            feedback.quality_flags=quality.rejected;
            feedback.mean=quality.mean;feedback.sharpness=quality.laplacian_variance;
            feedback.roll=quality.roll;feedback.yaw=quality.yaw_proxy;
            feedback.pitch=quality.pitch_proxy;feedback.landmark_error=quality.landmark_error;
            /* pixels is the original-resolution camera copy, never input_data
             * (the detector tensor), nor the annotated HDMI output. */
            if(ready&&fg_align(pixels,w,h,(size_t)w*3,faces,auth_tensor.fix_point,auth_input)==0){
                feedback.state=YUNET_FEEDBACK_READY;
                if(dpu_run(recognizer,error,sizeof(error))){fprintf(stderr,"Recognition run: %s\n",error);goto done;}
                const int8_t *embedding;dpu_tensor_info output;
                if(dpu_output(recognizer,0,&output,&embedding))goto done;
#ifdef FACEGUARD_DATABASE
                if(auth){
                    char *decision=NULL;
                    if(fg_auth_match(auth,embedding,&decision)){fprintf(stderr,"Native matching failed; access denied\n");goto done;}
                    json_object *result=json_tokener_parse(decision),*accepted=NULL,*score=NULL;
                    if(!result||!json_object_object_get_ex(result,"accepted",&accepted)||!json_object_is_type(accepted,json_type_boolean)){
                        if(result)json_object_put(result);
                        free(decision);fprintf(stderr,"Invalid native matching result\n");goto done;
                    }
                    feedback.state=json_object_get_boolean(accepted)?YUNET_FEEDBACK_MATCH:YUNET_FEEDBACK_NO_MATCH;
                    if(json_object_object_get_ex(result,"score",&score))feedback.match_score=(float)json_object_get_double(score);
                    json_object_put(result);
                    printf("{\"frame\":%lu,\"authentication\":%s,\"recognition_ms\":%.3f}\n",frame,decision,(now()-recognition_begin)*1000);
                    free(decision);
                }else
#endif
                {
                printf("{\"frame\":%lu,\"recognition_embedding_int8\":[",frame);
                for(int i=0;i<FG_DIM;i++)printf("%s%d",i?",":"",embedding[i]);
                printf("],\"recognition_ms\":%.3f}\n",(now()-recognition_begin)*1000);
                }
            }else {
                if(count==1&&!feedback.quality_flags)feedback.quality_flags=FG_INVALID;
#ifdef FACEGUARD_DATABASE
                if(auth)printf("{\"frame\":%lu,\"authentication\":{\"accepted\":false,\"reason\":\"frame_quality\"},\"face_count\":%zu,\"quality_flags\":%u}\n",frame,count,quality.rejected?quality.rejected:FG_INVALID);
                else
#endif
                printf("{\"frame\":%lu,\"recognition_rejected\":true,\"face_count\":%zu,\"quality_flags\":%u}\n",frame,count,quality.rejected?quality.rejected:FG_INVALID);
            }
        }
        preview_publish_feedback(&preview,preview_matrix,preview_range,faces,count,frame,capture_ns,&feedback);
        print_faces(frame,faces,count,dpu_ms,(now()-begin)*1000,wait_ms,copy_ms,prep_ms,post_ms,profile);
        if(image)break;
    }
    rc=0;
done:
#ifdef FACEGUARD_DATABASE
    fg_auth_close(auth);
#endif
    preview_writer_close(&preview);capture_close(cam);
    if(camera_fd>=0)close(camera_fd);
    if(intent_fd>=0)close(intent_fd);
    free(bgr);free(cached);free(auth_bgr);dpu_close(recognizer);dpu_close(dpu);return rc;
}
