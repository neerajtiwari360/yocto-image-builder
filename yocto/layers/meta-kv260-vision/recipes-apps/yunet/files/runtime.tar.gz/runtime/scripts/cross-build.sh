#!/bin/bash
set -eo pipefail
shopt -s nullglob
sdk_root=${SDK_ROOT:-/opt/yocto}
source_root=${SOURCE_ROOT:-/src}
build_root=${BUILD_ROOT:-/build}
output_root=${OUTPUT_ROOT:-/output}
environments=("$sdk_root"/environment-setup-*)
test ${#environments[@]} = 1 || { echo 'Expected exactly one SDK environment' >&2; exit 1; }
source "${environments[0]}"
test "${OECORE_TARGET_ARCH:-}" = aarch64 || { echo 'SDK is not ARM64' >&2; exit 1; }
test -n "${SDKTARGETSYSROOT:-}" && test -d "$SDKTARGETSYSROOT/usr/include/vart" || exit 1
test -d "$SDKTARGETSYSROOT/usr/include/xir" || exit 1
cmake -S "$source_root" -B "$build_root" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="${OE_CMAKE_TOOLCHAIN_FILE:?Missing SDK CMake toolchain}" \
    -DCMAKE_BUILD_TYPE=Release -DENABLE_VART=ON -DBUILD_TESTING=OFF
cmake --build "$build_root" --parallel "${BUILD_JOBS:-2}"
# SDK tools can contain command flags; split the SDK-provided command, never eval it.
read -r -a strip_command <<< "${STRIP:?}"
"${strip_command[@]}" "$build_root/yunet-kv260"
read -r -a readelf_command <<< "${READELF:?}"
"${readelf_command[@]}" -h "$build_root/yunet-kv260" | grep 'Machine:.*AArch64'
python3 "$source_root/scripts/package.py" --binary "$build_root/yunet-kv260" \
    --sysroot "$SDKTARGETSYSROOT" --source "$source_root" --output "$output_root" \
    --readelf "${readelf_command[0]}" "$@"
