#ifndef DPU_BRIDGE_H
#define DPU_BRIDGE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct dpu_context dpu_context;
typedef struct {
    char name[256];
    int dims[4]; /* NHWC, batch one */
    int fix_point;
    size_t bytes;
} dpu_tensor_info;
/* A context owns its graph, runner and buffers. It is single-threaded. */
int dpu_open(const char *model, uint64_t fingerprint, dpu_context **out,
             char *error, size_t error_size);
void dpu_close(dpu_context *ctx);
int dpu_input(dpu_context *ctx, dpu_tensor_info *info, int8_t **data);
size_t dpu_output_count(const dpu_context *ctx);
int dpu_output(dpu_context *ctx, size_t index, dpu_tensor_info *info,
               const int8_t **data);
int dpu_run(dpu_context *ctx, char *error, size_t error_size);
#ifdef __cplusplus
}
#endif
#endif
