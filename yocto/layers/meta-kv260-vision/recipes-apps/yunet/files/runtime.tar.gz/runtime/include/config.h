#ifndef CONFIG_H
#define CONFIG_H
#include <stdint.h>
typedef struct {
    char model[512],firmware[512],device[128],head[12][32];
    char recognition_model[512];
    uint64_t fingerprint;
    int width,height;
    float score,nms;
} app_config;
int config_load(const char *path,app_config *config);
#endif
