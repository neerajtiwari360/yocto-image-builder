#!/bin/bash
# Run in the existing Yocto builder container with the native project at /native.
set -eo pipefail
exec > /artifacts/kv260-native-build.log 2>&1
trap 'status=$?; printf "%s\n" "$status" > /artifacts/kv260-native-build.exit' EXIT
rm -f /artifacts/kv260-native-build.exit
echo waiting-for-image > /artifacts/kv260-native-build.phase
bash /native/yocto/build-sdk.sh
echo installing-sdk > /artifacts/kv260-native-build.phase
installers=(/artifacts/sdk/kv260-vision/*.sh)
test ${#installers[@]} = 1 || { echo 'Expected one exported SDK installer'; exit 1; }
export SDK_ROOT=/work/sdks/kv260-vision
export SOURCE_ROOT=/native
export BUILD_ROOT=/work/application-builds/yunet-kv260
export OUTPUT_ROOT=/artifacts/inference/yunet-kv260
export YUNET_SDK_SHA256
YUNET_SDK_SHA256=$(sha256sum "${installers[0]}" | cut -d' ' -f1)
manifests=(/artifacts/sdk/kv260-vision/*.target.manifest)
test ${#manifests[@]} = 1 || exit 1
export YUNET_TARGET_MANIFEST=${manifests[0]}
if test ! -f "$SDK_ROOT/.installer-sha256"; then
    mkdir -p "$SDK_ROOT"
    bash "${installers[0]}" -y -d "$SDK_ROOT"
    printf '%s\n' "$YUNET_SDK_SHA256" > "$SDK_ROOT/.installer-sha256"
fi
test "$(cat "$SDK_ROOT/.installer-sha256")" = "$YUNET_SDK_SHA256" || {
    echo 'Existing SDK differs from new installer; choose a fresh SDK_ROOT'; exit 1;
}
echo cross-compiling > /artifacts/kv260-native-build.phase
bash /native/scripts/cross-build.sh
echo complete > /artifacts/kv260-native-build.phase
echo 'Image, matching SDK and ARM64 inference package completed. Board execution remains untested.'
