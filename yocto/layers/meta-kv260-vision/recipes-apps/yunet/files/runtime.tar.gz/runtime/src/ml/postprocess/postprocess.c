#include "yunet_postprocess.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static float dequant(const yunet_head *h,size_t offset) {
    return ldexpf((float)h->data[offset],-h->fix_point);
}
static float sigmoid(float x) {
    if(x>=0) return 1.0f/(1.0f+expf(-x));
    float e=expf(x); return e/(1.0f+e);
}

static int compare_faces(const void *va,const void *vb) {
    const yunet_face *a=va,*b=vb;
    if(a->score>b->score)return -1;
    if(a->score<b->score)return 1;
    /* Deterministic tie order independent of libc qsort implementation. */
    if(a->y<b->y)return -1;
    if(a->y>b->y)return 1;
    if(a->x<b->x)return -1;
    if(a->x>b->x)return 1;
    return 0;
}
static float iou(const yunet_face *a,const yunet_face *b) {
    float w=fmaxf(0,fminf(a->x+a->w,b->x+b->w)-fmaxf(a->x,b->x));
    float h=fmaxf(0,fminf(a->y+a->h,b->y+b->h)-fmaxf(a->y,b->y));
    float intersection=w*h,area=a->w*a->h+b->w*b->h-intersection;
    return area>0?intersection/area:0;
}
int yunet_decode(const yunet_head hs[12],float threshold,float nms,
                 const yunet_transform *tr,yunet_face *out,size_t cap,size_t *count) {
    if(count)*count=0;
    if(!hs||!tr||!out||!count||!cap||!isfinite(threshold)||threshold<=0||threshold>1||
       !isfinite(nms)||nms<0||nms>1||tr->resized_width<1||tr->resized_height<1||
       tr->width<1||tr->height<1) return -1;
    const int channels[4]={1,1,4,10};
    for(int j=0;j<12;j++) {
        int side=40>>(j%3);
        if(!hs[j].data||hs[j].height!=side||hs[j].width!=side||
           hs[j].channels!=channels[j/3]||hs[j].fix_point < -16||hs[j].fix_point>16) return -1;
    }
    yunet_face *candidates=malloc(sizeof(*candidates)*YUNET_MAX_CANDIDATES);
    if(!candidates)return -1;
    size_t n=0;
    for(int level=0;level<3;level++) {
        int side=40>>level,stride=8<<level;
        for(int y=0;y<side;y++)for(int x=0;x<side;x++) {
            size_t p=(size_t)y*side+x;
            float score=sqrtf(sigmoid(dequant(&hs[level],p))*sigmoid(dequant(&hs[level+3],p)));
            if(score<threshold)continue;
            float cx=(dequant(&hs[level+6],p*4)+x)*stride;
            float cy=(dequant(&hs[level+6],p*4+1)+y)*stride;
            float bw=expf(dequant(&hs[level+6],p*4+2))*stride;
            float bh=expf(dequant(&hs[level+6],p*4+3))*stride;
            if(!isfinite(bw)||!isfinite(bh)||!isfinite(cx)||!isfinite(cy))continue;
            yunet_face *f=&candidates[n++];
            *f=(yunet_face){.x=cx-bw/2,.y=cy-bh/2,.w=bw,.h=bh,.score=score};
            for(int k=0;k<5;k++) {
                f->landmarks[k*2]=(dequant(&hs[level+9],p*10+k*2)+x)*stride;
                f->landmarks[k*2+1]=(dequant(&hs[level+9],p*10+k*2+1)+y)*stride;
            }
        }
    }
    qsort(candidates,n,sizeof(*candidates),compare_faces);
    size_t used=0;
    for(size_t i=0;i<n&&used<cap;i++) {
        int suppress=0;
        for(size_t j=0;j<used;j++)if(iou(&candidates[i],&out[j])>nms){suppress=1;break;}
        if(!suppress)out[used++]=candidates[i];
    }
    free(candidates);
    float sx=(float)tr->width/tr->resized_width,sy=(float)tr->height/tr->resized_height;
    for(size_t i=0;i<used;i++) {
        out[i].x*=sx;out[i].w*=sx;out[i].y*=sy;out[i].h*=sy;
        for(int k=0;k<5;k++){out[i].landmarks[k*2]*=sx;out[i].landmarks[k*2+1]*=sy;}
    }
    *count=used;return 0;
}

