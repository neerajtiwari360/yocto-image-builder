#define _POSIX_C_SOURCE 200809L
#include "faceguard_auth.h"
#include "faceguard.h"
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <sqlite3.h>
#include <json-c/json.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PREPROCESS FG_PREPROCESS_ID
struct fg_auth_context {
    sqlite3 *db;unsigned char key[32];char hash[65];
    char *permission,*claim;double threshold,margin;
};
static const char *string(json_object *o,const char *key){
    json_object *v=NULL;
    return json_object_object_get_ex(o,key,&v)&&json_object_is_type(v,json_type_string)?json_object_get_string(v):NULL;
}
static int equal(const char *a,const char *b){return a&&b&&!strcmp(a,b);}
static int number(json_object *o,const char *key,double *value){
    json_object *v=NULL;if(!json_object_object_get_ex(o,key,&v)||(!json_object_is_type(v,json_type_double)&&!json_object_is_type(v,json_type_int)))return -1;
    *value=json_object_get_double(v);return isfinite(*value)?0:-1;
}
static int private_path(const char *path){
    struct stat s;
    return lstat(path,&s)||!S_ISREG(s.st_mode)||(s.st_mode&077)?-1:0;
}
static int model_hash(const char *path,char hex[65]){
    FILE *f=fopen(path,"rb");if(!f)return -1;
    EVP_MD_CTX *md=EVP_MD_CTX_new();unsigned char buffer[16384],digest[32];unsigned n=0;int ok=md&&EVP_DigestInit_ex(md,EVP_sha256(),NULL)==1;
    size_t count;while(ok&&(count=fread(buffer,1,sizeof(buffer),f)))ok=EVP_DigestUpdate(md,buffer,count)==1;
    if(ferror(f))ok=0;
    if(ok)ok=EVP_DigestFinal_ex(md,digest,&n)==1&&n==32;
    fclose(f);EVP_MD_CTX_free(md);
    if(!ok)return -1;
    for(unsigned i=0;i<32;i++)snprintf(hex+2*i,3,"%02x",digest[i]);
    return 0;
}
static json_object *decrypt(fg_auth_context *c,const char *row,const unsigned char *blob,int length){
    if(length<28||length>1024*1024)return NULL;
    char aad[256];int size=snprintf(aad,sizeof(aad),"faceguard:1:%s:%s:%s",c->hash,PREPROCESS,row);
    if(size<0||size>=(int)sizeof(aad))return NULL;
    unsigned char *plain=malloc((size_t)length+1);if(!plain)return NULL;
    EVP_CIPHER_CTX *cipher=EVP_CIPHER_CTX_new();int n=0,total=0;
    int ok=cipher&&EVP_DecryptInit_ex(cipher,EVP_aes_256_gcm(),NULL,NULL,NULL)==1&&
        EVP_CIPHER_CTX_ctrl(cipher,EVP_CTRL_GCM_SET_IVLEN,12,NULL)==1&&
        EVP_DecryptInit_ex(cipher,NULL,NULL,c->key,blob)==1&&
        EVP_DecryptUpdate(cipher,NULL,&n,(const unsigned char*)aad,size)==1&&
        EVP_DecryptUpdate(cipher,plain,&n,blob+12,length-28)==1;
    total=n;
    if(ok)ok=EVP_CIPHER_CTX_ctrl(cipher,EVP_CTRL_GCM_SET_TAG,16,(void*)(blob+length-16))==1&&EVP_DecryptFinal_ex(cipher,plain+total,&n)==1;
    json_object *result=NULL;
    if(ok){total+=n;plain[total]=0;result=json_tokener_parse((const char*)plain);}
    OPENSSL_cleanse(plain,(size_t)length+1);free(plain);EVP_CIPHER_CTX_free(cipher);return result;
}
void fg_auth_close(fg_auth_context *c){
    if(!c)return;
    sqlite3_close(c->db);free(c->permission);free(c->claim);OPENSSL_cleanse(c->key,sizeof(c->key));free(c);
}
int fg_auth_open(const char *database,const char *key,const char *policy,const char *model,const char *permission,const char *claim,fg_auth_context **out){
    if(out)*out=NULL;
    if(!out||!database||!key||!policy||!model||!permission||!*permission||private_path(key)||private_path(database))return -1;
    fg_auth_context *c=calloc(1,sizeof(*c));if(!c)return -1;
    int fd=open(key,O_RDONLY|O_NOFOLLOW);unsigned char material[33];ssize_t n=fd<0?-1:read(fd,material,sizeof(material));if(fd>=0)close(fd);
    if(n!=32){OPENSSL_cleanse(material,sizeof(material));fg_auth_close(c);return -1;}
    memcpy(c->key,material,32);OPENSSL_cleanse(material,sizeof(material));
    c->permission=strdup(permission);c->claim=claim?strdup(claim):NULL;
    if(!c->permission||(claim&&!c->claim)||model_hash(model,c->hash)){fg_auth_close(c);return -1;}
    json_object *p=json_object_from_file(policy);double schema=0;
    int ok=p&&equal(string(p,"model_sha256"),c->hash)&&equal(string(p,"preprocess"),PREPROCESS)&&!number(p,"schema",&schema)&&schema==1&&
        !number(p,"threshold",&c->threshold)&&c->threshold>=-1&&c->threshold<=1&&!number(p,"margin",&c->margin)&&c->margin>=0&&c->margin<=2;
    if(p)json_object_put(p);
    if(!ok||sqlite3_open_v2(database,&c->db,SQLITE_OPEN_READONLY|SQLITE_OPEN_NOFOLLOW,NULL)!=SQLITE_OK){fg_auth_close(c);return -1;}
    sqlite3_stmt *stmt=NULL;
    ok=sqlite3_prepare_v2(c->db,"SELECT payload FROM templates WHERE id='contract'",-1,&stmt,NULL)==SQLITE_OK&&sqlite3_step(stmt)==SQLITE_ROW;
    json_object *contract=ok?decrypt(c,"contract",sqlite3_column_blob(stmt,0),sqlite3_column_bytes(stmt,0)):NULL;
    schema=0;ok=contract&&equal(string(contract,"model"),c->hash)&&equal(string(contract,"preprocess"),PREPROCESS)&&!number(contract,"schema",&schema)&&schema==1;
    if(contract)json_object_put(contract);
    sqlite3_finalize(stmt);
    if(!ok){fg_auth_close(c);return -1;}
    *out=c;return 0;
}
int fg_auth_match(fg_auth_context *c,const int8_t *embedding,char **decision){
    if(decision)*decision=NULL;
    if(!c||!embedding||!decision)return -1;
    double norm=0;for(int i=0;i<FG_DIM;i++)norm+=(double)embedding[i]*embedding[i];
    if(norm<=0)return -1;
    norm=sqrt(norm);double q[FG_DIM];for(int i=0;i<FG_DIM;i++)q[i]=embedding[i]/norm;
    sqlite3_stmt *stmt=NULL;json_object *best_user=NULL;double best=-2,second=-2;int count=0,rc=SQLITE_ERROR;
    if(sqlite3_prepare_v2(c->db,"SELECT id,payload FROM templates WHERE id!='contract' ORDER BY id",-1,&stmt,NULL)!=SQLITE_OK)return -1;
    while((rc=sqlite3_step(stmt))==SQLITE_ROW){
        const char *row=(const char*)sqlite3_column_text(stmt,0);
        json_object *user=row?decrypt(c,row,sqlite3_column_blob(stmt,1),sqlite3_column_bytes(stmt,1)):NULL;
        json_object *vectors=NULL,*permissions=NULL;
        int valid=user&&string(user,"identity")&&json_object_object_get_ex(user,"embeddings",&vectors)&&json_object_is_type(vectors,json_type_array)&&
            json_object_array_length(vectors)>0&&json_object_array_length(vectors)<=20&&json_object_object_get_ex(user,"permissions",&permissions)&&json_object_is_type(permissions,json_type_array);
        double score=-2;
        if(valid)for(size_t v=0;v<json_object_array_length(vectors);v++){
            json_object *a=json_object_array_get_idx(vectors,v);double sum=0,dot=0;
            if(!json_object_is_type(a,json_type_array)||json_object_array_length(a)!=FG_DIM){valid=0;break;}
            for(int i=0;i<FG_DIM;i++){
                json_object *element=json_object_array_get_idx(a,(size_t)i);
                double x=json_object_get_double(element);
                if((!json_object_is_type(element,json_type_double)&&!json_object_is_type(element,json_type_int))||!isfinite(x)){valid=0;break;}
                sum+=x*x;dot+=q[i]*x;
            }
            if(!valid||!isfinite(sum)||sum<1e-24){valid=0;break;}
            double s=dot/sqrt(sum);if(s>1)s=1;if(s< -1)s=-1;if(s>score)score=s;
        }
        if(!valid){if(user)json_object_put(user);rc=SQLITE_ERROR;break;}
        count++;
        if(score>best){second=best;best=score;if(best_user)json_object_put(best_user);best_user=user;}
        else{if(score>second)second=score;json_object_put(user);}
    }
    sqlite3_finalize(stmt);
    if(rc!=SQLITE_DONE){if(best_user)json_object_put(best_user);return -1;}
    json_object *result=json_object_new_object();if(!result){if(best_user)json_object_put(best_user);return -1;}
    double margin=count>1?best-second:2;int allowed=0;
    if(best_user){json_object *permissions=NULL;json_object_object_get_ex(best_user,"permissions",&permissions);
        for(size_t i=0;i<json_object_array_length(permissions);i++){
            json_object *p=json_object_array_get_idx(permissions,i);
            if(json_object_is_type(p,json_type_string)&&equal(json_object_get_string(p),c->permission))allowed=1;
        }
    }
    int accepted=best_user&&best>=c->threshold&&margin>=c->margin&&allowed&&(!c->claim||equal(c->claim,string(best_user,"identity")));
    json_object_object_add(result,"accepted",json_object_new_boolean(accepted));
    if(best_user){json_object_object_add(result,"score",json_object_new_double(best));json_object_object_add(result,"margin",json_object_new_double(margin));}
    if(accepted)json_object_object_add(result,"identity",json_object_new_string(string(best_user,"identity")));
    if(!count)json_object_object_add(result,"reason",json_object_new_string("empty_database"));
    *decision=strdup(json_object_to_json_string_ext(result,JSON_C_TO_STRING_PLAIN));
    if(best_user)json_object_put(best_user);
    json_object_put(result);return *decision?0:-1;
}
