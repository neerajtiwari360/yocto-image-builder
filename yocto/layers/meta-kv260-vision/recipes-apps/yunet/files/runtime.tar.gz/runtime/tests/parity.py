"""Run the compiled C core against real quantized CPU fixtures, no VART emulation."""
import ctypes as c
import json
from pathlib import Path
import sys

lib=c.CDLL(sys.argv[1]);fixtures=Path(sys.argv[2])
class Transform(c.Structure):
    _fields_=[('width',c.c_int),('height',c.c_int),('resized_width',c.c_int),('resized_height',c.c_int)]
class Head(c.Structure):
    _fields_=[('data',c.POINTER(c.c_int8)),('height',c.c_int),('width',c.c_int),('channels',c.c_int),('fix_point',c.c_int)]
class Face(c.Structure):
    _fields_=[('x',c.c_float),('y',c.c_float),('w',c.c_float),('h',c.c_float),('landmarks',c.c_float*10),('score',c.c_float)]
lib.yunet_preprocess.argtypes=[c.POINTER(c.c_uint8),c.c_int,c.c_int,c.c_size_t,c.c_int,c.POINTER(c.c_int8),c.POINTER(Transform)]
lib.yunet_decode.argtypes=[c.POINTER(Head),c.c_float,c.c_float,c.POINTER(Transform),c.POINTER(Face),c.c_size_t,c.POINTER(c.c_size_t)]
decode_cases=0;max_geometry_error=0.;preprocess_different=0;preprocess_total=0;preprocess_max=0
for case in json.loads((fixtures/'cases.json').read_text()):
    i=case['index'];w=case['width'];h=case['height']
    src=(c.c_uint8*(w*h*3)).from_buffer_copy((fixtures/f'{i}-bgr.bin').read_bytes())
    dst=(c.c_int8*(320*320*3))();tr=Transform()
    assert lib.yunet_preprocess(src,w,h,w*3,-1,dst,c.byref(tr))==0
    assert [tr.resized_width,tr.resized_height]==[case['resized_width'],case['resized_height']]
    expected=(c.c_int8*(320*320*3)).from_buffer_copy((fixtures/f'{i}-input.bin').read_bytes())
    differences=[abs(int(a)-int(b)) for a,b in zip(dst,expected)]
    preprocess_max=max(preprocess_max,max(differences));preprocess_different+=sum(d!=0 for d in differences);preprocess_total+=len(differences)
    buffers=[];heads=(Head*12)()
    for j,info in enumerate(case['heads']):
        data=(fixtures/f'{i}-head{j}.bin').read_bytes();buffer=(c.c_int8*len(data)).from_buffer_copy(data);buffers.append(buffer)
        heads[j]=Head(buffer,info['height'],info['width'],info['channels'],info['fix_point'])
    for threshold,reference in case['expected'].items():
        faces=(Face*100)();count=c.c_size_t()
        assert lib.yunet_decode(heads,float(threshold),.3,c.byref(tr),faces,100,c.byref(count))==0
        assert count.value==len(reference),(case['image'],threshold,count.value,len(reference))
        for actual,wanted in zip(faces[:count.value],reference):
            values=[actual.x,actual.y,actual.w,actual.h,*actual.landmarks,actual.score]
            error=max(abs(a-b) for a,b in zip(values,wanted))
            max_geometry_error=max(max_geometry_error,error)
            assert error<.002,(case['image'],threshold,error)
        decode_cases+=1
# Scalar C bilinear interpolation can differ by one uint8 level from OpenCV's
# fixed-point SIMD INTER_LINEAR. Quantized input must remain within one LSB.
assert preprocess_max<=1,preprocess_max
result={'decoded_image_threshold_cases':decode_cases,'max_decoded_coordinate_or_score_error':max_geometry_error,'preprocess_max_quantized_lsb_difference':preprocess_max,'preprocess_fraction_different':preprocess_different/preprocess_total,'note':'Decoder parity uses CPU quantized dumps, not actual DPU execution. C bilinear input is not claimed bit-exact with OpenCV.'}
print(json.dumps(result,indent=2))
if len(sys.argv)>3:Path(sys.argv[3]).write_text(json.dumps(result,indent=2))
