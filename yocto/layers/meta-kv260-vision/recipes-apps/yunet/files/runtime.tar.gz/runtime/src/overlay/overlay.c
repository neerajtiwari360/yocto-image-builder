#include "yunet_overlay.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "faceguard.h"
static void point(uint8_t *p,int w,int h,size_t pitch,int x,int y,int mark) {
    if(x<0||y<0||x>=w||y>=h)return;
    p[(size_t)y*pitch+(size_t)x]=(uint8_t)(mark==3?82:(mark==2?235:(mark?210:145)));
    size_t uv=(size_t)h*pitch+(size_t)(y/2)*pitch+(size_t)(x&~1);
    p[uv]=(uint8_t)(mark==3?90:(mark==2?128:(mark?16:54)));p[uv+1]=(uint8_t)(mark==3?240:(mark==2?128:(mark?146:34)));
}
static void face_point(uint8_t *dst,int w,int h,size_t pitch,int x,int y,int mark,int ox,int oy,int dw,int dh) {
    if(x<ox||x>=ox+dw||y<oy||y>=oy+dh)return;
    point(dst,w,h,pitch,x,y,mark);
}
static void draw_faces(const yunet_overlay_frame *s,uint8_t *dst,int w,int h,size_t pitch,int ox,int oy,int dw,int dh) {
    int sw=(int)s->width,sh=(int)s->height;
    for(uint32_t i=0;i<s->count;i++){
        const yunet_face *f=&s->faces[i];
        if(!isfinite(f->x)||!isfinite(f->y)||!isfinite(f->w)||!isfinite(f->h)||f->w<=0||f->h<=0)continue;
        float left=fmaxf(0,fminf((float)sw,f->x)),top=fmaxf(0,fminf((float)sh,f->y));
        float right=fmaxf(left,fminf((float)sw,f->x+f->w)),bottom=fmaxf(top,fminf((float)sh,f->y+f->h));
        int x0=ox+(int)(left*dw/sw),y0=oy+(int)(top*dh/sh);
        int x1=ox+(int)(right*dw/sw)-1,y1=oy+(int)(bottom*dh/sh)-1;
        if(x1<x0||y1<y0)continue;
        for(int t=0;t<2&&x0+t<=x1&&y0+t<=y1;t++){
            for(int x=x0;x<=x1;x++){face_point(dst,w,h,pitch,x,y0+t,0,ox,oy,dw,dh);face_point(dst,w,h,pitch,x,y1-t,0,ox,oy,dw,dh);}
            for(int y=y0;y<=y1;y++){face_point(dst,w,h,pitch,x0+t,y,0,ox,oy,dw,dh);face_point(dst,w,h,pitch,x1-t,y,0,ox,oy,dw,dh);}
        }
        for(int j=0;j<5;j++){
            float x=f->landmarks[j*2],y=f->landmarks[j*2+1];
            if(!isfinite(x)||!isfinite(y)||x<0||y<0||x>=sw||y>=sh)continue;
            int px=ox+(int)(x*dw/sw),py=oy+(int)(y*dh/sh);
            for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)face_point(dst,w,h,pitch,px+dx,py+dy,1,ox,oy,dw,dh);
        }
    }
}
static int render_base(const yunet_overlay_frame *s,uint8_t *dst,size_t len,int w,int h,size_t pitch,int panel_width,int annotate) {
    if(!s||!dst||w<2||h<2||(w&1)||(h&1)||pitch<(size_t)w||pitch>len/(size_t)h||len<(size_t)h*pitch*3/2||
       !s->pixels||(s->count&&!s->faces)||s->width<2||s->height<2||s->width>YUNET_OVERLAY_MAX_WIDTH||s->height>YUNET_OVERLAY_MAX_HEIGHT||(s->width&1)||(s->height&1)||s->count>YUNET_OVERLAY_MAX_FACES)return -1;
    if(s->length<(size_t)s->width*s->height*3/2)return -1;
    int sw=(int)s->width,sh=(int)s->height;
    int dw=panel_width,dh=(int)((int64_t)sh*panel_width/sw)&~1;
    if(dh>h){dh=h;dw=(int)((int64_t)sw*h/sh)&~1;}
    if(dw<2||dh<2)return -1;
    int ox=((panel_width-dw)/2)&~1,oy=((h-dh)/2)&~1;
    /* Padding is cleared too: a stale box cannot survive in a reused buffer. */
    memset(dst,16,pitch*(size_t)h);memset(dst+pitch*(size_t)h,128,pitch*(size_t)h/2);
    for(int y=0;y<dh;y++){
        const uint8_t *src=s->pixels+(size_t)(y*sh/dh)*sw;
        uint8_t *out=dst+(size_t)(oy+y)*pitch+(size_t)ox;
        for(int x=0;x<dw;x++){
            int v=src[x*sw/dw];
            out[x]=(uint8_t)(s->full_range?16+(v*219+127)/255:v);
        }
    }
    const uint8_t *uv=s->pixels+(size_t)sw*sh;
    for(int y=0;y<dh/2;y++){
        const uint8_t *src=uv+(size_t)(y*sh/dh)*sw;
        uint8_t *out=dst+pitch*(size_t)h+(size_t)(oy/2+y)*pitch+(size_t)ox;
        for(int x=0;x<dw;x+=2){
            int sx=(x*sw/dw)&~1;
            for(int c=0;c<2;c++){int v=src[sx+c];out[x+c]=(uint8_t)(s->full_range?128+((v-128)*224)/255:v);}
        }
    }
    if(annotate)draw_faces(s,dst,w,h,pitch,ox,oy,dw,dh);
    return 0;
}

static void label(uint8_t *dst,int w,int h,size_t pitch,int x,int y,const char *text,int color) {
    static const char letters[]="ACEFLMNORTUYBDGHIJKPQSVWXZ0123456789-.:/";
    static const uint8_t glyphs[][5]={
        {0x7e,0x11,0x11,0x11,0x7e},{0x3e,0x41,0x41,0x41,0x22},
        {0x7f,0x49,0x49,0x49,0x41},{0x7f,0x09,0x09,0x09,0x01},
        {0x7f,0x40,0x40,0x40,0x40},{0x7f,0x02,0x04,0x02,0x7f},
        {0x7f,0x04,0x08,0x10,0x7f},{0x3e,0x41,0x41,0x41,0x3e},
        {0x7f,0x09,0x19,0x29,0x46},{0x01,0x01,0x7f,0x01,0x01},
        {0x3f,0x40,0x40,0x40,0x3f},{0x03,0x04,0x78,0x04,0x03},
        {0x7f,0x49,0x49,0x49,0x36},{0x7f,0x41,0x41,0x22,0x1c},
        {0x3e,0x41,0x49,0x49,0x7a},{0x7f,0x08,0x08,0x08,0x7f},
        {0x00,0x41,0x7f,0x41,0x00},{0x20,0x40,0x41,0x3f,0x01},
        {0x7f,0x08,0x14,0x22,0x41},{0x7f,0x09,0x09,0x09,0x06},
        {0x3e,0x41,0x51,0x21,0x5e},{0x46,0x49,0x49,0x49,0x31},
        {0x1f,0x20,0x40,0x20,0x1f},{0x3f,0x40,0x38,0x40,0x3f},
        {0x63,0x14,0x08,0x14,0x63},{0x61,0x51,0x49,0x45,0x43},
        {0x3e,0x51,0x49,0x45,0x3e},{0x00,0x42,0x7f,0x40,0x00},
        {0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4b,0x31},
        {0x18,0x14,0x12,0x7f,0x10},{0x27,0x45,0x45,0x45,0x39},
        {0x3c,0x4a,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
        {0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1e},
        {0x08,0x08,0x08,0x08,0x08},{0,0x60,0x60,0,0},
        {0,0x36,0x36,0,0},{0x20,0x10,0x08,0x04,0x02}
    };
    for(;*text;text++,x+=12){
        const char *g=strchr(letters,*text);if(!g)continue;
        for(int col=0;col<5;col++)for(int row=0;row<7;row++)if(glyphs[g-letters][col]&(1u<<row))
            for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)point(dst,w,h,pitch,x+col*2+dx,y+row*2+dy,color);
    }
}
static void draw_feedback(const yunet_feedback *f,uint8_t *dst,int w,int h,size_t pitch,int left,int panel_width) {
    if(!f||panel_width<240||h<160)return;
    const char *status="QUALITY NOT ENABLED";int color=1;
    switch(f->state){
    case YUNET_FEEDBACK_NO_FACE:status="LOOK AT CAMERA";break;
    case YUNET_FEEDBACK_MULTIPLE:status="ONE PERSON AT A TIME";break;
    case YUNET_FEEDBACK_ADJUST:status="ADJUST FACE - SEE CHECKS";break;
    case YUNET_FEEDBACK_READY:status="QUALITY OK - MATCHING NOT ENABLED";break;
    case YUNET_FEEDBACK_MATCH:status=f->test_mode?"TEST MATCH OK":"FACE MATCH OK";color=0;break;
    case YUNET_FEEDBACK_NO_MATCH:status=f->test_mode?"TEST NO MATCH / NOT ALLOWED":"NO MATCH / NOT ALLOWED";color=3;break;
    default:break;
    }
    int compact=panel_width<600;
    if(compact){
        if(f->state==YUNET_FEEDBACK_ADJUST)status="ADJUST FACE";
        if(f->state==YUNET_FEEDBACK_READY)status="QUALITY OK - MATCH OFF";
        if(f->state==YUNET_FEEDBACK_NO_MATCH&&f->test_mode)status="TEST: NO MATCH / DENIED";
    }
    if(f->state==YUNET_FEEDBACK_ADJUST&&(f->quality_flags&FG_INVALID))status="MOVE FACE INTO VIEW";
    int y=h-148;
    for(int row=y;row<h;row++)for(int x=left;x<left+panel_width&&x<w;x++)point(dst,w,h,pitch,x,row,2);
    /* Dark neutral background; then draw compact 5x7 text at 2x scale. */
    for(int row=y;row<h;row++)memset(dst+(size_t)row*pitch+left,16,(size_t)panel_width);
    label(dst,w,h,pitch,left+8,y+3,status,color);
    int has_face=f->state>=YUNET_FEEDBACK_ADJUST;
    int measured=has_face&&!(f->quality_flags&(FG_POSITION|FG_INVALID))&&f->mean>0;
    const uint32_t masks[]={FG_POSITION|FG_SIZE|FG_INVALID,FG_BLUR,FG_LIGHT,FG_POSE,FG_LANDMARKS,FG_OCCLUSION_PROXY};
    const char *names[]={"POSITION / SIZE","SHARPNESS","BRIGHTNESS","POSE","LANDMARKS","TEXTURE CHECK"};
    const char *hints[]={"CENTRE FACE / ADJUST DISTANCE","HOLD STILL / CHECK FOCUS","IMPROVE LIGHTING","FACE FORWARD","LOOK STRAIGHT AT CAMERA","CHECK VISIBILITY / LIGHT"};
    const char *short_names[]={"POSITION/SIZE","SHARP","LIGHT","POSE","LANDMARKS","TEXTURE"};
    const char *short_hints[]={"ADJUST","HOLD STILL / FOCUS","IMPROVE LIGHT","FACE FORWARD","FACE CAMERA","CHECK VISIBILITY"};
    char line[80];
    for(int i=0;i<6;i++){
        int failed=has_face&&(f->quality_flags&masks[i]);
        const char *value=failed?(compact?short_hints[i]:hints[i]):measured?"OK":"WAIT";
        snprintf(line,sizeof(line),"%s: %s",compact?short_names[i]:names[i],value);
        label(dst,w,h,pitch,left+8,y+23+i*18,line,failed?1:measured?0:2);
    }
    if(f->test_mode)snprintf(line,sizeof(line),compact?"TEST - UNCALIBRATED":"TEST MODE - UNCALIBRATED");
    else if(has_face)snprintf(line,sizeof(line),compact?"SHARP %.1f LIGHT %.0f":"SHARPNESS %.1f  LIGHT %.0f",(double)f->sharpness,(double)f->mean);
    else snprintf(line,sizeof(line),compact?"ORIGINAL CAMERA FRAME":"ORIGINAL CAMERA FRAME - NO STORED MATCH");
    label(dst,w,h,pitch,left+8,h-17,line,2);
}
int yunet_overlay_nv12(const yunet_overlay_frame *s,uint8_t *dst,size_t len,int w,int h,size_t pitch) {
    int result=render_base(s,dst,len,w,h,pitch,w,1);
    if(!result)draw_feedback(s->feedback,dst,w,h,pitch,0,w);
    return result;
}
int yunet_overlay_split_nv12(const yunet_overlay_frame *s,uint8_t *dst,size_t len,int w,int h,size_t pitch,int ml_active) {
    if(w<8||(w%4))return -1; /* each NV12 column must have an even width */
    int half=w/2;
    if(render_base(s,dst,len,w,h,pitch,half,0))return -1;
    /* Resize once. A small sequential copy duplicates the clean panel before
     * any overlays are drawn; no second source read, resize or ML execution. */
    for(int y=0;y<h*3/2;y++)memcpy(dst+(size_t)y*pitch+half,dst+(size_t)y*pitch,(size_t)half);
    int sw=(int)s->width,sh=(int)s->height;
    int dw=half,dh=(int)((int64_t)sh*half/sw)&~1;
    if(dh>h){dh=h;dw=(int)((int64_t)sw*h/sh)&~1;}
    int ox=((half-dw)/2)&~1,oy=((h-dh)/2)&~1;
    if(ml_active)draw_faces(s,dst,w,h,pitch,half+ox,oy,dw,dh);
    for(int y=0;y<h;y++){point(dst,w,h,pitch,half-1,y,2);point(dst,w,h,pitch,half,y,2);}
    int title_y=oy>=20?oy-20:2;
    label(dst,w,h,pitch,8,title_y,"CAMERA",2);
    label(dst,w,h,pitch,half+8,title_y,ml_active?(s->feedback?"FACE CHECK":"YUNET"):"ML OFF",2);
    if(ml_active)draw_feedback(s->feedback,dst,w,h,pitch,half,half);
    return 0;
}
