#include "yunet.h"
#include "config.h"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void preprocessing(void) {
    uint8_t *src=malloc(640*320*3);int8_t *dst=malloc(320*320*3);assert(src&&dst);
    for(size_t i=0;i<640*320;i++){src[i*3]=1;src[i*3+1]=100;src[i*3+2]=255;}
    yunet_transform tr;
    assert(!yunet_preprocess(src,640,320,640*3,-1,dst,&tr));
    assert(tr.resized_width==320&&tr.resized_height==160);
    for(int y=0;y<320;y++)for(int x=0;x<320;x++) {
        size_t p=((size_t)y*320+x)*3;
        assert(dst[p]==(y<160?1:0));assert(dst[p+1]==(y<160?50:0));assert(dst[p+2]==(y<160?127:0));
    }
    assert(yunet_preprocess(src,640,320,1,-1,dst,&tr));
    free(src);free(dst);
}
static void decoding(void) {
    yunet_head hs[12];
    const int channels[4]={1,1,4,10};
    for(int j=0;j<12;j++) {
        int side=40>>(j%3),c=channels[j/3];size_t len=(size_t)side*side*c;
        int8_t *p=malloc(len);assert(p);memset(p,j<6?-128:0,len);
        hs[j]=(yunet_head){p,side,side,c,0};
    }
    size_t p=41;
    ((int8_t*)hs[0].data)[p]=10;((int8_t*)hs[3].data)[p]=10;
    yunet_face faces[10];size_t n=999;yunet_transform tr={640,320,320,160};
    assert(!yunet_decode(hs,.9f,.3f,&tr,faces,10,&n));assert(n==1);
    assert(fabsf(faces[0].x-8)<1e-6f&&fabsf(faces[0].y-8)<1e-6f);
    assert(fabsf(faces[0].w-16)<1e-6f&&fabsf(faces[0].h-16)<1e-6f);
    assert(fabsf(faces[0].landmarks[0]-16)<1e-6f);
    /* An overlapping lower-score detection from stride 16 is suppressed. */
    ((int8_t*)hs[1].data)[0]=9;((int8_t*)hs[4].data)[0]=9;
    hs[7].fix_point=1;
    ((int8_t*)hs[7].data)[0]=1;((int8_t*)hs[7].data)[1]=1;
    ((int8_t*)hs[7].data)[2]=-1;((int8_t*)hs[7].data)[3]=-1;
    assert(!yunet_decode(hs,.9f,.3f,&tr,faces,10,&n));assert(n==1);
    /* Output quantization must be per tensor, before sigmoid. */
    ((int8_t*)hs[0].data)[p]=1;hs[0].fix_point=1;
    ((int8_t*)hs[3].data)[p]=1;hs[3].fix_point=1;
    ((int8_t*)hs[1].data)[0]=-128;((int8_t*)hs[4].data)[0]=-128;
    assert(!yunet_decode(hs,.6f,.3f,&tr,faces,10,&n));assert(n==1);
    assert(fabsf(faces[0].score-.62245933f)<1e-6f);
    assert(!yunet_decode(hs,.7f,.3f,&tr,faces,10,&n));assert(n==0);
    hs[0].width=39;assert(yunet_decode(hs,.6f,.3f,&tr,faces,10,&n));
    for(int j=0;j<12;j++)free((void*)hs[j].data);
}
static void nv12(void) {
    uint8_t y[8]={16,235,99,99,16,235,99,99},uv[4]={128,128,99,99},bgr[12];
    assert(!yunet_nv12_to_bgr(y,6,4,uv,2,4,2,2,601,0,bgr));
    for(int i=0;i<12;i++)assert(bgr[i]==(i%6<3?0:255));
    assert(yunet_nv12_to_bgr(y,5,4,uv,2,4,2,2,601,0,bgr));
    assert(yunet_nv12_to_bgr(y,8,4,uv,4,4,2,2,2020,0,bgr));
}
int main(void) {
    preprocessing();decoding();nv12();
    app_config c;assert(!config_load(TEST_CONFIG_PATH,&c));
    assert(c.fingerprint==UINT64_C(0x101000016010406));assert(!strcmp(c.head[0],"op53"));
    puts("C preprocessing, per-head quantization, decode/NMS, strided NV12 and configuration passed");return 0;
}
