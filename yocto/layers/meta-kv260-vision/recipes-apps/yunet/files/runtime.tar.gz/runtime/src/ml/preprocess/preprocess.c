#include "yunet_preprocess.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static int clamp(int x,int lo,int hi) { return x<lo?lo:(x>hi?hi:x); }
int yunet_preprocess(const uint8_t *src,int w,int h,size_t stride,int fix,
                     int8_t *dst,yunet_transform *tr) {
    if(!src||!dst||!tr||w<=0||h<=0||w>16384||h>16384||
       stride<(size_t)w*3||fix < -16||fix>16) return -1;
    double scale=320.0/(w>h?w:h);
    /* nearbyint uses nearest/even, matching Python round used by the reference. */
    int rw=(int)nearbyint(w*scale), rh=(int)nearbyint(h*scale);
    if(rw<1)rw=1;
    if(rh<1)rh=1;
    memset(dst,0,320*320*3);
    for(int y=0;y<rh;y++) {
        double sy=((y+.5)*h/rh)-.5;
        int y0=(int)floor(sy), y1=y0+1;
        double fy=sy-y0;
        y0=clamp(y0,0,h-1); y1=clamp(y1,0,h-1);
        for(int x=0;x<rw;x++) {
            double sx=((x+.5)*w/rw)-.5;
            int x0=(int)floor(sx),x1=x0+1;
            double fx=sx-x0;
            x0=clamp(x0,0,w-1); x1=clamp(x1,0,w-1);
            for(int c=0;c<3;c++) {
                double top=src[(size_t)y0*stride+x0*3+c]*(1-fx)+src[(size_t)y0*stride+x1*3+c]*fx;
                double bottom=src[(size_t)y1*stride+x0*3+c]*(1-fx)+src[(size_t)y1*stride+x1*3+c]*fx;
                int pixel=clamp((int)floor(top*(1-fy)+bottom*fy+.5),0,255);
                int q=(int)floor(ldexp((double)pixel,fix)+.5);
                dst[((size_t)y*320+x)*3+c]=(int8_t)clamp(q,-128,127);
            }
        }
    }
    *tr=(yunet_transform){w,h,rw,rh}; return 0;
}

int yunet_nv12_to_bgr(const uint8_t *y,size_t yl,size_t ys,const uint8_t *uv,
                      size_t uvl,size_t uvs,int w,int h,int matrix,int full,uint8_t *bgr) {
    if(!y||!uv||!bgr||w<=0||h<=0||w>16384||h>16384||(w&1)||(h&1)||
       ys>SIZE_MAX/(size_t)h||uvs>SIZE_MAX/(size_t)h||ys<(size_t)w||uvs<(size_t)w||
       yl<ys*(size_t)(h-1)+(size_t)w||uvl<uvs*(size_t)(h/2-1)+(size_t)w||
       (matrix!=601&&matrix!=709)||(full!=0&&full!=1)) return -1;
    int cy=full?256:298;
    int cb=matrix==601?(full?454:516):(full?475:541);
    int cgu=matrix==601?(full?88:100):(full?48:55);
    int cgv=matrix==601?(full?183:208):(full?120:136);
    int cr=matrix==601?(full?359:409):(full?403:459);
    for(int row=0;row<h;row++)for(int x=0;x<w;x++) {
        int yy=(int)y[(size_t)row*ys+x]-(full?0:16);
        int u=(int)uv[(size_t)(row/2)*uvs+(x&~1)]-128;
        int v=(int)uv[(size_t)(row/2)*uvs+(x&~1)+1]-128;
        if(yy<0)yy=0;
        size_t p=((size_t)row*w+x)*3;
        bgr[p]=(uint8_t)clamp((cy*yy+cb*u+128)>>8,0,255);
        bgr[p+1]=(uint8_t)clamp((cy*yy-cgu*u-cgv*v+128)>>8,0,255);
        bgr[p+2]=(uint8_t)clamp((cy*yy+cr*v+128)>>8,0,255);
    }
    return 0;
}

/* Convert only the four source pixels used by a model-input sample. Saturating
 * each source pixel before interpolation preserves the reference RGB semantics. */
static void nv12_pixel(const uint8_t *y,const uint8_t *uv,size_t ys,size_t uvs,
                       int x,int row,int cy,int cb,int cgu,int cgv,int cr,int offset,
                       uint8_t bgr[3]) {
    int yy=(int)y[(size_t)row*ys+x]-offset;
    int u=(int)uv[(size_t)(row/2)*uvs+(x&~1)]-128;
    int v=(int)uv[(size_t)(row/2)*uvs+(x&~1)+1]-128;
    if(yy<0)yy=0;
    bgr[0]=(uint8_t)clamp((cy*yy+cb*u+128)>>8,0,255);
    bgr[1]=(uint8_t)clamp((cy*yy-cgu*u-cgv*v+128)>>8,0,255);
    bgr[2]=(uint8_t)clamp((cy*yy+cr*v+128)>>8,0,255);
}
int yunet_preprocess_nv12(const uint8_t *y,size_t yl,size_t ys,const uint8_t *uv,
                         size_t uvl,size_t uvs,int w,int h,int matrix,int full,
                         int fix,int8_t *dst,yunet_transform *tr) {
    if(!y||!uv||!dst||!tr||w<2||h<2||w>16384||h>16384||(w&1)||(h&1)||
       ys>SIZE_MAX/(size_t)h||uvs>SIZE_MAX/(size_t)h||ys<(size_t)w||uvs<(size_t)w||
       yl<ys*(size_t)(h-1)+(size_t)w||uvl<uvs*(size_t)(h/2-1)+(size_t)w||
       (matrix!=601&&matrix!=709)||(full!=0&&full!=1)||fix < -16||fix>16)return -1;
    double scale=320.0/(w>h?w:h);
    int rw=(int)nearbyint(w*scale),rh=(int)nearbyint(h*scale);
    if(rw<1)rw=1;
    if(rh<1)rh=1;
    int cy=full?256:298,cb=matrix==601?(full?454:516):(full?475:541);
    int cgu=matrix==601?(full?88:100):(full?48:55);
    int cgv=matrix==601?(full?183:208):(full?120:136);
    int cr=matrix==601?(full?359:409):(full?403:459);
    int8_t quant[256];
    for(int i=0;i<256;i++)quant[i]=(int8_t)clamp((int)floor(ldexp((double)i,fix)+.5),-128,127);
    memset(dst,0,320*320*3);
    /* At 1280x720 -> 320x180, all four bilinear weights are exactly 1/4.
     * This integer path is also valid for any equal, even integer downscale. */
    int factor=w/rw;
    if(factor>=2 && !(factor&1) && w==rw*factor && h==rh*factor) {
        for(int row=0;row<rh;row++)for(int x=0;x<rw;x++) {
            int sx=x*factor+factor/2-1,sy=row*factor+factor/2-1;
            uint8_t a[3],b[3],c[3],d[3];
            nv12_pixel(y,uv,ys,uvs,sx,sy,cy,cb,cgu,cgv,cr,full?0:16,a);
            nv12_pixel(y,uv,ys,uvs,sx+1,sy,cy,cb,cgu,cgv,cr,full?0:16,b);
            nv12_pixel(y,uv,ys,uvs,sx,sy+1,cy,cb,cgu,cgv,cr,full?0:16,c);
            nv12_pixel(y,uv,ys,uvs,sx+1,sy+1,cy,cb,cgu,cgv,cr,full?0:16,d);
            for(int k=0;k<3;k++)dst[((size_t)row*320+x)*3+k]=quant[(a[k]+b[k]+c[k]+d[k]+2)>>2];
        }
    }else{
        for(int row=0;row<rh;row++) {
            double sy=((row+.5)*h/rh)-.5;
            int y0=(int)floor(sy),y1=y0+1;double fy=sy-y0;
            y0=clamp(y0,0,h-1);y1=clamp(y1,0,h-1);
            for(int x=0;x<rw;x++) {
                double sx=((x+.5)*w/rw)-.5;
                int x0=(int)floor(sx),x1=x0+1;double fx=sx-x0;
                x0=clamp(x0,0,w-1);x1=clamp(x1,0,w-1);
                uint8_t a[3],b[3],c[3],d[3];
                nv12_pixel(y,uv,ys,uvs,x0,y0,cy,cb,cgu,cgv,cr,full?0:16,a);
                nv12_pixel(y,uv,ys,uvs,x1,y0,cy,cb,cgu,cgv,cr,full?0:16,b);
                nv12_pixel(y,uv,ys,uvs,x0,y1,cy,cb,cgu,cgv,cr,full?0:16,c);
                nv12_pixel(y,uv,ys,uvs,x1,y1,cy,cb,cgu,cgv,cr,full?0:16,d);
                for(int k=0;k<3;k++){
                    double top=a[k]*(1-fx)+b[k]*fx,bottom=c[k]*(1-fx)+d[k]*fx;
                    int pixel=clamp((int)floor(top*(1-fy)+bottom*fy+.5),0,255);
                    dst[((size_t)row*320+x)*3+k]=quant[pixel];
                }
            }
        }
    }
    *tr=(yunet_transform){w,h,rw,rh};return 0;
}
