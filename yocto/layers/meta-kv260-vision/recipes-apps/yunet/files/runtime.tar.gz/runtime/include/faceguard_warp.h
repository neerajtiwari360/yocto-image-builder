#ifndef FACEGUARD_WARP_H
#define FACEGUARD_WARP_H
#include <stddef.h>
#include <stdint.h>
#include "faceguard.h"
/* Shared PS/HLS kernel: borrowed BGR, caller-owned RGB. No allocation/floats.
 * Q16 inverse transform is computed by the five-landmark fit on the PS.
 * lut maps an interpolated 8-bit pixel to the model's INT8 input scale. */
static int fg_warp_q16(const uint8_t *p,int w,int h,size_t s,int64_t aq,int64_t bq,int64_t xq,int64_t yq,const int8_t lut[768],int8_t out[FG_WIDTH*FG_HEIGHT*3]){
    if(!p||!lut||!out||w<2||h<2||w>16384||h>16384||s<(size_t)w*3||
       aq< -33554432||aq>33554432||bq< -33554432||bq>33554432||
       xq< -2147483647||xq>2147483647||yq< -2147483647||yq>2147483647)return -1;
    for(int v=0;v<FG_HEIGHT;v+=FG_HEIGHT-1)for(int u=0;u<FG_WIDTH;u+=FG_WIDTH-1){
        int64_t x=aq*u-bq*v+xq,y=bq*u+aq*v+yq;
        if(x<0||y<0||x>=((int64_t)(w-1)<<16)||y>=((int64_t)(h-1)<<16))return -1;
    }
    for(int v=0;v<FG_HEIGHT;v++)for(int u=0;u<FG_WIDTH;u++){
        int64_t x=aq*u-bq*v+xq,y=bq*u+aq*v+yq;int ix=(int)(x>>16),iy=(int)(y>>16);
        int64_t fx=x&65535,fy=y&65535;
        for(int c=0;c<3;c++){
            const uint8_t *z=p+(size_t)iy*s+3*(size_t)ix+c;
            int value=(int)((z[0]*(65536-fx)*(65536-fy)+z[3]*fx*(65536-fy)+z[s]*(65536-fx)*fy+z[s+3]*fx*fy+((int64_t)1<<31))>>32);
            out[(v*FG_WIDTH+u)*3+c]=lut[c*256+value];
        }
    }
    return 0;
}
#endif
