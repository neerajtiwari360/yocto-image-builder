#include "capture.h"
#include <errno.h>
#include <fcntl.h>
#include <glob.h>
#include <linux/videodev2.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

typedef struct { void *p[2];size_t length[2]; } mapping;
struct camera {
    int fd,width,height,mplane,planes,streaming,held;
    enum v4l2_buf_type type;
    unsigned count;
    size_t stride[2];
    int matrix,full_range;
    mapping maps[32];
    struct v4l2_buffer active;
    struct v4l2_plane active_planes[VIDEO_MAX_PLANES];
};
static int control(int fd,unsigned long code,void *arg) {
    int rc;do{rc=ioctl(fd,code,arg);}while(rc<0&&errno==EINTR);return rc;
}
int capture_find_ias(char *device,size_t n) {
    glob_t paths={0};int found=0;
    if(!device||!n||glob("/sys/class/video4linux/video*/name",0,NULL,&paths)!=0)return -1;
    for(size_t i=0;i<paths.gl_pathc;i++) {
        char value[256];FILE *f=fopen(paths.gl_pathv[i],"r");
        if(!f)continue;
        int ok=fgets(value,sizeof(value),f)!=NULL;fclose(f);
        if(ok&&strstr(value,"isp_vcap_csi")) {
            const char *v=strstr(paths.gl_pathv[i],"/video4linux/video");
            if(!v)continue;
            v+=strlen("/video4linux/");
            const char *end=strchr(v,'/');
            if(!end)continue;
            int written=snprintf(device,n,"/dev/%.*s",(int)(end-v),v);
            if(written<0||(size_t)written>=n){found=0;break;}
            found++;
        }
    }
    globfree(&paths);return found==1?0:-1;
}
void capture_close(camera *c) {
    if(!c)return;
    if(c->fd>=0&&c->streaming)control(c->fd,VIDIOC_STREAMOFF,&c->type);
    for(unsigned i=0;i<c->count;i++)for(int p=0;p<c->planes;p++)
        if(c->maps[i].p[p]&&c->maps[i].p[p]!=MAP_FAILED)munmap(c->maps[i].p[p],c->maps[i].length[p]);
    if(c->fd>=0)close(c->fd);
    free(c);
}
static void init_buffer(camera *c,struct v4l2_buffer *b,struct v4l2_plane *planes,unsigned index) {
    memset(b,0,sizeof(*b));memset(planes,0,sizeof(*planes)*VIDEO_MAX_PLANES);
    b->type=c->type;b->memory=V4L2_MEMORY_MMAP;b->index=index;
    if(c->mplane){b->length=(unsigned)c->planes;b->m.planes=planes;}
}
int capture_open(const char *device,int w,int h,camera **out) {
    if(out)*out=NULL;
    if(!device||!out||w<2||h<2||w>16384||h>16384||(w&1)||(h&1))return -1;
    camera *c=calloc(1,sizeof(*c));if(!c)return -1;
    c->fd=open(device,O_RDWR|O_NONBLOCK|O_CLOEXEC);c->held=-1;
    if(c->fd<0)goto fail;
    struct v4l2_capability caps;
    if(control(c->fd,VIDIOC_QUERYCAP,&caps)<0)goto fail;
    unsigned capabilities=(caps.capabilities&V4L2_CAP_DEVICE_CAPS)?caps.device_caps:caps.capabilities;
    if(!(capabilities&V4L2_CAP_STREAMING))goto fail;
    c->mplane=!!(capabilities&V4L2_CAP_VIDEO_CAPTURE_MPLANE);
    if(!c->mplane&&!(capabilities&V4L2_CAP_VIDEO_CAPTURE))goto fail;
    c->type=c->mplane?V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE:V4L2_BUF_TYPE_VIDEO_CAPTURE;
    struct v4l2_format fmt={0};fmt.type=c->type;
    if(c->mplane) {
        fmt.fmt.pix_mp.width=(unsigned)w;fmt.fmt.pix_mp.height=(unsigned)h;
        fmt.fmt.pix_mp.pixelformat=V4L2_PIX_FMT_NV12;fmt.fmt.pix_mp.field=V4L2_FIELD_NONE;
    }else {
        fmt.fmt.pix.width=(unsigned)w;fmt.fmt.pix.height=(unsigned)h;
        fmt.fmt.pix.pixelformat=V4L2_PIX_FMT_NV12;fmt.fmt.pix.field=V4L2_FIELD_NONE;
    }
    if(control(c->fd,VIDIOC_S_FMT,&fmt)<0)goto fail;
    unsigned format,colorspace,encoding,quantization;
    if(c->mplane) {
        c->width=(int)fmt.fmt.pix_mp.width;c->height=(int)fmt.fmt.pix_mp.height;
        format=fmt.fmt.pix_mp.pixelformat;c->planes=fmt.fmt.pix_mp.num_planes;
        if(c->planes<1||c->planes>2)goto fail;
        c->stride[0]=fmt.fmt.pix_mp.plane_fmt[0].bytesperline;
        c->stride[1]=c->planes==2?fmt.fmt.pix_mp.plane_fmt[1].bytesperline:c->stride[0];
        colorspace=fmt.fmt.pix_mp.colorspace;encoding=fmt.fmt.pix_mp.ycbcr_enc;quantization=fmt.fmt.pix_mp.quantization;
    }else {
        c->width=(int)fmt.fmt.pix.width;c->height=(int)fmt.fmt.pix.height;
        format=fmt.fmt.pix.pixelformat;c->planes=1;
        c->stride[0]=c->stride[1]=fmt.fmt.pix.bytesperline;
        colorspace=fmt.fmt.pix.colorspace;encoding=fmt.fmt.pix.ycbcr_enc;quantization=fmt.fmt.pix.quantization;
    }
    if((format!=V4L2_PIX_FMT_NV12&&format!=V4L2_PIX_FMT_NV12M)||
       (format==V4L2_PIX_FMT_NV12M&&c->planes!=2)||
       c->width<=0||c->height<=0||c->width>16384||c->height>16384||
       (c->width&1)||(c->height&1)||c->stride[0]<(size_t)c->width||c->stride[1]<(size_t)c->width)goto fail;
    if(encoding==V4L2_YCBCR_ENC_DEFAULT)encoding=V4L2_MAP_YCBCR_ENC_DEFAULT(colorspace);
    if(quantization==V4L2_QUANTIZATION_DEFAULT)quantization=V4L2_MAP_QUANTIZATION_DEFAULT(0,colorspace,encoding);
    if(encoding==V4L2_YCBCR_ENC_601||encoding==V4L2_YCBCR_ENC_SYCC)c->matrix=601;
    else if(encoding==V4L2_YCBCR_ENC_709)c->matrix=709;
    else {fprintf(stderr,"Unsupported V4L2 color encoding %u\n",encoding);goto fail;}
    if(quantization!=V4L2_QUANTIZATION_LIM_RANGE&&quantization!=V4L2_QUANTIZATION_FULL_RANGE)goto fail;
    c->full_range=quantization==V4L2_QUANTIZATION_FULL_RANGE;
    fprintf(stderr,"Camera %dx%d NV12, strides %zu/%zu, BT.%d %s range\n",c->width,c->height,c->stride[0],c->stride[1],c->matrix,c->full_range?"full":"limited");
    struct v4l2_requestbuffers req={0};req.type=c->type;req.memory=V4L2_MEMORY_MMAP;req.count=3;
    if(control(c->fd,VIDIOC_REQBUFS,&req)<0||req.count<2||req.count>32)goto fail;
    c->count=req.count;
    for(unsigned i=0;i<c->count;i++) {
        struct v4l2_buffer b;struct v4l2_plane planes[VIDEO_MAX_PLANES];
        init_buffer(c,&b,planes,i);
        if(control(c->fd,VIDIOC_QUERYBUF,&b)<0)goto fail;
        for(int p=0;p<c->planes;p++) {
            size_t len=c->mplane?planes[p].length:b.length;
            off_t offset=c->mplane?(off_t)planes[p].m.mem_offset:(off_t)b.m.offset;
            c->maps[i].length[p]=len;
            c->maps[i].p[p]=mmap(NULL,len,PROT_READ|PROT_WRITE,MAP_SHARED,c->fd,offset);
            if(c->maps[i].p[p]==MAP_FAILED)goto fail;
        }
        if(control(c->fd,VIDIOC_QBUF,&b)<0)goto fail;
    }
    if(control(c->fd,VIDIOC_STREAMON,&c->type)<0)goto fail;
    c->streaming=1;*out=c;return 0;
fail:
    perror("V4L2 NV12 capture setup");capture_close(c);return -1;
}
int capture_acquire(camera *c,nv12_frame *frame) {
    if(!c||!frame||c->held>=0)return -1;
    struct pollfd pfd={.fd=c->fd,.events=POLLIN};
    int ready=poll(&pfd,1,3000);
    if(ready<=0||!(pfd.revents&POLLIN))return -1;
    init_buffer(c,&c->active,c->active_planes,0);
    if(control(c->fd,VIDIOC_DQBUF,&c->active)<0)return -1;
    unsigned i=c->active.index;
    if(i>=c->count)return -1;
    c->held=(int)i;
    if(c->active.flags&V4L2_BUF_FLAG_ERROR)goto fail;
    const uint8_t *data[2]={0};size_t lengths[2]={0};
    for(int p=0;p<c->planes;p++) {
        size_t used=c->mplane?c->active_planes[p].bytesused:c->active.bytesused;
        size_t offset=c->mplane?c->active_planes[p].data_offset:0;
        if(used>c->maps[i].length[p]||offset>used)goto fail;
        data[p]=(const uint8_t*)c->maps[i].p[p]+offset;lengths[p]=used-offset;
    }
    if(c->planes==1) {
        size_t uv_offset=c->stride[0]*(size_t)c->height;
        if(lengths[0]<uv_offset)goto fail;
        data[1]=data[0]+uv_offset;lengths[1]=lengths[0]-uv_offset;lengths[0]=uv_offset;
    }
    *frame=(nv12_frame){data[0],data[1],lengths[0],lengths[1],c->stride[0],c->stride[1],c->width,c->height,c->matrix,c->full_range};
    return 0;
fail:
    capture_release(c);return -1;
}
int capture_release(camera *c) {
    if(!c||c->held<0)return -1;
    int rc=control(c->fd,VIDIOC_QBUF,&c->active);c->held=-1;return rc;
}
