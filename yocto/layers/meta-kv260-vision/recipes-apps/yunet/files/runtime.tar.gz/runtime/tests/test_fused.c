#include "yunet.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned seed=123456789;
static unsigned char random_byte(void){seed=seed*1664525u+1013904223u;return (unsigned char)(seed>>24);}
int main(void){
    const int shapes[][2]={{2,2},{160,160},{162,242},{318,238},{320,240},{640,480},{1280,720},{1920,1080}};
    const int fixes[]={-3,-1,0,2};int cases=0;
    for(size_t i=0;i<sizeof(shapes)/sizeof(shapes[0]);i++){
        int w=shapes[i][0],h=shapes[i][1];size_t ys=(size_t)w+24,uvs=(size_t)w+16;
        size_t yl=ys*h,uvl=uvs*(h/2);
        unsigned char*y=malloc(yl),*uv=malloc(uvl),*bgr=malloc((size_t)w*h*3);
        signed char *ref=malloc(320*320*3),*fused=malloc(320*320*3);
        assert(y&&uv&&bgr&&ref&&fused);
        for(size_t n=0;n<yl;n++)y[n]=random_byte();
        for(size_t n=0;n<uvl;n++)uv[n]=random_byte();
        for(int matrix=601;matrix<=709;matrix+=108)for(int full=0;full<=1;full++){
            assert(yunet_nv12_to_bgr(y,yl,ys,uv,uvl,uvs,w,h,matrix,full,bgr)==0);
            for(size_t f=0;f<sizeof(fixes)/sizeof(fixes[0]);f++){
                yunet_transform a,b;
                assert(yunet_preprocess(bgr,w,h,(size_t)w*3,fixes[f],ref,&a)==0);
                assert(yunet_preprocess_nv12(y,yl,ys,uv,uvl,uvs,w,h,matrix,full,fixes[f],fused,&b)==0);
                if(memcmp(ref,fused,320*320*3)||memcmp(&a,&b,sizeof(a))){fprintf(stderr,"Mismatch %dx%d matrix=%d full=%d fix=%d\n",w,h,matrix,full,fixes[f]);return 1;}
                cases++;
            }
        }
        yunet_transform t;
        assert(yunet_preprocess_nv12(y,0,ys,uv,uvl,uvs,w,h,601,0,-1,fused,&t)==-1);
        assert(yunet_preprocess_nv12(y,yl,ys,uv,0,uvs,w,h,601,0,-1,fused,&t)==-1);
        assert(yunet_preprocess_nv12(y,yl,ys,uv,uvl,uvs,w,h,123,0,-1,fused,&t)==-1);
        free(y);free(uv);free(bgr);free(ref);free(fused);
    }
    printf("Fused NV12 preprocessing: %d randomized strided/color/fix-point cases byte-identical; invalid lengths rejected\n",cases);
    return 0;
}
