#include "preview_render.h"
#include "yunet_overlay.h"
/* Borrow the status and pixels from the same claimed mailbox slot. */
static yunet_overlay_frame view(const preview_slot *s) {
    return (yunet_overlay_frame){s->width,s->height,s->matrix,s->full_range,
        s->count,s->faces,s->pixels,PREVIEW_BYTES,&s->feedback};
}
int preview_render_nv12(const preview_slot *s,uint8_t *dst,size_t len,int w,int h,size_t pitch) {
    if(!s)return -1;
    yunet_overlay_frame frame=view(s);
    return yunet_overlay_nv12(&frame,dst,len,w,h,pitch);
}
int preview_render_split_nv12(const preview_slot *s,uint8_t *dst,size_t len,int w,int h,size_t pitch,int active) {
    if(!s)return -1;
    yunet_overlay_frame frame=view(s);
    return yunet_overlay_split_nv12(&frame,dst,len,w,h,pitch,active);
}
