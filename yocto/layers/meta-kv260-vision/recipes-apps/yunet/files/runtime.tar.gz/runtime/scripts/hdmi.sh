#!/bin/sh
# Compatibility control for the existing SysV image. New HDMI image uses systemd.
set -eu
pidfile=/run/yunet-hdmi.pid
case "${1:-}" in
start)
    if [ -s "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
        echo 'Preview already running'; exit 0
    fi
    YUNET_HDMI_ARGS='--device /dev/dri/card0 --width 640 --height 480 --fps 15 --layout split'
    if [ -r /etc/default/yunet-hdmi ]; then . /etc/default/yunet-hdmi;
    elif [ -r /opt/yunet/config/yunet-hdmi ]; then . /opt/yunet/config/yunet-hdmi; fi
    # Only local numeric/device arguments from the administrator's config.
    /opt/yunet/bin/yunet-hdmi $YUNET_HDMI_ARGS > /var/log/yunet-hdmi.log 2>&1 &
    echo "$!" > "$pidfile"
    sleep 1
    if ! kill -0 "$(cat "$pidfile")" 2>/dev/null; then
        cat /var/log/yunet-hdmi.log >&2; rm -f "$pidfile"; exit 1
    fi
    ;;
stop)
    if [ -s "$pidfile" ]; then
        pid=$(cat "$pidfile")
        # Do not signal an unrelated process if a stale PID was reused.
        if [ "$(cat /proc/"$pid"/comm 2>/dev/null || true)" = yunet-hdmi ]; then
            kill "$pid"
            for n in 1 2 3 4 5 6; do kill -0 "$pid" 2>/dev/null || break; sleep 1; done
        fi
        rm -f "$pidfile"
    fi
    ;;
status)
    if [ -s "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then echo running; else echo stopped; exit 3; fi
    ;;
*) echo "Usage: $0 {start|stop|status}" >&2; exit 2 ;;
esac
