#ifndef CAPTURE_H
#define CAPTURE_H
#include <stddef.h>
#include <stdint.h>
#include "yunet_version.h"
typedef struct camera camera;
typedef struct {
    const uint8_t *y,*uv;
    size_t y_length,uv_length,y_stride,uv_stride;
    int width,height;
    int matrix,full_range; /* matrix: 601 or 709, negotiated by V4L2 */
} nv12_frame;
int capture_open(const char *device,int width,int height,camera **out);
int capture_acquire(camera *cam,nv12_frame *frame);
/* Preview-only: zero-timeout dequeue, discarding at most the queued buffers. */
int capture_try_latest(camera *cam,nv12_frame *frame);
int capture_release(camera *cam);
void capture_close(camera *cam);
int capture_find_ias(char *device,size_t length);
#endif
