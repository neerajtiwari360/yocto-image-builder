#ifndef YUNET_PREPROCESS_H
#define YUNET_PREPROCESS_H
#include "yunet_types.h"
/* Input is BGR uint8. No /255, channel mean subtraction or RGB swap. */
int yunet_preprocess(const uint8_t *bgr, int width, int height, size_t stride,
                     int fix_point, int8_t *nhwc, yunet_transform *transform);
int yunet_nv12_to_bgr(const uint8_t *y, size_t y_length, size_t y_stride,
                      const uint8_t *uv, size_t uv_length, size_t uv_stride,
                      int width, int height, int matrix, int full_range, uint8_t *bgr);
/* Same tensor as NV12->BGR followed by yunet_preprocess, without a full BGR frame. */
int yunet_preprocess_nv12(const uint8_t *y, size_t y_length, size_t y_stride,
                         const uint8_t *uv, size_t uv_length, size_t uv_stride,
                         int width, int height, int matrix, int full_range,
                         int fix_point, int8_t *nhwc, yunet_transform *transform);
#endif
