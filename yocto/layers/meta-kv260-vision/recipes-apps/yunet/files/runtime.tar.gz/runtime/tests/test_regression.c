#include "yunet_preprocess.h"
#include "yunet_postprocess.h"
#include "yunet_overlay.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static FILE *fixture(const char *name) {
    char path[2048];snprintf(path,sizeof path,"%s/%s",FIXTURE_DIR,name);
    FILE *f=fopen(path,"rb");if(!f){perror(path);exit(1);}return f;
}
static unsigned char *load(const char *name,size_t size) {
    unsigned char *p=malloc(size);assert(p);FILE *f=fixture(name);
    assert(fread(p,1,size,f)==size);assert(fgetc(f)==EOF);assert(!fclose(f));return p;
}
int main(void) {
    const size_t frame_bytes=320*180*3/2,input_bytes=320*320*3;
    unsigned char *frame=load("camera-320x180.nv12",frame_bytes);
    unsigned char *gold=load("input.int8",input_bytes);
    int8_t *input=malloc(input_bytes);assert(input);yunet_transform tr;
    assert(!yunet_preprocess_nv12(frame,320*180,320,frame+320*180,320*90,320,320,180,601,0,-1,input,&tr));
    assert(!memcmp(input,gold,input_bytes));assert(tr.resized_width==320&&tr.resized_height==180);
    const int fixes[12]={5,8,6,1,2,2,5,7,5,4,6,5};
    unsigned char *raw=load("heads.int8",33600);yunet_head heads[12];size_t offset=0;
    for(int i=0;i<12;i++){
        int side=40>>(i%3),channels=(int[]){1,1,4,10}[i/3];
        heads[i]=(yunet_head){(const int8_t*)raw+offset,side,side,channels,fixes[i]};offset+=(size_t)side*side*channels;
    }
    assert(offset==33600);yunet_face faces[100];size_t count=0;
    assert(!yunet_decode(heads,.9f,.3f,&tr,faces,100,&count));
    FILE *expected=fixture("faces.txt");unsigned n;assert(fscanf(expected,"%u",&n)==1&&n==count);
    for(size_t i=0;i<count;i++){
        float actual[15]={faces[i].x,faces[i].y,faces[i].w,faces[i].h};
        memcpy(actual+4,faces[i].landmarks,10*sizeof(float));actual[14]=faces[i].score;
        for(int k=0;k<15;k++){float value;assert(fscanf(expected,"%f",&value)==1);assert(isfinite(actual[k])&&fabsf(actual[k]-value)<=1e-4f+1e-5f*fabsf(value));}
    }
    assert(!fclose(expected));
    yunet_face annotation={.x=100,.y=40,.w=100,.h=100,.landmarks={120,70,170,70,145,90,125,115,165,115},.score=.95f};
    yunet_overlay_frame view={320,180,601,0,1,&annotation,frame,frame_bytes,NULL};
    size_t bytes=640*480*3/2;unsigned char *output=malloc(bytes);assert(output);
    unsigned char *overlay=load("overlay.nv12",bytes);
    assert(!yunet_overlay_split_nv12(&view,output,bytes,640,480,640,1));assert(!memcmp(output,overlay,bytes));
    free(frame);free(gold);free(input);free(raw);free(output);free(overlay);
    puts("Recorded frame preprocessing and overlay byte-exact; saved-head detections within 1e-4 + 1e-5 relative");return 0;
}
