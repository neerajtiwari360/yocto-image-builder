"""Generate local-only parity fixtures from the lab's pinned images and Vitis dumps."""
from pathlib import Path
import json
import cv2
import numpy as np

root=Path(__file__).resolve().parents[1]
lab=root.parent/'conversion/reports/vitis-build'
inspection=json.loads((lab/'compiled-smartcam/inspection.json').read_text())
meta=json.loads((lab/'metadata.json').read_text())
quant=np.load(lab/'quantized-outputs.npz')
out=root/'tests/fixtures';out.mkdir(parents=True,exist_ok=True)
import sys
sys.path.insert(0,str(root.parent/'conversion'))
from evaluate_vitis import decode
cases=[]
for i,name in enumerate(meta['images']):
    image=cv2.imread(str(root.parent/'calibration/images'/name))
    h,w=image.shape[:2];scale=320/max(h,w)
    rw,rh=max(1,round(w*scale)),max(1,round(h*scale))
    canvas=np.zeros((320,320,3),np.uint8);canvas[:rh,:rw]=cv2.resize(image,(rw,rh))
    image.tofile(out/f'{i}-bgr.bin')
    np.clip(np.floor(canvas.astype(np.float32)*.5+.5),-128,127).astype(np.int8).tofile(out/f'{i}-input.bin')
    heads=[];infos=[]
    for j,module in enumerate(meta['head_module_names']):
        tensor=next(t for t in inspection['outputs'] if '_'+module+'__' in t['name'])
        raw=quant[f'image_{i}_head_{j}'].transpose(0,2,3,1)
        fix=tensor['fix_point']
        ints=np.clip(np.floor(raw*2.**fix+.5),-128,127).astype(np.int8)
        ints.tofile(out/f'{i}-head{j}.bin')
        value=ints.astype(np.float32)*2.**(-fix)
        if j<6:value=1/(1+np.exp(-value))
        heads.append(value.reshape(1,-1,value.shape[-1]))
        infos.append({'height':raw.shape[1],'width':raw.shape[2],'channels':raw.shape[3],'fix_point':fix})
    expected={}
    for threshold in (.9,.7,.5):
        faces=decode(heads,threshold)
        faces[:,:14:2]*=w/rw;faces[:,1:14:2]*=h/rh
        expected[str(threshold)]=faces.tolist()
    cases.append({'index':i,'image':name,'width':w,'height':h,'resized_width':rw,'resized_height':rh,'heads':infos,'expected':expected})
(out/'cases.json').write_text(json.dumps(cases,indent=2))
print(f'Prepared {len(cases)} images with twelve INT8 heads and reference detections')
