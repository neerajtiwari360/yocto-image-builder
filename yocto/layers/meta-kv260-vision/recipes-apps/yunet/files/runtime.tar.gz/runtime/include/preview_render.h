#ifndef PREVIEW_RENDER_H
#define PREVIEW_RENDER_H
#include "preview.h"
/* Render into an owned DRM back buffer; never alter the shared source frame. */
int preview_render_nv12(const preview_slot *s,uint8_t *dst,size_t length,
                        int width,int height,size_t pitch);
/* Equal synchronized columns: clean camera left; annotations only on right.
 * ml_active=0 shows clean video on both sides with an ML OFF caption. */
int preview_render_split_nv12(const preview_slot *s,uint8_t *dst,size_t length,
                              int width,int height,size_t pitch,int ml_active);
#endif
