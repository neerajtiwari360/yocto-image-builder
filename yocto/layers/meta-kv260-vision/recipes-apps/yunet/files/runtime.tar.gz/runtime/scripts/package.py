"""Package ARM64 ELF dependencies from the exact SDK; never copy host libraries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--sysroot',type=Path,required=True)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--readelf',required=True)
    p.add_argument('--runtime-from-image',action='store_true',help='Audit dependencies but rely on the matching image for them')
    a=p.parse_args()
    root=a.sysroot.resolve()
    def inspect(path,option):
        return subprocess.check_output([a.readelf,option,str(path)],text=True,stderr=subprocess.STDOUT)
    def arm64(path):
        if not re.search(r'Machine:\s+AArch64',inspect(path,'-h')):
            raise RuntimeError('Not ARM64 ELF: '+str(path))
    def resolve(path):
        # Sysroot links may be absolute target paths; never resolve them on the host.
        for _ in range(64):
            if not path.is_symlink():
                if not path.is_file(): raise FileNotFoundError(path)
                if root not in path.parents: raise RuntimeError('Dependency escaped SDK sysroot')
                return path
            value=os.readlink(path)
            path=Path(os.path.normpath(str(root/value.lstrip('/') if value.startswith('/') else path.parent/value)))
            if root not in path.parents: raise RuntimeError('Dependency link escaped SDK sysroot')
        raise RuntimeError('Dependency symlink loop')
    locations=[root/'usr/lib',root/'lib',root/'usr/lib64',root/'lib64']
    def find(name):
        if '/' in name: raise RuntimeError('Unexpected dependency path: '+name)
        for directory in locations:
            candidate=directory/name
            if candidate.exists() or candidate.is_symlink(): return resolve(candidate)
        raise FileNotFoundError('SDK runtime dependency missing: '+name)
    arm64(a.binary)
    model=a.source/'model/yunet_smartcam.xmodel'
    inspection=json.loads((a.source/'model/inspection.json').read_text())
    model_manifest=json.loads((a.source/'model/manifest.json').read_text())
    if int(inspection['fingerprint'],0)!=0x101000016010406 or inspection['dpu_subgraphs']!=1:
        raise RuntimeError('Expected verified SmartCam B3136 model')
    if sha(model)!=model_manifest['model_sha256']: raise RuntimeError('Model SHA256 mismatch')
    target_manifest=Path(os.environ.get('YUNET_TARGET_MANIFEST','/opt/sdk-provenance/target.manifest'))
    versions={}
    for line in target_manifest.read_text().splitlines():
        parts=line.split()
        if len(parts)>=3: versions[parts[0]]=parts[-1]
    for package in ('vart','xir'):
        matches={k:v for k,v in versions.items() if (k==package or k.startswith('lib'+package)) and '-dev' not in k and '-dbg' not in k}
        if not matches or not all(v.startswith('3.5') for v in matches.values()):
            raise RuntimeError('SDK manifest must contain '+package+' 3.5: '+str(matches))
    # The glibc loader and its components must come from the matching board OS.
    base=re.compile(r'^(ld-linux-aarch64\.so\.1|lib(c|m|pthread|dl|rt|resolv|util|anl)\.so\.[0-9]+)$')
    required={};provided={};queue=[]
    def dependencies(path):
        return re.findall(r'\(NEEDED\).*?\[(.*?)\]',inspect(path,'-d'))
    queue.extend(dependencies(a.binary))
    # Runner and XRT load these plugins dynamically, outside the ELF NEEDED graph.
    queue.extend(['libvart-dpu-runner.so','libxrt_core.so'])
    with tempfile.TemporaryDirectory(prefix='yunet-package-') as tmp:
        stage=Path(tmp)/'yunet-kv260';(stage/'bin').mkdir(parents=True)
        (stage/'model').mkdir();(stage/'config').mkdir();(stage/'lib').mkdir()
        shutil.copy2(a.binary,stage/'bin/yunet-kv260')
        shutil.copy2(model,stage/'model/yunet_smartcam.xmodel')
        shutil.copy2(a.source/'config/yunet.conf',stage/'config/yunet.conf')
        shutil.copy2(a.source/'scripts/run.sh',stage/'run.sh');(stage/'run.sh').chmod(0o755)
        while queue:
            name=queue.pop(0)
            if name in required or name in provided: continue
            path=find(name);arm64(path)
            item={'sha256':sha(path),'sdk_path':str(path.relative_to(root))}
            if base.fullmatch(name) or a.runtime_from_image: provided[name]=item
            else:
                required[name]=item
                destination=stage/'lib'/path.name
                if destination.exists() and sha(destination)!=item['sha256']:
                    raise RuntimeError('Conflicting runtime library names')
                if not destination.exists(): shutil.copy2(path,destination)
                if name!=path.name:
                    alias=stage/'lib'/name
                    if not alias.exists() and not alias.is_symlink(): alias.symlink_to(path.name)
            queue.extend(dependencies(path))
        # Include the interpreter in the audited OS requirements explicitly.
        program=inspect(a.binary,'-l')
        interp=re.search(r'Requesting program interpreter:\s*(.*?)\]',program)
        if not interp or interp.group(1)!='/lib/ld-linux-aarch64.so.1':
            raise RuntimeError('Unexpected ARM64 dynamic loader')
        loader=find('ld-linux-aarch64.so.1')
        provided['ld-linux-aarch64.so.1']={'sha256':sha(loader),'sdk_path':str(loader.relative_to(root))}
        manifest={'architecture':'aarch64','sdk_sha256':os.environ.get('YUNET_SDK_SHA256'),'target':'kv260-vision-minimal','model_sha256':sha(model),'fingerprint':inspection['fingerprint'],'bundled_libraries':required,'required_from_matching_board_image':provided,'runtime_versions':{k:v for k,v in versions.items() if k in ('vart','xir','xrt') or k.startswith(('libxir','libvart'))},'board_execution':'NOT TESTED','note':'Camera/FPGA firmware, kernel drivers and glibc are supplied by the matching board image; no compiler, headers or sysroot are deployed.'}
        (stage/'manifest.json').write_text(json.dumps(manifest,indent=2))
        (stage/'RUN.txt').write_text('Load the matching KV260 SmartCam image and camera pipeline first.\nRun ./run.sh --frames 300 > faces.jsonl\nFor a known image: ./run.sh --image test.ppm --dump-input input-int8.bin\nDiagnostics and tensor metadata go to stderr; detections go to stdout.\nDo not disable VART hardware fingerprint checks.\n')
        a.output.mkdir(parents=True,exist_ok=True)
        archive=a.output/'yunet-kv260-arm64.tar.gz'
        with tarfile.open(archive,'w:gz') as tar: tar.add(stage,arcname='yunet-kv260')
        shutil.copy2(stage/'manifest.json',a.output/'manifest.json')
        (a.output/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
        print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'bundled_libraries':len(required),'provided_by_os':len(provided)},indent=2))

if __name__=='__main__':main()
