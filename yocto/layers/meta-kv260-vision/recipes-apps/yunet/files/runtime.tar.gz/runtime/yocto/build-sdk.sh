#!/bin/bash
set -eo pipefail
build=/work/builds/scarthgap-kv260/kv260-vision-minimal
exec 9>"$build.lock"
echo 'Waiting for the image build lock...'
flock 9
for attempt in {1..10}; do
    test ! -f /artifacts/kv260-vision-build.exit || break
    sleep 1
done
test -f /artifacts/kv260-vision-build.exit && test "$(cat /artifacts/kv260-vision-build.exit)" = 0 || {
    echo 'A successful matching image build is required before generating the SDK.' >&2
    exit 1
}
source /work/layers/scarthgap-kv260/poky/oe-init-build-env "$build" >/dev/null
bitbake -R /native/yocto/sdk.conf product-vision-minimal -c populate_sdk
destination=/artifacts/sdk/kv260-vision
mkdir -p "$destination"
cp -L "$build"/tmp/deploy/sdk/* "$destination/"
cp /project/yocto/targets/kv260-vision-minimal/sources.conf "$destination/sources.conf"
cp /native/yocto/sdk.conf "$destination/sdk.conf"
(cd "$destination"; find . -maxdepth 1 -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS)
echo "SDK exported to $destination"
