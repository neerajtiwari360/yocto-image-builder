#!/bin/sh
# Run explicitly as root after serial deployment. Enable only the preview;
# this never enables ML inference or changes its model/configuration.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root' >&2; exit 1; }
test -x /opt/yunet/bin/yunet-hdmi
mkdir -p /etc/default
[ -e /etc/default/yunet-hdmi ] || cp /opt/yunet/config/yunet-hdmi /etc/default/yunet-hdmi
if [ "$(cat /proc/1/comm)" = systemd ]; then
    mkdir -p /etc/systemd/system
    cp /opt/yunet/service/yunet-hdmi.service /opt/yunet/service/yunet-inference.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable yunet-hdmi.service
    echo 'Enabled boot preview; use systemctl start/stop yunet-hdmi.'
else
    # Existing, verified image uses SysV init with runlevel 5 and S95 camera setup.
    test -d /etc/rc5.d
    mkdir -p /etc/init.d /etc/rc0.d /etc/rc6.d
    cp /opt/yunet/hdmi.sh /etc/init.d/yunet-hdmi
    chmod 0755 /etc/init.d/yunet-hdmi
    ln -sf ../init.d/yunet-hdmi /etc/rc5.d/S99yunet-hdmi
    ln -sf ../init.d/yunet-hdmi /etc/rc0.d/K01yunet-hdmi
    ln -sf ../init.d/yunet-hdmi /etc/rc6.d/K01yunet-hdmi
    echo 'Enabled boot preview on SysV; use /opt/yunet/hdmi.sh start/stop.'
fi
