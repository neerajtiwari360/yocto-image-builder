#define _GNU_SOURCE
#include "preview_render.h"
#include "capture.h"
#include "camera_guard.h"
#include <drm_fourcc.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/kd.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
typedef struct {uint32_t handle,fb,pitch;size_t size;uint8_t *data;} buffer;
typedef struct {
    int fd,started,pending,tty_fd,tty_mode;
    uint32_t connector,crtc,plane,blob;
    uint32_t blend_plane;
    uint64_t saved_alpha,saved_alpha_enable;
    drmModeModeInfo mode;
    drmModeCrtc *saved;
    buffer bufs[2];
} display;
static volatile sig_atomic_t stopping;
static void stopped(int n){(void)n;stopping=1;}
static int property(int fd,drmModeAtomicReq *r,uint32_t id,uint32_t type,const char *name,uint64_t value) {
    drmModeObjectProperties *ps=drmModeObjectGetProperties(fd,id,type);
    if(!ps)return -1;
    int rc=-1;
    for(uint32_t i=0;i<ps->count_props;i++){
        drmModePropertyRes *p=drmModeGetProperty(fd,ps->props[i]);
        if(p&&!strcmp(p->name,name))rc=drmModeAtomicAddProperty(r,id,p->prop_id,value)<0?-1:0;
        drmModeFreeProperty(p);if(!rc)break;
    }
    drmModeFreeObjectProperties(ps);return rc;
}
static uint64_t property_value(int fd,uint32_t id,uint32_t type,const char *name) {
    uint64_t v=0;drmModeObjectProperties *ps=drmModeObjectGetProperties(fd,id,type);
    if(!ps)return 0;
    for(uint32_t i=0;i<ps->count_props;i++){
        drmModePropertyRes *p=drmModeGetProperty(fd,ps->props[i]);
        if(p&&!strcmp(p->name,name))v=ps->prop_values[i];
        drmModeFreeProperty(p);
    }
    drmModeFreeObjectProperties(ps);return v;
}
static int make_buffer(display *d,buffer *b) {
    struct drm_mode_create_dumb c={0};
    c.width=d->mode.hdisplay;c.height=d->mode.vdisplay*3/2;c.bpp=8;
    if(drmIoctl(d->fd,DRM_IOCTL_MODE_CREATE_DUMB,&c))return -1;
    b->handle=c.handle;b->pitch=c.pitch;b->size=(size_t)c.size;
    uint32_t handles[4]={c.handle,c.handle,0,0},pitches[4]={c.pitch,c.pitch,0,0};
    uint32_t offsets[4]={0,c.pitch*d->mode.vdisplay,0,0};
    if(drmModeAddFB2(d->fd,d->mode.hdisplay,d->mode.vdisplay,DRM_FORMAT_NV12,handles,pitches,offsets,&b->fb,0))return -1;
    struct drm_mode_map_dumb m={0};m.handle=c.handle;
    if(drmIoctl(d->fd,DRM_IOCTL_MODE_MAP_DUMB,&m))return -1;
    void *p=mmap(NULL,b->size,PROT_READ|PROT_WRITE,MAP_SHARED,d->fd,(off_t)m.offset);
    if(p==MAP_FAILED)return -1;
    b->data=p;
    memset(p,16,(size_t)c.pitch*d->mode.vdisplay);
    memset(b->data+(size_t)c.pitch*d->mode.vdisplay,128,(size_t)c.pitch*d->mode.vdisplay/2);
    return 0;
}
static int plane_properties(display *d,drmModeAtomicReq *r,uint32_t fb) {
    int rc=0;
#define P(n,v) rc|=property(d->fd,r,d->plane,DRM_MODE_OBJECT_PLANE,n,v)
    P("FB_ID",fb);P("CRTC_ID",d->crtc);P("SRC_X",0);P("SRC_Y",0);
    P("SRC_W",(uint64_t)d->mode.hdisplay<<16);P("SRC_H",(uint64_t)d->mode.vdisplay<<16);
    P("CRTC_X",0);P("CRTC_Y",0);P("CRTC_W",d->mode.hdisplay);P("CRTC_H",d->mode.vdisplay);
#undef P
    return rc;
}
static void flipped(int fd,unsigned seq,unsigned sec,unsigned usec,void *data) {
    (void)fd;(void)seq;(void)sec;(void)usec;((display *)data)->pending=0;
}
static void display_close(display *d) {
    if(d->fd<0)return;
    if(d->blend_plane){
        drmModeAtomicReq *r=drmModeAtomicAlloc();
        if(r){
            property(d->fd,r,d->blend_plane,DRM_MODE_OBJECT_PLANE,"alpha",d->saved_alpha);
            property(d->fd,r,d->blend_plane,DRM_MODE_OBJECT_PLANE,"g_alpha_en",d->saved_alpha_enable);
            drmModeAtomicCommit(d->fd,r,0,NULL);drmModeAtomicFree(r);
        }
    }
    if(d->started){
        drmModeAtomicReq *r=drmModeAtomicAlloc();
        if(r){
            property(d->fd,r,d->plane,DRM_MODE_OBJECT_PLANE,"FB_ID",0);
            property(d->fd,r,d->plane,DRM_MODE_OBJECT_PLANE,"CRTC_ID",0);
            drmModeAtomicCommit(d->fd,r,0,NULL);drmModeAtomicFree(r);
        }
        if(d->saved&&d->saved->mode_valid)
            drmModeSetCrtc(d->fd,d->crtc,d->saved->buffer_id,d->saved->x,d->saved->y,&d->connector,1,&d->saved->mode);
        else drmModeSetCrtc(d->fd,d->crtc,0,0,0,NULL,0,NULL);
    }
    for(int i=0;i<2;i++){
        buffer *b=&d->bufs[i];
        if(b->data)munmap(b->data,b->size);
        if(b->fb)drmModeRmFB(d->fd,b->fb);
        if(b->handle){struct drm_mode_destroy_dumb x={0};x.handle=b->handle;drmIoctl(d->fd,DRM_IOCTL_MODE_DESTROY_DUMB,&x);}
    }
    if(d->blob)drmModeDestroyPropertyBlob(d->fd,d->blob);
    drmModeFreeCrtc(d->saved);drmDropMaster(d->fd);close(d->fd);d->fd=-1;
    if(d->tty_fd>=0){ioctl(d->tty_fd,KDSETMODE,d->tty_mode);close(d->tty_fd);d->tty_fd=-1;}
}
static int display_open(display *d,const char *device,int probe,int width,int height) {
    d->fd=open(device,O_RDWR|O_CLOEXEC);
    if(d->fd<0){perror(device);return -1;}
    if(drmSetClientCap(d->fd,DRM_CLIENT_CAP_UNIVERSAL_PLANES,1)||drmSetClientCap(d->fd,DRM_CLIENT_CAP_ATOMIC,1)){perror("DRM atomic capability");return -1;}
    drmVersionPtr ver=drmGetVersion(d->fd);
    fprintf(stderr,"DRM %s: %.*s\n",device,ver?ver->name_len:0,ver?ver->name:"");drmFreeVersion(ver);
    drmModeRes *res=drmModeGetResources(d->fd);
    if(!res){fprintf(stderr,"No KMS resources (do not select the zocl DPU node)\n");return -1;}
    int crtc_index=-1;
    for(int i=0;i<res->count_connectors;i++){
        drmModeConnector *c=drmModeGetConnector(d->fd,res->connectors[i]);if(!c)continue;
        fprintf(stderr,"Connector %u type=%u connected=%d modes=%d\n",c->connector_id,c->connector_type,c->connection==DRM_MODE_CONNECTED,c->count_modes);
        for(int j=0;j<c->count_modes;j++)fprintf(stderr,"  %s %ux%u @%u\n",c->modes[j].name,c->modes[j].hdisplay,c->modes[j].vdisplay,c->modes[j].vrefresh);
        if(!d->connector&&c->connection==DRM_MODE_CONNECTED&&c->count_modes){
            for(int j=0;j<c->count_modes;j++){
                drmModeModeInfo *m=&c->modes[j];
                if(m->hdisplay==width&&m->vdisplay==height&&!(m->flags&DRM_MODE_FLAG_INTERLACE)&&(!d->mode.clock||m->vrefresh>d->mode.vrefresh))d->mode=*m;
            }
            if(d->mode.clock){
                d->connector=c->connector_id;
                for(int e=0;e<c->count_encoders&&crtc_index<0;e++){
                    drmModeEncoder *enc=drmModeGetEncoder(d->fd,c->encoders[e]);if(!enc)continue;
                    for(int k=0;k<res->count_crtcs;k++)if(enc->possible_crtcs&(1u<<k)){
                        if(enc->crtc_id&&res->crtcs[k]!=enc->crtc_id)continue;
                        crtc_index=k;d->crtc=res->crtcs[k];break;
                    }
                    drmModeFreeEncoder(enc);
                }
            }
        }
        drmModeFreeConnector(c);
    }
    drmModePlaneRes *planes=drmModeGetPlaneResources(d->fd);
    if(planes)for(uint32_t i=0;i<planes->count_planes;i++){
        drmModePlane *p=drmModeGetPlane(d->fd,planes->planes[i]);if(!p)continue;
        fprintf(stderr,"Plane %u possible_crtcs=%x formats:",p->plane_id,p->possible_crtcs);
        int nv12=0;
        for(uint32_t j=0;j<p->count_formats;j++){
            uint32_t f=p->formats[j];fprintf(stderr," %c%c%c%c",f&255,(f>>8)&255,(f>>16)&255,(f>>24)&255);
            if(f==DRM_FORMAT_NV12)nv12=1;
        }
        fputc('\n',stderr);
        if(!d->plane&&nv12&&crtc_index>=0&&(p->possible_crtcs&(1u<<crtc_index)))d->plane=p->plane_id;
        drmModeFreePlane(p);
    }
    drmModeFreePlaneResources(planes);drmModeFreeResources(res);
    if(probe)return 0;
    if(!d->connector||!d->crtc||!d->plane){fprintf(stderr,"Need connected %dx%d mode, compatible CRTC and NV12 plane; see --probe\n",width,height);return -1;}
    if(drmSetMaster(d->fd)){perror("DRM master (stop other display users)");return -1;}
    d->saved=drmModeGetCrtc(d->fd,d->crtc);
    /* fbcon/getty must not redraw the HDMI login console over KMS video.
     * UART administration is unaffected. Restore text mode when preview stops. */
    d->tty_fd=open("/dev/tty1",O_RDWR|O_CLOEXEC|O_NOCTTY);
    if(d->tty_fd>=0){
        if(ioctl(d->tty_fd,KDGETMODE,&d->tty_mode)||ioctl(d->tty_fd,KDSETMODE,KD_GRAPHICS)){
            perror("Suppress HDMI text console");close(d->tty_fd);d->tty_fd=-1;return -1;
        }
    }
    if(make_buffer(d,&d->bufs[0])||make_buffer(d,&d->bufs[1])||drmModeCreatePropertyBlob(d->fd,&d->mode,sizeof(d->mode),&d->blob)){perror("DRM buffers");return -1;}
    drmModeAtomicReq *r=drmModeAtomicAlloc();if(!r)return -1;
    int rc=0;
    /* Disable the old primary plane on our CRTC (e.g. fbcon); no plane from
     * another CRTC is touched. The previous primary is restored on exit. */
    planes=drmModeGetPlaneResources(d->fd);
    if(planes)for(uint32_t i=0;i<planes->count_planes;i++){
        uint32_t id=planes->planes[i];
        drmModePlane *candidate=drmModeGetPlane(d->fd,id);
        int compatible=candidate&&(candidate->possible_crtcs&(1u<<crtc_index));
        drmModeFreePlane(candidate);if(!compatible)continue;
        /* This Xilinx 6.6 driver attaches a GLOBAL compositor alpha to the
         * graphics plane. Its default 255 hides video even when graphics is
         * disabled. Explicit alpha=0 selects the NV12 video layer underneath.
         * Preserve the property so the console is restored when preview stops. */
        uint64_t old_alpha=property_value(d->fd,id,DRM_MODE_OBJECT_PLANE,"alpha");
        uint64_t old_enable=property_value(d->fd,id,DRM_MODE_OBJECT_PLANE,"g_alpha_en");
        if(!property(d->fd,r,id,DRM_MODE_OBJECT_PLANE,"g_alpha_en",1)){
            d->blend_plane=id;d->saved_alpha=old_alpha;d->saved_alpha_enable=old_enable;
            rc|=property(d->fd,r,id,DRM_MODE_OBJECT_PLANE,"alpha",0);
            fprintf(stderr,"Xilinx global graphics alpha: %llu -> 0 (select NV12 video)\n",(unsigned long long)old_alpha);
        }
        if(id!=d->plane&&property_value(d->fd,id,DRM_MODE_OBJECT_PLANE,"CRTC_ID")==d->crtc){
            rc|=property(d->fd,r,id,DRM_MODE_OBJECT_PLANE,"FB_ID",0);
            rc|=property(d->fd,r,id,DRM_MODE_OBJECT_PLANE,"CRTC_ID",0);
        }
    }
    drmModeFreePlaneResources(planes);
    rc|=property(d->fd,r,d->connector,DRM_MODE_OBJECT_CONNECTOR,"CRTC_ID",d->crtc);
    rc|=property(d->fd,r,d->crtc,DRM_MODE_OBJECT_CRTC,"MODE_ID",d->blob);
    rc|=property(d->fd,r,d->crtc,DRM_MODE_OBJECT_CRTC,"ACTIVE",1);
    rc|=plane_properties(d,r,d->bufs[0].fb);
    if(!rc)rc=drmModeAtomicCommit(d->fd,r,DRM_MODE_ATOMIC_ALLOW_MODESET|DRM_MODE_ATOMIC_TEST_ONLY,NULL);
    if(!rc)rc=drmModeAtomicCommit(d->fd,r,DRM_MODE_ATOMIC_ALLOW_MODESET,NULL);
    drmModeAtomicFree(r);
    if(rc){perror("DRM modeset");return -1;}
    d->started=1;
    fprintf(stderr,"Preview NV12 %dx%d @%u, plane=%u crtc=%u; double buffered, no hardware scaling\n",width,height,d->mode.vrefresh,d->plane,d->crtc);
    return 0;
}
static int present(display *d,int back) {
    drmModeAtomicReq *r=drmModeAtomicAlloc();if(!r)return -1;
    int rc=property(d->fd,r,d->plane,DRM_MODE_OBJECT_PLANE,"FB_ID",d->bufs[back].fb);
    if(!rc){d->pending=1;rc=drmModeAtomicCommit(d->fd,r,DRM_MODE_ATOMIC_NONBLOCK|DRM_MODE_PAGE_FLIP_EVENT,d);}
    drmModeAtomicFree(r);if(rc){perror("DRM page flip");return -1;}
    drmEventContext events={0};events.version=2;events.page_flip_handler=flipped;
    uint64_t deadline=preview_now_ns()+500000000u;
    while(d->pending&&!stopping){
        struct pollfd p={d->fd,POLLIN,0};int n=poll(&p,1,50);
        if(n<0&&errno==EINTR)continue;
        if(n<0||(n>0&&(!(p.revents&POLLIN)||drmHandleEvent(d->fd,&events))))return -1;
        if(preview_now_ns()>deadline){fprintf(stderr,"DRM flip timed out; not reusing scanout buffers\n");return -1;}
    }
    return stopping?-1:0;
}
static int fallback_frame(camera **cam,int intent_fd,int camera_fd,
                          preview_writer *writer,uint64_t ns,uint64_t *retry) {
    /* Inference publishes intent before initializing VART. Yield V4L2 and its
     * mappings here; ML never waits for preview during its running frame loop. */
    if(flock(intent_fd,LOCK_EX|LOCK_NB)){
        if(*cam){capture_close(*cam);*cam=NULL;flock(camera_fd,LOCK_UN);fprintf(stderr,"Camera-only preview yielded to inference\n");}
        return -1;
    }
    flock(intent_fd,LOCK_UN);
    if(!*cam){
        if(ns<*retry)return -1;
        *retry=ns+1000000000u;
        if(camera_guard_claim(camera_fd,0))return -1;
        char device[128];
        if(capture_find_ias(device,sizeof(device))||capture_open(device,PREVIEW_WIDTH,PREVIEW_HEIGHT,cam)){
            flock(camera_fd,LOCK_UN);return -1;
        }
        fprintf(stderr,"Camera-only preview active (no DPU inference)\n");
    }
    nv12_frame nv;
    if(capture_try_latest(*cam,&nv))return -1;
    uint8_t *pixels=preview_begin(writer,nv.width,nv.height,ns);
    if(!pixels){capture_release(*cam);return -1;}
    int slot=writer->slot;preview_slot *s=&writer->map->slots[slot];
    size_t w=(size_t)nv.width,h=(size_t)nv.height;
    if(nv.y_length<(h-1)*nv.y_stride+w||nv.uv_length<(h/2-1)*nv.uv_stride+w){
        capture_release(*cam);preview_release(writer->map,slot);writer->slot=-1;return -1;
    }
    for(size_t y=0;y<h;y++)memcpy(pixels+y*w,nv.y+y*nv.y_stride,w);
    for(size_t y=0;y<h/2;y++)memcpy(pixels+w*h+y*w,nv.uv+y*nv.uv_stride,w);
    if(capture_release(*cam)){preview_release(writer->map,slot);writer->slot=-1;return -1;}
    s->feedback=(yunet_feedback){0};
    s->count=0;s->matrix=(uint32_t)nv.matrix;s->full_range=(uint32_t)nv.full_range;s->capture_ns=ns;
    /* This process owns WRITING while rendering, and releases it directly.
     * No READY slot is exposed with fabricated ML metadata. */
    writer->slot=-1;return slot;
}
int main(int argc,char **argv) {
    const char *device="/dev/dri/card0";int fps=15,w=640,h=480,probe=0,fallback=1,split=1;unsigned long limit=0;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--probe")){probe=1;continue;}
        if(!strcmp(argv[i],"--no-camera-fallback")){fallback=0;continue;}
        if(!strcmp(argv[i],"--help")){puts("yunet-hdmi [--device /dev/dri/card0] [--fps 1..30] [--width 640 --height 480] [--frames N] [--probe] [--no-camera-fallback] [--layout split|single]");return 0;}
        if(i+1>=argc)return 2;
        const char *key=argv[i],*value=argv[++i];char *end=NULL;
        if(!strcmp(key,"--device")){device=value;continue;}
        if(!strcmp(key,"--layout")){
            if(!strcmp(value,"split"))split=1;
            else if(!strcmp(value,"single"))split=0;
            else return 2;
            continue;
        }
        errno=0;long n=strtol(value,&end,10);if(errno||*end||n<0||n>1000000)return 2;
        if(!strcmp(key,"--fps"))fps=(int)n;
        else if(!strcmp(key,"--width"))w=(int)n;
        else if(!strcmp(key,"--height"))h=(int)n;
        else if(!strcmp(key,"--frames"))limit=(unsigned long)n;
        else return 2;
    }
    if((split&&(w<8||w%4))||fps<1||fps>30||w<2||w>1920||h<2||h>1080||(w&1)||(h&1))return 2;
    cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(3,&cpus);
    if(sched_setaffinity(0,sizeof(cpus),&cpus)){perror("Pin preview to CPU3");return 1;}
    if(setpriority(PRIO_PROCESS,0,10))perror("Preview nice");
    signal(SIGINT,stopped);signal(SIGTERM,stopped);
    display d={.fd=-1,.tty_fd=-1};preview_mailbox *m=NULL;int fd=-1,lock=-1,rc=1,intent_fd=-1,camera_fd=-1;char temp[128]={0};
    camera *raw_camera=NULL;
    lock=open("/run/yunet-hdmi.lock",O_CREAT|O_RDWR|O_CLOEXEC|O_NOFOLLOW,0600);
    if(lock<0||flock(lock,LOCK_EX|LOCK_NB)){fprintf(stderr,"Another preview viewer is running\n");goto done;}
    if(display_open(&d,device,probe,w,h))goto done;
    if(probe){rc=0;goto done;}
    if(fallback){
        intent_fd=camera_guard_open("/run/yunet-inference.lock");
        camera_fd=camera_guard_open("/run/yunet-camera.lock");
        if(intent_fd<0||camera_fd<0){perror("Camera coordination locks");goto done;}
    }
    snprintf(temp,sizeof(temp),"%s.%ld",PREVIEW_PATH,(long)getpid());
    fd=open(temp,O_CREAT|O_EXCL|O_RDWR|O_CLOEXEC|O_NOFOLLOW,0600);
    if(fd<0||ftruncate(fd,sizeof(*m))){perror("Preview mailbox");goto done;}
    void *mapped=mmap(NULL,sizeof(*m),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if(mapped==MAP_FAILED){perror("Preview mmap");goto done;}
    m=mapped;memset(m,0,sizeof(*m));m->version=PREVIEW_VERSION;m->bytes=sizeof(*m);m->fps=(uint32_t)fps;
    for(int i=0;i<PREVIEW_SLOTS;i++)atomic_init(&m->slots[i].state,PREVIEW_FREE);
    atomic_init(&m->heartbeat_ns,preview_now_ns());atomic_init(&m->magic,0);
    atomic_store_explicit(&m->magic,PREVIEW_MAGIC,memory_order_release);
    if(rename(temp,PREVIEW_PATH)){perror("Publish mailbox");goto done;}temp[0]=0;
    fprintf(stderr,"Layout: %s\n",split?"CAMERA | YUNET (synchronized equal columns)":"single annotated video");
    fprintf(stderr,"Mailbox %zu bytes; CPU3 nice10; %d fps cap; waiting for inference\n",sizeof(*m),fps);
    uint64_t begin=preview_now_ns(),next=begin,last=begin,frames=0,faces=0,max_age=0;int front=0,blank=1;
    uint64_t retry=0,raw_frames=0;preview_writer raw_writer=PREVIEW_WRITER_INIT;raw_writer.map=m;
    while(!stopping&&(!limit||frames<limit)){
        uint64_t ns=preview_now_ns();atomic_store_explicit(&m->heartbeat_ns,ns,memory_order_release);
        int raw_slot=fallback?fallback_frame(&raw_camera,intent_fd,camera_fd,&raw_writer,ns,&retry):-1;
        int slot=preview_take_latest(m),back=1-front,draw=0;
        if(raw_slot>=0){if(slot>=0)preview_release(m,slot);slot=raw_slot;raw_frames++;}
        if(slot>=0){
            preview_slot *s=&m->slots[slot];
            if(ns>=s->capture_ns&&ns-s->capture_ns<500000000u){
                uint64_t age=ns-s->capture_ns;if(age>max_age)max_age=age;
                draw=!(split?preview_render_split_nv12(s,d.bufs[back].data,d.bufs[back].size,w,h,d.bufs[back].pitch,raw_slot<0)
                            :preview_render_nv12(s,d.bufs[back].data,d.bufs[back].size,w,h,d.bufs[back].pitch));
                if(draw){frames++;faces+=s->count;last=ns;blank=0;}
            }
            preview_release(m,slot);
        }
        if(!draw&&!blank&&ns-last>1000000000u){
            memset(d.bufs[back].data,16,(size_t)d.bufs[back].pitch*h);
            memset(d.bufs[back].data+(size_t)d.bufs[back].pitch*h,128,(size_t)d.bufs[back].pitch*h/2);
            draw=1;blank=1;
        }
        if(draw){if(present(&d,back)){if(stopping)break;goto done;}front=back;}
        next+=1000000000u/(unsigned)fps;ns=preview_now_ns();
        if(next<ns)next=ns;
        struct timespec ts={(time_t)(next/1000000000u),(long)(next%1000000000u)};
        while(!stopping&&clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&ts,NULL)==EINTR){}
    }
    fprintf(stderr,"Preview frames=%llu camera_only=%llu faces=%llu elapsed=%.3fs max_frame_age=%.3fms\n",(unsigned long long)frames,(unsigned long long)raw_frames,(unsigned long long)faces,(preview_now_ns()-begin)/1e9,max_age/1e6);
    rc=0;
done:
    capture_close(raw_camera);
    if(camera_fd>=0)close(camera_fd);
    if(intent_fd>=0)close(intent_fd);
    if(m){atomic_store_explicit(&m->heartbeat_ns,0,memory_order_release);unlink(PREVIEW_PATH);munmap(m,sizeof(*m));}
    if(temp[0])unlink(temp);
    if(fd>=0)close(fd);
    display_close(&d);if(lock>=0)close(lock);return stopping?0:rc;
}
