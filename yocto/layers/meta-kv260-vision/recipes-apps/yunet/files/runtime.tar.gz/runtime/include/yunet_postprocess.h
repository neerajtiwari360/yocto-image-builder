#ifndef YUNET_POSTPROCESS_H
#define YUNET_POSTPROCESS_H
#include "yunet_types.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Heads are cls8/16/32, obj8/16/32, bbox8/16/32, kps8/16/32. */
int yunet_decode(const yunet_head heads[YUNET_HEADS], float threshold,
                 float nms_iou, const yunet_transform *transform,
                 yunet_face *faces, size_t capacity, size_t *count);
#ifdef __cplusplus
}
#endif
#endif
