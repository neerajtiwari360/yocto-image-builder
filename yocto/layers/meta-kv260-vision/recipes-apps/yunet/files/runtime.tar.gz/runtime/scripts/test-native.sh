#!/bin/bash
set -euo pipefail
cmake -S /src -B /build -G Ninja -DENABLE_VART=OFF -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Debug
cmake --build /build --parallel 2
ctest --test-dir /build --output-on-failure
cc -std=c11 -D_POSIX_C_SOURCE=200809L -Wall -Wextra -Wpedantic -fsyntax-only -I/src/include /src/src/main.c /src/src/capture.c
python3 /src/tests/parity.py /build/libyunet_core.so /src/tests/fixtures /build/parity.json
