#!/bin/bash
set -euo pipefail
src=${SOURCE_ROOT:-/src}
out=${BUILD_ROOT:-/build}
mkdir -p "$out"
cc -std=c11 -O3 -fPIC -shared -Wall -Wextra -Wpedantic -I"$src/include" "$src/src/yunet.c" "$src/src/config.c" -lm -o "$out/libyunet_core.so"
cc -std=c11 -I"$src/include" "-DTEST_CONFIG_PATH=\"$src/config/yunet.conf\"" "$src/tests/test_core.c" -L"$out" -lyunet_core -lm -o "$out/test-core"
cc -std=c11 -I"$src/include" "$src/tests/test_fused.c" -L"$out" -lyunet_core -lm -o "$out/test-fused"
LD_LIBRARY_PATH="$out" "$out/test-core"
LD_LIBRARY_PATH="$out" "$out/test-fused"
cc -std=c11 -D_POSIX_C_SOURCE=200809L -Wall -Wextra -Wpedantic -fsyntax-only -I"$src/include" "$src/src/main.c" "$src/src/capture.c"

cc -std=c11 -O2 -Wall -Wextra -Wpedantic -I"$src/include" "$src/tests/test_preview.c" "$src/src/preview.c" "$src/src/preview_render.c" -lm -o "$out/test-preview"
"$out/test-preview"

cc -std=c11 -O2 -Wall -Wextra -Wpedantic -I"$src/include" "$src/tests/test_camera_guard.c" "$src/src/camera_guard.c" -o "$out/test-camera-guard"
"$out/test-camera-guard"
