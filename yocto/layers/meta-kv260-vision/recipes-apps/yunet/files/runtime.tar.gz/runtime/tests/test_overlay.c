#include "yunet_overlay.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    uint8_t pixels[8*8*3/2],out[64*64*3/2+8];
    memset(pixels,90,sizeof pixels);memset(out,0xa5,sizeof out);
    yunet_face face={.x=2,.y=2,.w=4,.h=4,.landmarks={4,4,4,4,4,4,4,4,4,4}};
    yunet_overlay_frame f={8,8,601,0,1,&face,pixels,sizeof pixels};
    assert(!yunet_overlay_split_nv12(&f,out,sizeof(out)-8,64,64,64,1));
    assert(out[24*64+8]==90); /* camera column stays clean */
    assert(out[24*64+40]==145); /* box in right column */
    for(size_t i=sizeof(out)-8;i<sizeof(out);i++)assert(out[i]==0xa5);
    for(size_t i=0;i<sizeof pixels;i++)assert(pixels[i]==90);
    f.length--;assert(yunet_overlay_nv12(&f,out,sizeof out,64,64,64)==-1);
    f.length++;f.faces=NULL;assert(yunet_overlay_nv12(&f,out,sizeof out,64,64,64)==-1);
    return 0;
}
