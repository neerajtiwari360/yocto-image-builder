#include "yunet_overlay.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    uint8_t pixels[8*8*3/2],out[64*64*3/2+8];
    memset(pixels,90,sizeof pixels);memset(out,0xa5,sizeof out);
    yunet_face face={.x=2,.y=2,.w=4,.h=4,.landmarks={4,4,4,4,4,4,4,4,4,4}};
    yunet_overlay_frame f={8,8,601,0,1,&face,pixels,sizeof pixels,NULL};
    assert(!yunet_overlay_split_nv12(&f,out,sizeof(out)-8,64,64,64,1));
    assert(out[24*64+8]==90); /* camera column stays clean */
    assert(out[24*64+40]==145); /* box in right column */
    for(size_t i=sizeof(out)-8;i<sizeof(out);i++)assert(out[i]==0xa5);
    for(size_t i=0;i<sizeof pixels;i++)assert(pixels[i]==90);
    f.length--;assert(yunet_overlay_nv12(&f,out,sizeof out,64,64,64)==-1);
    f.length++;f.faces=NULL;assert(yunet_overlay_nv12(&f,out,sizeof out,64,64,64)==-1);
    /* Quality/match status changes only the annotated panel, never the clean
     * source or left camera panel. Last-frame matches cannot survive a reject. */
    size_t bytes=1280*720*3/2;
    uint8_t *matched=malloc(bytes+16),*rejected=malloc(bytes+16);assert(matched&&rejected);
    memset(matched,0xa5,bytes+16);memset(rejected,0xa5,bytes+16);
    yunet_feedback status={.state=YUNET_FEEDBACK_MATCH,.mean=120,.sharpness=80};
    f.faces=&face;f.feedback=&status;
    assert(!yunet_overlay_split_nv12(&f,matched,bytes,1280,720,1280,1));
    status.state=YUNET_FEEDBACK_ADJUST;status.quality_flags=4;
    assert(!yunet_overlay_split_nv12(&f,rejected,bytes,1280,720,1280,1));
    for(int y=0;y<720*3/2;y++)assert(!memcmp(matched+y*1280,rejected+y*1280,638));
    assert(memcmp(matched,rejected,bytes));
    for(size_t i=bytes;i<bytes+16;i++)assert(matched[i]==0xa5&&rejected[i]==0xa5);
    for(size_t i=0;i<sizeof pixels;i++)assert(pixels[i]==90);
    for(unsigned state=0;state<=YUNET_FEEDBACK_NO_MATCH;state++){
        status.state=state;status.test_mode=1;status.quality_flags=255;
        assert(!yunet_overlay_split_nv12(&f,rejected,bytes,1280,720,1280,1));
    }
    free(matched);free(rejected);
    return 0;
}
