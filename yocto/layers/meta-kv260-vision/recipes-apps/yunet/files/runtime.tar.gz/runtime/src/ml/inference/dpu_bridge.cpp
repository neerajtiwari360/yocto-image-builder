#include "dpu_bridge.h"
#include <vart/runner.hpp>
#include <vart/tensor_buffer.hpp>
#include <xir/graph/graph.hpp>
#include <xir/graph/subgraph.hpp>
#include <xir/tensor/tensor.hpp>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void error_message(char *dst,size_t n,const char *message) {
    if(dst&&n)std::snprintf(dst,n,"%s",message);
}
class HostBuffer final:public vart::TensorBuffer {
public:
    explicit HostBuffer(const xir::Tensor *t):vart::TensorBuffer(t),storage(t->get_data_size()){}
    std::pair<uint64_t,size_t> data(const std::vector<int> index={}) override {
        auto shape=get_tensor()->get_shape(); size_t offset=0;
        if(!index.empty()) {
            if(index.size()!=shape.size())return {0,0};
            for(size_t i=0;i<shape.size();i++) {
                if(index[i]<0||index[i]>=shape[i])return {0,0};
                offset=offset*static_cast<size_t>(shape[i])+static_cast<size_t>(index[i]);
            }
        }
        if(offset>=storage.size())return {0,0};
        return {reinterpret_cast<uint64_t>(storage.data()+offset),storage.size()-offset};
    }
    location_t get_location() const override {return location_t::HOST_VIRT;}
    std::vector<int8_t> storage;
};
dpu_tensor_info describe(const xir::Tensor *t) {
    auto shape=t->get_shape();auto type=t->get_data_type();
    if(shape.size()!=4||shape[0]!=1||
       std::any_of(shape.begin(),shape.end(),[](int x){return x<=0;})||
       type.type!=xir::DataType::XINT||type.bit_width!=8||!t->has_attr("fix_point"))
        throw std::runtime_error("Expected fixed INT8 NHWC rank-four batch-one tensor: "+t->get_name());
    dpu_tensor_info info{};
    if(t->get_name().size()>=sizeof(info.name))throw std::runtime_error("Tensor name too long");
    std::snprintf(info.name,sizeof(info.name),"%s",t->get_name().c_str());
    std::copy(shape.begin(),shape.end(),info.dims);
    info.fix_point=t->get_attr<int>("fix_point");info.bytes=t->get_data_size();
    if(info.fix_point < -16||info.fix_point>16)throw std::runtime_error("Unsupported fix_point");
    return info;
}
}
struct dpu_context {
    std::unique_ptr<xir::Graph> graph;
    std::unique_ptr<vart::Runner> runner;
    std::vector<std::unique_ptr<HostBuffer>> inputs,outputs;
    std::vector<dpu_tensor_info> input_info,output_info;
};
extern "C" int dpu_open(const char *model,uint64_t fingerprint,dpu_context **out,char *error,size_t n) {
    if(out)*out=nullptr;
    if(!model||!out||!fingerprint){error_message(error,n,"Invalid model/context/fingerprint");return -1;}
    try {
        auto ctx=std::make_unique<dpu_context>();ctx->graph=xir::Graph::deserialize(model);
        const xir::Subgraph *dpu=nullptr;
        for(auto *sg:ctx->graph->get_root_subgraph()->children_topological_sort()) {
            if(sg->has_attr("device")&&sg->get_attr<std::string>("device")=="DPU") {
                if(dpu)throw std::runtime_error("Only single-DPU-subgraph models are supported");
                dpu=sg;
            }
        }
        if(!dpu||!dpu->has_attr("dpu_fingerprint")||dpu->get_attr<uint64_t>("dpu_fingerprint")!=fingerprint)
            throw std::runtime_error("Compiled model DPU fingerprint does not match configuration");
        ctx->runner=vart::Runner::create_runner(dpu,"run");
        if(!ctx->runner)throw std::runtime_error("VART could not create runner");
        if(ctx->runner->get_tensor_format()!=vart::Runner::TensorFormat::NHWC)
            throw std::runtime_error("Runner must expose NHWC tensors");
        for(auto *t:ctx->runner->get_input_tensors()) {
            ctx->input_info.push_back(describe(t));ctx->inputs.push_back(std::make_unique<HostBuffer>(t));
        }
        for(auto *t:ctx->runner->get_output_tensors()) {
            ctx->output_info.push_back(describe(t));ctx->outputs.push_back(std::make_unique<HostBuffer>(t));
        }
        if(ctx->inputs.size()!=1||ctx->outputs.size()!=12)throw std::runtime_error("Expected one input and twelve raw YuNet heads");
        auto &s=ctx->input_info[0];
        if(s.dims[1]!=320||s.dims[2]!=320||s.dims[3]!=3||s.bytes!=320*320*3)
            throw std::runtime_error("Expected YuNet input [1,320,320,3] INT8");
        *out=ctx.release();return 0;
    }catch(const std::exception &e){error_message(error,n,e.what());return -1;}
    catch(...){error_message(error,n,"Unknown VART error");return -1;}
}
extern "C" void dpu_close(dpu_context *ctx){delete ctx;}
extern "C" int dpu_input(dpu_context *ctx,dpu_tensor_info *info,int8_t **data) {
    if(!ctx||!info||!data)return -1;
    *info=ctx->input_info[0];*data=ctx->inputs[0]->storage.data();return 0;
}
extern "C" size_t dpu_output_count(const dpu_context *ctx){return ctx?ctx->outputs.size():0;}
extern "C" int dpu_output(dpu_context *ctx,size_t i,dpu_tensor_info *info,const int8_t **data) {
    if(!ctx||!info||!data||i>=ctx->outputs.size())return -1;
    *info=ctx->output_info[i];*data=ctx->outputs[i]->storage.data();return 0;
}
extern "C" int dpu_run(dpu_context *ctx,char *error,size_t n) {
    if(!ctx){error_message(error,n,"Null context");return -1;}
    try {
        std::vector<vart::TensorBuffer*> inputs,outputs;
        for(auto &b:ctx->inputs){b->sync_for_write(0,b->storage.size());inputs.push_back(b.get());}
        for(auto &b:ctx->outputs)outputs.push_back(b.get());
        auto job=ctx->runner->execute_async(inputs,outputs);
        if(job.second!=0)throw std::runtime_error("VART execute_async failed: "+std::to_string(job.second));
        int status=ctx->runner->wait(static_cast<int>(job.first),-1);
        if(status!=0)throw std::runtime_error("VART wait failed: "+std::to_string(status));
        for(auto &b:ctx->outputs)b->sync_for_read(0,b->storage.size());
        return 0;
    }catch(const std::exception &e){error_message(error,n,e.what());return -1;}
    catch(...){error_message(error,n,"Unknown VART execution error");return -1;}
}
