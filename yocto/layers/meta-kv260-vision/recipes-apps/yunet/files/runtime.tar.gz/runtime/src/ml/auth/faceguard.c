#include "faceguard.h"
#include "faceguard_warp.h"
#include <math.h>
#include <string.h>
static const double target[10]={30.2946,51.6963,65.5318,51.5014,48.0252,71.7366,33.5493,92.3655,62.7299,92.2041};
static int valid(const uint8_t *p,int w,int h,size_t s,const yunet_face *f) {
    if(!p||!f||w<3||h<3||w>16384||h>16384||s<(size_t)w*3)return 0;
    if(!isfinite(f->x)||!isfinite(f->y)||!isfinite(f->w)||!isfinite(f->h)||!isfinite(f->score)||f->w<=0||f->h<=0)return 0;
    for(int i=0;i<10;i++)if(!isfinite(f->landmarks[i]))return 0;
    return 1;
}
/* Inverse similarity: source x=a*u-b*v+tx, y=b*u+a*v+ty. */
static int fit(const yunet_face *f,double *a,double *b,double *tx,double *ty,double *error) {
    double u=0,v=0,x=0,y=0,den=0,an=0,bn=0;
    for(int i=0;i<5;i++){u+=target[2*i]/5;v+=target[2*i+1]/5;x+=f->landmarks[2*i]/5.;y+=f->landmarks[2*i+1]/5.;}
    for(int i=0;i<5;i++){
        double du=target[2*i]-u,dv=target[2*i+1]-v,dx=f->landmarks[2*i]-x,dy=f->landmarks[2*i+1]-y;
        den+=du*du+dv*dv;an+=du*dx+dv*dy;bn+=du*dy-dv*dx;
    }
    *a=an/den;*b=bn/den;*tx=x-*a*u+*b*v;*ty=y-*b*u-*a*v;
    double scale=hypot(*a,*b),e=0;
    if(!isfinite(scale)||scale<0.05||scale>512)return -1;
    for(int i=0;i<5;i++){
        double dx=*a*target[2*i]-*b*target[2*i+1]+*tx-f->landmarks[2*i];
        double dy=*b*target[2*i]+*a*target[2*i+1]+*ty-f->landmarks[2*i+1];e+=dx*dx+dy*dy;
    }
    *error=sqrt(e/5)/(scale*35.24);return 0;
}
static int luma(const uint8_t *p,size_t s,int x,int y){p+=s*(size_t)y+3*(size_t)x;return (29*p[0]+150*p[1]+77*p[2]+128)>>8;}
fg_quality_config fg_quality_defaults(void){fg_quality_config c={80,45,210,60,20,0.35f,0.12f,12,0.2f,0.8f,0.9f,0.95f};return c;}
int fg_quality(const uint8_t *p,int w,int h,size_t s,const yunet_face *f,const fg_quality_config *c,fg_quality_result *r){
    if(!r)return -1;
    memset(r,0,sizeof(*r));r->rejected=FG_INVALID;
    if(!c||!valid(p,w,h,s,f))return -1;
    const float values[]={c->min_size,c->min_mean,c->max_mean,c->min_laplacian_variance,c->max_roll,c->max_yaw_proxy,c->max_landmark_error,c->min_region_variance,c->min_pitch_proxy,c->max_pitch_proxy,c->min_score,c->max_size_fraction};
    for(unsigned i=0;i<sizeof(values)/sizeof(values[0]);i++)if(!isfinite(values[i])||values[i]<0)return -1;
    if(c->min_mean>c->max_mean||c->max_mean>255||c->min_pitch_proxy>c->max_pitch_proxy||c->max_pitch_proxy>1||c->min_score>1||c->max_size_fraction>1||c->max_size_fraction<=0)return -1;
    r->rejected=0;
    if(f->x<1||f->y<1||f->x+f->w>w-1||f->y+f->h>h-1){r->rejected=FG_POSITION;return 0;}
    if(f->w<c->min_size||f->h<c->min_size||f->w>w*c->max_size_fraction||f->h>h*c->max_size_fraction)r->rejected|=FG_SIZE;
    if(f->score<c->min_score)r->rejected|=FG_LANDMARKS;
    double a,b,tx,ty,e;
    if(fit(f,&a,&b,&tx,&ty,&e)){r->rejected|=FG_LANDMARKS;return 0;}
    r->landmark_error=(float)e;
    if(e>c->max_landmark_error)r->rejected|=FG_LANDMARKS;
    for(int i=0;i<5;i++)if(f->landmarks[2*i]<f->x||f->landmarks[2*i]>=f->x+f->w||f->landmarks[2*i+1]<f->y||f->landmarks[2*i+1]>=f->y+f->h)r->rejected|=FG_LANDMARKS;
    double ex=f->landmarks[2]-f->landmarks[0],ey=f->landmarks[3]-f->landmarks[1],eyes=hypot(ex,ey);
    if(eyes<1||f->landmarks[1]>=f->landmarks[7]||f->landmarks[3]>=f->landmarks[9]){r->rejected|=FG_LANDMARKS;return 0;}
    r->roll=(float)(fabs(atan2(ey,ex))*180/3.141592653589793);
    r->yaw_proxy=(float)fabs(((f->landmarks[4]-(f->landmarks[0]+f->landmarks[2])/2)*ex+(f->landmarks[5]-(f->landmarks[1]+f->landmarks[3])/2)*ey)/(eyes*eyes));
    double eye_x=(f->landmarks[0]+f->landmarks[2])/2,eye_y=(f->landmarks[1]+f->landmarks[3])/2;
    double vertical=-(f->landmarks[6]/2+f->landmarks[8]/2-eye_x)*ey+(f->landmarks[7]/2+f->landmarks[9]/2-eye_y)*ex;
    if(vertical<=0){r->rejected|=FG_LANDMARKS;return 0;}
    r->pitch_proxy=(float)((-(f->landmarks[4]-eye_x)*ey+(f->landmarks[5]-eye_y)*ex)/vertical);
    if(r->roll>c->max_roll||r->yaw_proxy>c->max_yaw_proxy||r->pitch_proxy<c->min_pitch_proxy||r->pitch_proxy>c->max_pitch_proxy)r->rejected|=FG_POSE;
    double sum=0,ls=0,lss=0,rs[4]={0},rss[4]={0};unsigned n=0,rn[4]={0};
    int x0=(int)f->x,y0=(int)f->y,x1=(int)(f->x+f->w),y1=(int)(f->y+f->h);
    for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++){
        int z=luma(p,s,x,y),lap=4*z-luma(p,s,x-1,y)-luma(p,s,x+1,y)-luma(p,s,x,y-1)-luma(p,s,x,y+1);
        unsigned q=(x>=x0+(x1-x0)/2)+2*(y>=y0+(y1-y0)/2);
        sum+=z;ls+=lap;lss+=(double)lap*lap;n++;rs[q]+=z;rss[q]+=(double)z*z;rn[q]++;
    }
    if(!n){r->rejected|=FG_INVALID;return -1;}
    r->mean=(float)(sum/n);r->laplacian_variance=(float)(lss/n-(ls/n)*(ls/n));
    if(r->mean<c->min_mean||r->mean>c->max_mean)r->rejected|=FG_LIGHT;
    if(r->laplacian_variance<c->min_laplacian_variance)r->rejected|=FG_BLUR;
    for(int q=0;q<4;q++)if(!rn[q]||rss[q]/rn[q]-(rs[q]/rn[q])*(rs[q]/rn[q])<c->min_region_variance)r->rejected|=FG_OCCLUSION_PROXY;
    return 0;
}
int fg_align(const uint8_t *p,int w,int h,size_t s,const yunet_face *f,int fix,int8_t *out){
    double a,b,tx,ty,e;
    if(!out||!valid(p,w,h,s,f)||fix< -16||fix>16||fit(f,&a,&b,&tx,&ty,&e))return -1;
    if(!isfinite(tx)||!isfinite(ty)||fabs(tx)>32767||fabs(ty)>32767)return -1;
    int64_t aq=llround(a*65536),bq=llround(b*65536),xq=llround(tx*65536),yq=llround(ty*65536);
    int8_t lut[768];
    for(int c=0;c<3;c++)for(int value=0;value<256;value++){
        int64_t num=2*value-255,den=255;
        if(fix>=0)num*=((int64_t)1<<fix);else den*=((int64_t)1<<(-fix));
        int q=(int)(num>=0?(num+den/2)/den:-((-num+den/2)/den));
        lut[c*256+value]=(int8_t)(q< -128?-128:q>127?127:q);
    }
    return fg_warp_q16(p,w,h,s,aq,bq,xq,yq,lut,out);
}
