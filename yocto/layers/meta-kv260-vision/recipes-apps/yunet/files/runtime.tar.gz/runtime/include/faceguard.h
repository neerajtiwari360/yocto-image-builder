#ifndef FACEGUARD_H
#define FACEGUARD_H
#include "yunet_types.h"
#ifdef __cplusplus
extern "C" {
#endif
#define FG_SIDE 112
#define FG_WIDTH 96
#define FG_HEIGHT 112
#define FG_DIM 512
#define FG_PREPROCESS_ID "amd-resnet20-112x96-bgr-q16-minus127.5-div127.5-v1"
enum { FG_POSITION=1, FG_SIZE=2, FG_BLUR=4, FG_LIGHT=8, FG_POSE=16,
       FG_LANDMARKS=32, FG_OCCLUSION_PROXY=64, FG_INVALID=128 };
typedef struct {
    float min_size, min_mean, max_mean, min_laplacian_variance;
    float max_roll, max_yaw_proxy, max_landmark_error, min_region_variance;
    float min_pitch_proxy, max_pitch_proxy, min_score, max_size_fraction;
} fg_quality_config;
typedef struct {
    unsigned rejected;
    float mean, laplacian_variance, landmark_error, roll, yaw_proxy, pitch_proxy;
} fg_quality_result;
/* Engineering defaults only; calibrate against the target camera/population. */
fg_quality_config fg_quality_defaults(void);
int fg_quality(const uint8_t *bgr, int width, int height, size_t stride,
               const yunet_face *face, const fg_quality_config *config,
               fg_quality_result *result);
/* Five-point similarity fit, central 96x112 crop of the 112x112 template.
 * Q16 sampling, BGR (pixel-127.5)/127.5 normalization, compiled INT8 scale.
 * Caller owns FG_WIDTH*FG_HEIGHT*3 bytes. Rejects out-of-image sampling. */
int fg_align(const uint8_t *bgr, int width, int height, size_t stride,
             const yunet_face *face, int fix_point, int8_t *rgb);
#ifdef __cplusplus
}
#endif
#endif
