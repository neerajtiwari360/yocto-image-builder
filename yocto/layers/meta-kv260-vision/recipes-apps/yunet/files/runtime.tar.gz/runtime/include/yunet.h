#ifndef YUNET_H
#define YUNET_H
#include <stddef.h>
#include <stdint.h>
#define YUNET_SIDE 320
#define YUNET_HEADS 12
#define YUNET_MAX_CANDIDATES 2100
typedef struct { float x,y,w,h,landmarks[10],score; } yunet_face;
typedef struct { int width,height,resized_width,resized_height; } yunet_transform;
typedef struct {
    const int8_t *data; /* NHWC contiguous, one batch */
    int height,width,channels,fix_point;
} yunet_head;
/* Input is BGR uint8. No /255, channel mean subtraction or RGB swap. */
int yunet_preprocess(const uint8_t *bgr, int width, int height, size_t stride,
                     int fix_point, int8_t *nhwc, yunet_transform *transform);
/* Heads are cls8/16/32, obj8/16/32, bbox8/16/32, kps8/16/32. */
int yunet_decode(const yunet_head heads[YUNET_HEADS], float threshold,
                 float nms_iou, const yunet_transform *transform,
                 yunet_face *faces, size_t capacity, size_t *count);
int yunet_nv12_to_bgr(const uint8_t *y, size_t y_length, size_t y_stride,
                      const uint8_t *uv, size_t uv_length, size_t uv_stride,
                      int width, int height, int matrix, int full_range, uint8_t *bgr);
/* Same tensor as NV12->BGR followed by yunet_preprocess, without a full BGR frame. */
int yunet_preprocess_nv12(const uint8_t *y, size_t y_length, size_t y_stride,
                         const uint8_t *uv, size_t uv_length, size_t uv_stride,
                         int width, int height, int matrix, int full_range,
                         int fix_point, int8_t *nhwc, yunet_transform *transform);
#endif
