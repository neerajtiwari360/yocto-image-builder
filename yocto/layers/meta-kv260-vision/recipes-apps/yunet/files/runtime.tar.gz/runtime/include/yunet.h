/* Compatibility umbrella; modules may include their narrower API header. */
#ifndef YUNET_H
#define YUNET_H
#include "yunet_preprocess.h"
#include "yunet_postprocess.h"
#endif
