#define _POSIX_C_SOURCE 200809L
#include "camera_guard.h"
#include <errno.h>
#include <fcntl.h>
#include <sys/file.h>
#include <time.h>
#include <unistd.h>
int camera_guard_open(const char *path) {
    return open(path,O_RDWR|O_CREAT|O_CLOEXEC|O_NOFOLLOW,0600);
}
int camera_guard_intent(void) {
    int fd=camera_guard_open("/run/yunet-inference.lock");
    if(fd<0)return -1;
    if(flock(fd,LOCK_EX|LOCK_NB)){close(fd);return -1;}
    return fd;
}
int camera_guard_claim(int fd,int timeout_ms) {
    for(int waited=0;;waited+=10){
        if(!flock(fd,LOCK_EX|LOCK_NB))return 0;
        if((errno!=EWOULDBLOCK&&errno!=EAGAIN)||waited>=timeout_ms)return -1;
        struct timespec delay={0,10000000};
        while(nanosleep(&delay,&delay)&&errno==EINTR){}
    }
}
