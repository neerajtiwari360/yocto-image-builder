#ifndef CAMERA_GUARD_H
#define CAMERA_GUARD_H
/* Intent is held for a live inference process. The optional camera-only viewer
 * yields the camera to that intent. Coordination occurs only at ML startup. */
int camera_guard_open(const char *path);
int camera_guard_intent(void);
int camera_guard_claim(int fd,int timeout_ms);
#endif
